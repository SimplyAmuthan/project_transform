package com.usbank.vulnrewrite.service;

import com.usbank.vulnrewrite.model.RecipeArtifact;
import com.usbank.vulnrewrite.model.RemediationPlan;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class RecipeWriterServiceTest {

    private final RecipeWriterService writer = new RecipeWriterService();

    @Test
    void renders_aggregate_plus_inline_recipes() {
        RecipeArtifact known = RecipeArtifact.builder()
                .componentCoordinate("Spring Boot:3.5.11")
                .strategy(RecipeArtifact.Strategy.KNOWN_RECIPE)
                .recipeReference("org.openrewrite.java.spring.boot3.UpgradeSpringBoot_3_5")
                .targetVersion("3.5.14")
                .coversVulnIds(List.of("BDSA-2026-4914"))
                .confidence(0.95)
                .build();

        RecipeArtifact generated = RecipeArtifact.builder()
                .componentCoordinate("Apache Tomcat:11.0.18")
                .strategy(RecipeArtifact.Strategy.GENERATED_YAML)
                .groupId("org.apache.tomcat.embed")
                .artifactId("tomcat-embed-core")
                .targetVersion("11.0.22")
                .coversVulnIds(List.of("BDSA-2026-6784"))
                .confidence(0.85)
                .build();

        RemediationPlan plan = RemediationPlan.builder()
                .aggregateRecipeName("com.usbank.vulnrewrite.AutoRemediation")
                .artifact(known)
                .artifact(generated)
                .generatedAt(Instant.now())
                .build();

        String yaml = writer.render(plan);

        assertThat(yaml).contains("name: com.usbank.vulnrewrite.AutoRemediation");
        assertThat(yaml).contains("- org.openrewrite.java.spring.boot3.UpgradeSpringBoot_3_5");
        assertThat(yaml).contains("UpgradeDependencyVersion");
        assertThat(yaml).contains("newVersion: 11.0.22");
    }
}
