package com.usbank.vulnrewrite.shell;

import com.usbank.vulnrewrite.model.RemediationReport;
import com.usbank.vulnrewrite.model.Vulnerability;
import com.usbank.vulnrewrite.service.RecipeGeneratorService;
import com.usbank.vulnrewrite.service.RemediationOrchestrator;
import com.usbank.vulnrewrite.service.VulnerabilityParserService;
import lombok.RequiredArgsConstructor;
import org.springframework.shell.command.annotation.Command;
import org.springframework.shell.command.annotation.Option;
import org.springframework.stereotype.Component;

import java.nio.file.Path;
import java.util.List;

/**
 * Spring Shell command surface for vuln-rewrite.
 *
 * Three commands are exposed:
 * <ul>
 *   <li>{@code remediate} — full pipeline (parse → plan → apply → push → MR)</li>
 *   <li>{@code plan} — generates the recipe file only and prints it to stdout
 *       (no Git, no Maven). Useful in CI before opening a real PR.</li>
 *   <li>{@code summarise} — parses a vulnerability export and prints a
 *       severity histogram. Quick triage tool.</li>
 * </ul>
 */
@Component
@Command(group = "vuln-rewrite")
@RequiredArgsConstructor
public class RemediationCommands {

    private final RemediationOrchestrator orchestrator;
    private final VulnerabilityParserService parser;
    private final RecipeGeneratorService generator;
    private final com.usbank.vulnrewrite.service.RecipeWriterService writer;

    @Command(command = "remediate", description = "Run the end-to-end remediation pipeline.")
    public String remediate(
            @Option(longNames = "project-url", required = true,
                    description = "GitLab project URL (HTTPS or SSH).") String projectUrl,
            @Option(longNames = "vulnerabilities", required = true,
                    description = "Path to Black Duck export (XLSX, TSV, or CSV).") String vulnFile,
            @Option(longNames = "dry-run", defaultValue = "true",
                    description = "If true, run rewrite:dryRun; if false, rewrite:run.") boolean dryRun,
            @Option(longNames = "push", defaultValue = "false",
                    description = "Push the auto-created branch to origin.") boolean push,
            @Option(longNames = "open-mr", defaultValue = "false",
                    description = "Open a GitLab merge request after pushing.") boolean openMr,
            @Option(longNames = "min-severity", defaultValue = "MEDIUM",
                    description = "Minimum severity to remediate (CRITICAL, HIGH, MEDIUM, LOW).") String severity
    ) {
        RemediationOrchestrator.Request req = new RemediationOrchestrator.Request(
                projectUrl,
                Path.of(vulnFile),
                dryRun,
                push,
                openMr,
                Vulnerability.Severity.from(severity)
        );
        RemediationReport report = orchestrator.execute(req);
        return formatReport(report);
    }

    @Command(command = "plan", description = "Generate a rewrite.yml without touching Git.")
    public String plan(
            @Option(longNames = "vulnerabilities", required = true,
                    description = "Path to Black Duck export.") String vulnFile,
            @Option(longNames = "min-severity", defaultValue = "MEDIUM",
                    description = "Minimum severity threshold.") String severity
    ) {
        List<Vulnerability> vulns = parser.parse(Path.of(vulnFile));
        var plan = generator.generate(vulns, Vulnerability.Severity.from(severity));
        return writer.render(plan);
    }

    @Command(command = "summarise", description = "Quick triage: counts by severity & component.")
    public String summarise(
            @Option(longNames = "vulnerabilities", required = true,
                    description = "Path to Black Duck export.") String vulnFile
    ) {
        List<Vulnerability> vulns = parser.parse(Path.of(vulnFile));
        StringBuilder sb = new StringBuilder();
        sb.append("Total: ").append(vulns.size()).append("\n");
        sb.append("\nBy severity:\n");
        java.util.Map<Vulnerability.Severity, Long> bySev = vulns.stream()
                .collect(java.util.stream.Collectors.groupingBy(
                        Vulnerability::getSeverity, java.util.stream.Collectors.counting()));
        bySev.forEach((s, n) -> sb.append("  ").append(s).append(": ").append(n).append("\n"));
        sb.append("\nBy component:\n");
        java.util.Map<String, Long> byComp = vulns.stream()
                .collect(java.util.stream.Collectors.groupingBy(
                        Vulnerability::componentCoordinate, java.util.stream.Collectors.counting()));
        byComp.forEach((c, n) -> sb.append("  ").append(c).append(": ").append(n).append("\n"));
        return sb.toString();
    }

    private String formatReport(RemediationReport r) {
        return """

                ==================== Remediation Complete ====================
                Project       : %s
                Branch        : %s
                Mode          : %s
                Pushed        : %s
                Merge request : %s
                Vulnerabilities (input)   : %d
                Automated remediations    : %d
                Manual review required    : %d
                Recipe file               : %s
                HTML report               : %s
                ==============================================================
                """.formatted(
                        r.getProjectUrl(),
                        r.getBranchName(),
                        r.isDryRun() ? "dry-run" : "applied",
                        r.isPushed() ? "yes" : "no",
                        r.getMergeRequestUrl() == null ? "n/a" : r.getMergeRequestUrl(),
                        r.getTotalVulnerabilities(),
                        r.getAutomatedRemediations(),
                        r.getManualRemediations(),
                        r.getRecipeFile(),
                        r.getHtmlReportPath());
    }
}
