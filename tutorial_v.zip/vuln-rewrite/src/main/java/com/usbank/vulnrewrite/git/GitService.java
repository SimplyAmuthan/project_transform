package com.usbank.vulnrewrite.git;

import com.usbank.vulnrewrite.config.AppProperties;
import com.usbank.vulnrewrite.exception.RemediationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.jgit.api.CloneCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.Status;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.transport.RefSpec;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.stream.Stream;

/**
 * All Git operations are funnelled through this service so credentials
 * handling is centralised and tests can mock the entire surface.
 *
 * Auth model: GitLab Personal Access Token used as the password with the
 * literal username 'oauth2' — the canonical pattern for token auth on GitLab.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class GitService {

    private final AppProperties props;

    /** Clone a project (or refresh existing checkout) and return the working copy path. */
    public Path cloneOrUpdate(String repoUrl) {
        String slug = slugify(repoUrl);
        Path dest = props.getWorkspace().resolve(slug);
        try {
            Files.createDirectories(props.getWorkspace());
            if (Files.exists(dest.resolve(".git"))) {
                deleteRecursively(dest);
            }
            log.info("Cloning {} → {}", repoUrl, dest);
            try (Git ignored = configureCredentials(Git.cloneRepository())
                    .setURI(repoUrl)
                    .setDirectory(dest.toFile())
                    .call()) {
                return dest;
            }
        } catch (Exception e) {
            throw new RemediationException("Could not clone " + repoUrl, e);
        }
    }

    public String createBranch(Path workingCopy) {
        String branch = props.getBranchPrefix() + "/"
                + DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").format(LocalDateTime.now());
        try (Git git = Git.open(workingCopy.toFile())) {
            Ref ref = git.checkout()
                    .setCreateBranch(true)
                    .setName(branch)
                    .call();
            log.info("Created branch {}", ref.getName());
            return branch;
        } catch (Exception e) {
            throw new RemediationException("Could not create branch", e);
        }
    }

    public boolean commitAll(Path workingCopy, String message) {
        try (Git git = Git.open(workingCopy.toFile())) {
            Status status = git.status().call();
            if (status.isClean()) {
                log.info("No changes to commit.");
                return false;
            }
            git.add().addFilepattern(".").call();
            // addFilepattern doesn't stage deletes — handle them separately.
            for (String missing : status.getMissing()) {
                git.rm().addFilepattern(missing).call();
            }
            git.commit()
                    .setMessage(message)
                    .setSign(false)
                    .call();
            return true;
        } catch (Exception e) {
            throw new RemediationException("Could not commit changes", e);
        }
    }

    public void push(Path workingCopy, String branch) {
        try (Git git = Git.open(workingCopy.toFile())) {
            configureCredentials(git.push())
                    .setRefSpecs(new RefSpec(branch + ":" + branch))
                    .call();
            log.info("Pushed branch {} to origin", branch);
        } catch (Exception e) {
            throw new RemediationException("Could not push branch " + branch, e);
        }
    }

    // ---------- helpers ----------

    private CloneCommand configureCredentials(CloneCommand cmd) {
        if (props.getGitlab().getToken() != null && !props.getGitlab().getToken().isBlank()) {
            cmd.setCredentialsProvider(creds());
        }
        return cmd;
    }

    private org.eclipse.jgit.api.PushCommand configureCredentials(org.eclipse.jgit.api.PushCommand cmd) {
        if (props.getGitlab().getToken() != null && !props.getGitlab().getToken().isBlank()) {
            cmd.setCredentialsProvider(creds());
        }
        return cmd;
    }

    private UsernamePasswordCredentialsProvider creds() {
        return new UsernamePasswordCredentialsProvider("oauth2", props.getGitlab().getToken());
    }

    private String slugify(String repoUrl) {
        String s = repoUrl.replaceAll("https?://", "")
                .replaceAll("[^a-zA-Z0-9._-]+", "_");
        if (s.endsWith(".git")) s = s.substring(0, s.length() - 4);
        return s;
    }

    private void deleteRecursively(Path path) throws IOException {
        if (!Files.exists(path)) return;
        try (Stream<Path> walk = Files.walk(path)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (IOException ignored) {}
            });
        }
    }
}
