package com.usbank.vulnrewrite.service;

import com.usbank.vulnrewrite.exception.RemediationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Executes the OpenRewrite Maven plugin against the working copy.
 *
 * We deliberately shell out to {@code mvn} rather than embedding the plugin —
 * teams already have their own Maven config (mirrors, settings.xml, JDK
 * toolchains) that we should respect. Embedding would force us to mirror those
 * settings, which is fragile.
 */
@Slf4j
@Service
public class RecipeExecutorService {

    public ExecutionResult dryRun(Path workingCopy) {
        return run(workingCopy, "rewrite:dryRun");
    }

    public ExecutionResult run(Path workingCopy) {
        return run(workingCopy, "rewrite:run");
    }

    private ExecutionResult run(Path workingCopy, String goal) {
        if (!Files.exists(workingCopy.resolve("pom.xml"))) {
            throw new RemediationException("No pom.xml in " + workingCopy);
        }
        String mvn = resolveMvn(workingCopy);
        ProcessBuilder pb = new ProcessBuilder(List.of(mvn, "-B", goal))
                .directory(workingCopy.toFile())
                .redirectErrorStream(true);
        log.info("Executing: {} (cwd={})", String.join(" ", pb.command()), workingCopy);
        try {
            Process proc = pb.start();
            StringBuilder log = new StringBuilder();
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    log.append(line).append(System.lineSeparator());
                }
            }
            boolean done = proc.waitFor(45, TimeUnit.MINUTES);
            if (!done) {
                proc.destroyForcibly();
                throw new RemediationException("mvn " + goal + " timed out after 45 minutes");
            }
            int exit = proc.exitValue();
            String output = log.toString();
            return new ExecutionResult(exit, output, summarise(output));
        } catch (IOException | InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RemediationException("mvn " + goal + " failed", e);
        }
    }

    /** Use Maven Wrapper if the project provides one — common in U.S. Bank repos. */
    private String resolveMvn(Path workingCopy) {
        Path wrapper = workingCopy.resolve(isWindows() ? "mvnw.cmd" : "mvnw");
        if (Files.exists(wrapper) && Files.isExecutable(wrapper)) {
            return wrapper.toAbsolutePath().toString();
        }
        return "mvn";
    }

    private boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    /** Pull out the rewrite plugin's "would make X changes" summary lines. */
    private String summarise(String mvnOutput) {
        return mvnOutput.lines()
                .filter(l -> l.contains("[INFO] Patch:") ||
                             l.contains("changes") ||
                             l.contains("BUILD SUCCESS") ||
                             l.contains("BUILD FAILURE"))
                .reduce("", (a, b) -> a + b + System.lineSeparator());
    }

    public record ExecutionResult(int exitCode, String fullOutput, String summary) {
        public boolean ok() { return exitCode == 0; }
    }
}
