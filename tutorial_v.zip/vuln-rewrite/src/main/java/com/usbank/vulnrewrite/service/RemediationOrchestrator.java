package com.usbank.vulnrewrite.service;

import com.usbank.vulnrewrite.config.AppProperties;
import com.usbank.vulnrewrite.exception.RemediationException;
import com.usbank.vulnrewrite.git.GitLabMergeRequestService;
import com.usbank.vulnrewrite.git.GitService;
import com.usbank.vulnrewrite.maven.MavenPluginInjector;
import com.usbank.vulnrewrite.model.RemediationPlan;
import com.usbank.vulnrewrite.model.RemediationReport;
import com.usbank.vulnrewrite.model.Vulnerability;
import com.usbank.vulnrewrite.report.ReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.time.Instant;
import java.util.List;

/**
 * The end-to-end pipeline. This is the only class the Spring Shell command
 * layer talks to, so the user-facing surface stays small and the steps are
 * easy to reorder when product requirements change.
 *
 * Pipeline:
 *  1. parse vulnerabilities
 *  2. clone target repo + create branch
 *  3. ask Spring AI for a {@link RemediationPlan}
 *  4. write {@code rewrite.yml} into the working copy
 *  5. inject the {@code rewrite-maven-plugin} into pom.xml
 *  6. run {@code rewrite:dryRun} or {@code rewrite:run}
 *  7. commit, optionally push, optionally open an MR
 *  8. write the report
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RemediationOrchestrator {

    private final VulnerabilityParserService parser;
    private final RecipeGeneratorService generator;
    private final RecipeWriterService writer;
    private final RecipeExecutorService executor;
    private final GitService gitService;
    private final GitLabMergeRequestService mrService;
    private final MavenPluginInjector pluginInjector;
    private final ReportService reportService;
    private final AppProperties props;

    public RemediationReport execute(Request req) {
        log.info("Starting remediation: project={}, dryRun={}", req.projectUrl, req.dryRun);

        // 1. Parse
        List<Vulnerability> vulns = parser.parse(req.vulnerabilityFile);
        if (vulns.isEmpty()) {
            throw new RemediationException("No vulnerabilities found in " + req.vulnerabilityFile);
        }

        // 2. Clone + branch
        Path workingCopy = gitService.cloneOrUpdate(req.projectUrl);
        String branch = gitService.createBranch(workingCopy);

        // 3. Plan
        RemediationPlan plan = generator.generate(vulns, req.severityFloor);

        // 4. Recipe file
        Path recipeFile = writer.writeRecipeFile(plan, workingCopy, props.getRecipeFileName());

        // 5. Plugin
        pluginInjector.inject(workingCopy, plan.getAggregateRecipeName());

        // 6. Run
        RecipeExecutorService.ExecutionResult exec = req.dryRun
                ? executor.dryRun(workingCopy)
                : executor.run(workingCopy);

        if (!exec.ok()) {
            log.warn("Maven exited with code {}; full output captured in report.", exec.exitCode());
        }

        // 7. Commit / push / MR
        boolean committed = gitService.commitAll(workingCopy, buildCommitMessage(plan, req.dryRun));
        boolean pushed = false;
        String mrUrl = null;
        if (committed && req.push) {
            gitService.push(workingCopy, branch);
            pushed = true;
            if (req.openMergeRequest) {
                mrUrl = mrService.openMergeRequest(
                        req.projectUrl, branch,
                        "[vuln-rewrite] Automated dependency remediation",
                        markdownSummary(plan, exec));
            }
        }

        // 8. Report
        RemediationReport report = RemediationReport.builder()
                .projectUrl(req.projectUrl)
                .branchName(branch)
                .workingCopy(workingCopy)
                .recipeFile(recipeFile)
                .dryRun(req.dryRun)
                .pushed(pushed)
                .mergeRequestOpened(mrUrl != null)
                .mergeRequestUrl(mrUrl)
                .totalVulnerabilities(vulns.size())
                .automatedRemediations((int) plan.automatedCount())
                .manualRemediations((int) plan.manualCount())
                .dryRunDiffSummary(exec.summary())
                .completedAt(Instant.now())
                .build();

        Path html = reportService.writeHtml(plan, report);
        return RemediationReport.builder()
                .projectUrl(report.getProjectUrl())
                .branchName(report.getBranchName())
                .workingCopy(report.getWorkingCopy())
                .recipeFile(report.getRecipeFile())
                .dryRun(report.isDryRun())
                .pushed(report.isPushed())
                .mergeRequestOpened(report.isMergeRequestOpened())
                .mergeRequestUrl(report.getMergeRequestUrl())
                .totalVulnerabilities(report.getTotalVulnerabilities())
                .automatedRemediations(report.getAutomatedRemediations())
                .manualRemediations(report.getManualRemediations())
                .dryRunDiffSummary(report.getDryRunDiffSummary())
                .completedAt(report.getCompletedAt())
                .htmlReportPath(html)
                .build();
    }

    private String buildCommitMessage(RemediationPlan plan, boolean dryRun) {
        return "[vuln-rewrite] Apply automated dependency remediation\n\n"
                + "Mode: " + (dryRun ? "dry-run" : "apply") + "\n"
                + "Automated: " + plan.automatedCount() + "\n"
                + "Manual: " + plan.manualCount() + "\n"
                + "Aggregate recipe: " + plan.getAggregateRecipeName() + "\n";
    }

    private String markdownSummary(RemediationPlan plan, RecipeExecutorService.ExecutionResult exec) {
        StringBuilder mr = new StringBuilder();
        mr.append("This MR was generated by **vuln-rewrite**.\n\n");
        mr.append("- Automated remediations: ").append(plan.automatedCount()).append("\n");
        mr.append("- Manual review required: ").append(plan.manualCount()).append("\n");
        mr.append("- Maven exit code: ").append(exec.exitCode()).append("\n\n");
        mr.append("### Recipe artifacts\n\n");
        plan.getArtifacts().forEach(a -> mr.append("- `").append(a.getComponentCoordinate())
                .append("` → ").append(a.getTargetVersion())
                .append(" (").append(a.getStrategy()).append(")\n"));
        return mr.toString();
    }

    /** Strongly-typed inputs from the shell layer. */
    public record Request(
            String projectUrl,
            Path vulnerabilityFile,
            boolean dryRun,
            boolean push,
            boolean openMergeRequest,
            Vulnerability.Severity severityFloor
    ) { }
}
