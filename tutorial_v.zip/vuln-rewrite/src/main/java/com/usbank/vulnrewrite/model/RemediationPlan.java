package com.usbank.vulnrewrite.model;

import lombok.Builder;
import lombok.Singular;
import lombok.Value;

import java.time.Instant;
import java.util.List;

/**
 * The full set of recipe artifacts that will be written into the target
 * project plus the metadata needed to render the report and the Git commit.
 */
@Value
@Builder
public class RemediationPlan {

    String aggregateRecipeName;
    @Singular List<RecipeArtifact> artifacts;
    @Singular("inputVulnerability") List<Vulnerability> inputVulnerabilities;
    Instant generatedAt;

    public long automatedCount() {
        return artifacts.stream()
                .filter(a -> a.getStrategy() != RecipeArtifact.Strategy.MANUAL)
                .count();
    }

    public long manualCount() {
        return artifacts.stream()
                .filter(a -> a.getStrategy() == RecipeArtifact.Strategy.MANUAL)
                .count();
    }
}
