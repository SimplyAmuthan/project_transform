package com.usbank.vulnrewrite.report;

import com.usbank.vulnrewrite.config.AppProperties;
import com.usbank.vulnrewrite.exception.RemediationException;
import com.usbank.vulnrewrite.model.RecipeArtifact;
import com.usbank.vulnrewrite.model.RemediationPlan;
import com.usbank.vulnrewrite.model.RemediationReport;
import com.usbank.vulnrewrite.model.Vulnerability;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.format.DateTimeFormatter;

/**
 * Renders human-readable remediation reports.
 * <p>
 * A single HTML file is written into {@code vulnrewrite.report-dir} with a
 * timestamp suffix; the same content is also collapsed to a Markdown summary
 * suitable for a Confluence page or a Jira ticket description.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ReportService {

    private final AppProperties props;

    public Path writeHtml(RemediationPlan plan, RemediationReport report) {
        try {
            Files.createDirectories(props.getReportDir());
            String stamp = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")
                    .format(java.time.LocalDateTime.now());
            Path out = props.getReportDir().resolve("remediation-" + stamp + ".html");
            Files.writeString(out, renderHtml(plan, report));
            log.info("HTML report → {}", out);
            return out;
        } catch (IOException e) {
            throw new RemediationException("Could not write HTML report", e);
        }
    }

    public String renderMarkdown(RemediationPlan plan, RemediationReport report) {
        StringBuilder md = new StringBuilder();
        md.append("# Vulnerability Remediation Report\n\n");
        md.append("- **Project:** ").append(report.getProjectUrl()).append("\n");
        md.append("- **Branch:** `").append(report.getBranchName()).append("`\n");
        md.append("- **Mode:** ").append(report.isDryRun() ? "Dry run" : "Apply").append("\n");
        md.append("- **Pushed:** ").append(report.isPushed()).append("\n");
        if (report.getMergeRequestUrl() != null) {
            md.append("- **MR:** ").append(report.getMergeRequestUrl()).append("\n");
        }
        md.append("- **Total vulnerabilities:** ").append(report.getTotalVulnerabilities()).append("\n");
        md.append("- **Automated:** ").append(report.getAutomatedRemediations()).append("\n");
        md.append("- **Manual review:** ").append(report.getManualRemediations()).append("\n\n");

        md.append("## Recipe artifacts\n\n");
        md.append("| Component | → | Strategy | Recipe / Note | Confidence |\n");
        md.append("|---|---|---|---|---|\n");
        for (RecipeArtifact a : plan.getArtifacts()) {
            md.append("| ").append(a.getComponentCoordinate())
              .append(" | ").append(a.getTargetVersion() == null ? "—" : a.getTargetVersion())
              .append(" | ").append(a.getStrategy())
              .append(" | ").append(detail(a))
              .append(" | ").append(a.getConfidence() == null ? "—" : String.format("%.2f", a.getConfidence()))
              .append(" |\n");
        }

        md.append("\n## Vulnerabilities covered\n\n");
        md.append("| ID | Severity | Component | Score |\n");
        md.append("|---|---|---|---|\n");
        for (Vulnerability v : plan.getInputVulnerabilities()) {
            md.append("| ").append(v.getVulnerabilityId())
              .append(" | ").append(v.getSeverity())
              .append(" | ").append(v.componentCoordinate())
              .append(" | ").append(v.getBaseScore() == null ? "—" : v.getBaseScore())
              .append(" |\n");
        }

        if (report.getDryRunDiffSummary() != null && !report.getDryRunDiffSummary().isBlank()) {
            md.append("\n## Dry-run summary\n\n```\n");
            md.append(report.getDryRunDiffSummary()).append("\n```\n");
        }
        return md.toString();
    }

    private String detail(RecipeArtifact a) {
        return switch (a.getStrategy()) {
            case KNOWN_RECIPE -> "`" + a.getRecipeReference() + "`";
            case GENERATED_YAML -> "_generated_";
            case MANUAL -> a.getManualNote() == null ? "Manual review" : a.getManualNote();
        };
    }

    private String renderHtml(RemediationPlan plan, RemediationReport report) {
        // Wrap markdown rendering in a minimal HTML shell — keeps the report
        // self-contained and renderable without an external markdown processor.
        String md = renderMarkdown(plan, report);
        String body = md
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
        return """
                <!doctype html>
                <html><head><meta charset="utf-8">
                <title>Vulnerability Remediation Report</title>
                <style>
                  body{font:14px/1.5 -apple-system,Segoe UI,Roboto,sans-serif;
                       max-width:900px;margin:2rem auto;padding:0 1rem;color:#222}
                  pre{background:#f6f8fa;padding:1rem;overflow:auto;border-radius:6px}
                  h1,h2{border-bottom:1px solid #eee;padding-bottom:.3rem}
                  table{border-collapse:collapse;width:100%}
                  th,td{border:1px solid #ddd;padding:.4rem .6rem;text-align:left}
                  th{background:#fafafa}
                </style></head><body><pre>%s</pre></body></html>
                """.formatted(body);
    }
}
