package com.usbank.vulnrewrite.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Centralized configuration for the vuln-rewrite tool.
 * <p>
 * Bound from {@code application.yml} (prefix {@code vulnrewrite}). All paths
 * default to sensible values under the user home so the tool is runnable
 * out-of-the-box from any developer workstation.
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "vulnrewrite")
public class AppProperties {

    /** GitLab settings used for cloning and MR creation. */
    private GitLab gitlab = new GitLab();

    /** Local workspace where target repositories are cloned. */
    private Path workspace = Paths.get(System.getProperty("user.home"), ".vuln-rewrite", "workspace");

    /** Where final reports (HTML / Markdown) are written. */
    private Path reportDir = Paths.get(System.getProperty("user.home"), ".vuln-rewrite", "reports");

    /** Branch prefix used for the auto-created remediation branch. */
    private String branchPrefix = "remediation/vuln-rewrite";

    /** Default minimum severity to act upon. */
    private String minSeverity = "MEDIUM";

    /** Max number of vulnerabilities sent in a single LLM batch. */
    private int batchSize = 10;

    /** Whether the AI may invent novel recipes (true) or only map to known recipes (false). */
    private boolean allowNovelRecipes = true;

    /** Recipe file name written into target repo. */
    private String recipeFileName = "rewrite.yml";

    @Data
    public static class GitLab {
        /** GitLab base URL, e.g. https://gitlab.usbank.com */
        private String baseUrl;
        /** Personal Access Token (PAT) with api + write_repository scopes. */
        private String token;
        /** Whether to open a merge request after pushing. */
        private boolean openMergeRequest = true;
        /** Default target branch for the MR. */
        private String targetBranch = "main";
    }
}
