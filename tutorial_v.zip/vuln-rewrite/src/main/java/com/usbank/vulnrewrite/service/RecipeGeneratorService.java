package com.usbank.vulnrewrite.service;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.usbank.vulnrewrite.config.AppProperties;
import com.usbank.vulnrewrite.exception.RemediationException;
import com.usbank.vulnrewrite.model.RecipeArtifact;
import com.usbank.vulnrewrite.model.RemediationPlan;
import com.usbank.vulnrewrite.model.Vulnerability;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Uses Spring AI to translate {@link Vulnerability} instances into
 * {@link RecipeArtifact}s.
 *
 * The model is given a *deduplicated* batch (one entry per coordinate), with the
 * highest-severity CVE per coordinate. This both controls cost and keeps the
 * recipe set small — one bump for spring-boot fixes 30 transitive CVEs.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RecipeGeneratorService {

    private final ChatClient chatClient;
    private final AppProperties props;

    public RemediationPlan generate(List<Vulnerability> vulns,
                                    Vulnerability.Severity severityFloor) {

        List<Vulnerability> filtered = vulns.stream()
                .filter(v -> v.getSeverity().atLeast(severityFloor))
                .toList();

        if (filtered.isEmpty()) {
            log.warn("No vulnerabilities at or above {} — nothing to do.", severityFloor);
            return RemediationPlan.builder()
                    .aggregateRecipeName("com.usbank.vulnrewrite.NoOp")
                    .generatedAt(Instant.now())
                    .build();
        }

        // Dedupe by component coordinate — keep worst severity.
        Map<String, List<Vulnerability>> byCoordinate = filtered.stream()
                .collect(Collectors.groupingBy(Vulnerability::componentCoordinate,
                        LinkedHashMap::new, Collectors.toList()));

        List<RecipeArtifact> artifacts = new ArrayList<>();
        for (Map.Entry<String, List<Vulnerability>> entry : byCoordinate.entrySet()) {
            try {
                artifacts.add(generateOne(entry.getKey(), entry.getValue()));
            } catch (Exception e) {
                log.error("Failed to generate recipe for {}: {}", entry.getKey(), e.getMessage(), e);
                artifacts.add(manualFallback(entry.getKey(), entry.getValue(),
                        "Recipe generation failed: " + e.getMessage()));
            }
        }

        // Sort: automated first (so KNOWN_RECIPE/GENERATED_YAML appear at top of rewrite.yml)
        artifacts.sort(Comparator.comparing(a -> a.getStrategy() == RecipeArtifact.Strategy.MANUAL ? 1 : 0));

        return RemediationPlan.builder()
                .aggregateRecipeName("com.usbank.vulnrewrite.AutoRemediation")
                .artifacts(artifacts)
                .inputVulnerabilities(filtered)
                .generatedAt(Instant.now())
                .build();
    }

    private RecipeArtifact generateOne(String coordinate, List<Vulnerability> vulns) {
        Vulnerability worst = vulns.stream()
                .max(Comparator.comparingInt(v -> v.getSeverity().weight()))
                .orElseThrow();

        String prompt = buildPrompt(coordinate, vulns, worst);

        log.debug("Calling LLM for coordinate={}", coordinate);

        AiRecipeResponse response = chatClient.prompt()
                .user(prompt)
                .call()
                .entity(AiRecipeResponse.class);

        if (response == null) {
            return manualFallback(coordinate, vulns, "LLM returned no response");
        }
        if (!props.isAllowNovelRecipes()
                && "GENERATED_YAML".equalsIgnoreCase(response.strategy())) {
            return manualFallback(coordinate, vulns,
                    "Novel recipes disabled by configuration; generated YAML rejected.");
        }

        return RecipeArtifact.builder()
                .componentCoordinate(coordinate)
                .groupId(response.groupId())
                .artifactId(response.artifactId())
                .currentVersion(worst.getComponentVersion())
                .targetVersion(response.targetVersion())
                .strategy(safeStrategy(response.strategy()))
                .recipeReference(response.recipeReference())
                .generatedYaml(response.generatedYaml())
                .manualNote(response.manualNote())
                .coversVulnIds(vulns.stream().map(Vulnerability::getVulnerabilityId).toList())
                .confidence(response.confidence())
                .build();
    }

    private RecipeArtifact.Strategy safeStrategy(String s) {
        if (s == null) return RecipeArtifact.Strategy.MANUAL;
        try {
            return RecipeArtifact.Strategy.valueOf(s.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return RecipeArtifact.Strategy.MANUAL;
        }
    }

    private RecipeArtifact manualFallback(String coordinate, List<Vulnerability> vulns, String note) {
        Vulnerability v = vulns.get(0);
        return RecipeArtifact.builder()
                .componentCoordinate(coordinate)
                .groupId(null)
                .artifactId(null)
                .currentVersion(v.getComponentVersion())
                .targetVersion(v.getSuggestedUpgradeVersion())
                .strategy(RecipeArtifact.Strategy.MANUAL)
                .manualNote(note)
                .coversVulnIds(vulns.stream().map(Vulnerability::getVulnerabilityId).toList())
                .confidence(0.0d)
                .build();
    }

    private String buildPrompt(String coordinate, List<Vulnerability> vulns, Vulnerability worst) {
        StringBuilder sb = new StringBuilder();
        sb.append("Component: ").append(coordinate).append("\n");
        sb.append("Current version: ").append(worst.getComponentVersion()).append("\n");
        sb.append("Suggested upgrade (per Black Duck): ").append(worst.getSuggestedUpgradeVersion()).append("\n");
        sb.append("Latest version: ").append(worst.getLatestVersion()).append("\n");
        sb.append("Worst severity: ").append(worst.getSeverity()).append("\n");
        sb.append("Vulnerabilities covered:\n");
        for (Vulnerability v : vulns) {
            sb.append("  - ").append(v.getVulnerabilityId())
              .append(" (").append(v.getSeverity()).append("): ")
              .append(truncate(v.getDescription(), 350)).append("\n");
        }
        sb.append("""

                Decide the best OpenRewrite remediation strategy and return ONLY a JSON object
                matching this schema (no markdown fences, no commentary):

                {
                  "groupId": "<maven groupId or null>",
                  "artifactId": "<maven artifactId or null>",
                  "targetVersion": "<version to upgrade TO>",
                  "strategy": "KNOWN_RECIPE | GENERATED_YAML | MANUAL",
                  "recipeReference": "<fully qualified known recipe name or null>",
                  "generatedYaml": "<full YAML body for a custom org.openrewrite.maven.UpgradeDependencyVersion recipe, or null>",
                  "manualNote": "<reason for manual review or null>",
                  "confidence": 0.0
                }

                Rules:
                - If component is 'Spring Boot' use the canonical recipe name
                  org.openrewrite.java.spring.boot3.UpgradeSpringBoot_3_5 (or 3_4, 3_3 etc).
                - For 'Apache Tomcat' bundled by Spring Boot — DO NOT generate a tomcat-specific
                  recipe; instead recommend bumping spring-boot itself if a fixing version exists,
                  otherwise return strategy=MANUAL with a note.
                - For arbitrary libraries with a clear upgrade target, prefer
                  strategy=GENERATED_YAML using org.openrewrite.maven.UpgradeDependencyVersion.
                - Confidence < 0.6 → return strategy=MANUAL.
                """);
        return sb.toString();
    }

    private String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }

    /** Response shape Spring AI is asked to coerce into. */
    public record AiRecipeResponse(
            @JsonProperty("groupId")         String groupId,
            @JsonProperty("artifactId")      String artifactId,
            @JsonProperty("targetVersion")   String targetVersion,
            @JsonProperty("strategy")        String strategy,
            @JsonProperty("recipeReference") String recipeReference,
            @JsonProperty("generatedYaml")   String generatedYaml,
            @JsonProperty("manualNote")      String manualNote,
            @JsonProperty("confidence")      Double confidence
    ) { }
}
