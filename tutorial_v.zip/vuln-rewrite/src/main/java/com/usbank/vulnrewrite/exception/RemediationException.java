package com.usbank.vulnrewrite.exception;

/**
 * Single checked-style runtime exception used across the remediation pipeline.
 * Wrapping all failures here keeps the Spring Shell error handler simple.
 */
public class RemediationException extends RuntimeException {

    public RemediationException(String message) {
        super(message);
    }

    public RemediationException(String message, Throwable cause) {
        super(message, cause);
    }
}
