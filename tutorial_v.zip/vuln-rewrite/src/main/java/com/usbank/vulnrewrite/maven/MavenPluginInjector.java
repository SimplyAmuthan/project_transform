package com.usbank.vulnrewrite.maven;

import com.usbank.vulnrewrite.exception.RemediationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.maven.model.Build;
import org.apache.maven.model.Model;
import org.apache.maven.model.Plugin;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.apache.maven.model.io.xpp3.MavenXpp3Writer;
import org.codehaus.plexus.util.xml.Xpp3Dom;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Inserts the {@code rewrite-maven-plugin} into the target project's
 * {@code pom.xml} together with the activeRecipes element pointing at the
 * generated aggregate recipe.
 *
 * Idempotent — if the plugin is already declared we update the configuration
 * rather than appending a duplicate. Existing developer settings on the plugin
 * (e.g. {@code <failOnDryRunResults>}) are preserved.
 */
@Slf4j
@Service
public class MavenPluginInjector {

    /** The OpenRewrite plugin coordinates we inject. */
    public static final String OR_GROUP = "org.openrewrite.maven";
    public static final String OR_ARTIFACT = "rewrite-maven-plugin";
    public static final String OR_VERSION = "5.46.0";

    /** Recipe dependencies brought in for canonical recipes (Spring Boot, etc.). */
    private static final String SPRING_RECIPES_GROUP = "org.openrewrite.recipe";
    private static final String SPRING_RECIPES_ARTIFACT = "rewrite-spring";
    private static final String SPRING_RECIPES_VERSION = "5.24.1";

    public void inject(Path projectRoot, String activeRecipe) {
        Path pom = projectRoot.resolve("pom.xml");
        if (!Files.exists(pom)) {
            throw new RemediationException("No pom.xml at " + pom);
        }

        Model model;
        try (InputStream in = Files.newInputStream(pom)) {
            model = new MavenXpp3Reader().read(in);
        } catch (Exception e) {
            throw new RemediationException("Failed to parse pom.xml", e);
        }

        Build build = model.getBuild();
        if (build == null) {
            build = new Build();
            model.setBuild(build);
        }

        Plugin existing = findPlugin(build.getPlugins(), OR_GROUP, OR_ARTIFACT);
        Plugin plugin = (existing != null) ? existing : new Plugin();
        plugin.setGroupId(OR_GROUP);
        plugin.setArtifactId(OR_ARTIFACT);
        if (plugin.getVersion() == null) {
            plugin.setVersion(OR_VERSION);
        }

        Xpp3Dom configuration = (Xpp3Dom) plugin.getConfiguration();
        if (configuration == null) {
            configuration = new Xpp3Dom("configuration");
            plugin.setConfiguration(configuration);
        }
        replaceOrAddChild(configuration, "activeRecipes",
                activeRecipeXml(activeRecipe));
        replaceOrAddChild(configuration, "failOnDryRunResults",
                singleValue("failOnDryRunResults", "false"));

        // Recipe dependency for canonical Spring recipes.
        Xpp3Dom dependencies = configuration.getChild("dependencies");
        if (dependencies == null) {
            dependencies = new Xpp3Dom("dependencies");
            configuration.addChild(dependencies);
        }
        if (!hasDependency(dependencies, SPRING_RECIPES_ARTIFACT)) {
            Xpp3Dom dep = new Xpp3Dom("dependency");
            dep.addChild(text("groupId", SPRING_RECIPES_GROUP));
            dep.addChild(text("artifactId", SPRING_RECIPES_ARTIFACT));
            dep.addChild(text("version", SPRING_RECIPES_VERSION));
            dependencies.addChild(dep);
        }

        if (existing == null) {
            build.addPlugin(plugin);
        }

        try (OutputStream out = Files.newOutputStream(pom)) {
            new MavenXpp3Writer().write(out, model);
            log.info("Updated pom.xml with rewrite-maven-plugin and activeRecipe={}", activeRecipe);
        } catch (IOException e) {
            throw new RemediationException("Failed to rewrite pom.xml", e);
        }
    }

    // ---------- helpers ----------

    private Plugin findPlugin(List<Plugin> plugins, String groupId, String artifactId) {
        if (plugins == null) return null;
        return plugins.stream()
                .filter(p -> groupId.equals(p.getGroupId()) && artifactId.equals(p.getArtifactId()))
                .findFirst().orElse(null);
    }

    private boolean hasDependency(Xpp3Dom dependencies, String artifactId) {
        for (Xpp3Dom dep : dependencies.getChildren("dependency")) {
            Xpp3Dom a = dep.getChild("artifactId");
            if (a != null && artifactId.equals(a.getValue())) return true;
        }
        return false;
    }

    private void replaceOrAddChild(Xpp3Dom parent, String name, Xpp3Dom replacement) {
        for (int i = 0; i < parent.getChildCount(); i++) {
            if (parent.getChild(i).getName().equals(name)) {
                parent.removeChild(i);
                break;
            }
        }
        parent.addChild(replacement);
    }

    private Xpp3Dom activeRecipeXml(String recipeName) {
        Xpp3Dom holder = new Xpp3Dom("activeRecipes");
        holder.addChild(text("recipe", recipeName));
        return holder;
    }

    private Xpp3Dom singleValue(String name, String value) {
        Xpp3Dom n = new Xpp3Dom(name);
        n.setValue(value);
        return n;
    }

    private Xpp3Dom text(String name, String value) {
        Xpp3Dom n = new Xpp3Dom(name);
        n.setValue(value);
        return n;
    }
}
