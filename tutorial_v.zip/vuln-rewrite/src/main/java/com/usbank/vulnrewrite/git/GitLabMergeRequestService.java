package com.usbank.vulnrewrite.git;

import com.usbank.vulnrewrite.config.AppProperties;
import com.usbank.vulnrewrite.exception.RemediationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.MergeRequest;
import org.gitlab4j.api.models.MergeRequestParams;
import org.springframework.stereotype.Service;

/**
 * Thin wrapper around gitlab4j-api for opening a merge request after a push.
 * Project lookup uses URL-encoded "namespace/project" path which is the most
 * reliable identifier across GitLab self-hosted and gitlab.com.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class GitLabMergeRequestService {

    private final AppProperties props;

    public String openMergeRequest(String projectUrl,
                                   String sourceBranch,
                                   String title,
                                   String description) {
        AppProperties.GitLab cfg = props.getGitlab();
        if (!cfg.isOpenMergeRequest()) {
            log.info("MR creation disabled by configuration; skipping.");
            return null;
        }
        String baseUrl = cfg.getBaseUrl();
        if (baseUrl == null || cfg.getToken() == null) {
            log.warn("GitLab base URL or token not configured — cannot open MR.");
            return null;
        }
        String projectPath = extractProjectPath(projectUrl);

        try (GitLabApi api = new GitLabApi(baseUrl, cfg.getToken())) {
            MergeRequestParams params = new MergeRequestParams()
                    .withSourceBranch(sourceBranch)
                    .withTargetBranch(cfg.getTargetBranch())
                    .withTitle(title)
                    .withDescription(description)
                    .withRemoveSourceBranch(true);

            MergeRequest mr = api.getMergeRequestApi().createMergeRequest(projectPath, params);
            log.info("Opened MR !{} → {}", mr.getIid(), mr.getWebUrl());
            return mr.getWebUrl();
        } catch (GitLabApiException e) {
            throw new RemediationException("Failed to open merge request: " + e.getMessage(), e);
        }
    }

    /**
     * Convert a clone URL into a "namespace/project" path that GitLab APIs accept.
     * Examples:
     *   https://gitlab.usbank.com/payments/cardcontrols.git → payments/cardcontrols
     *   git@gitlab.usbank.com:payments/cardcontrols.git    → payments/cardcontrols
     */
    static String extractProjectPath(String repoUrl) {
        String s = repoUrl.trim();
        if (s.endsWith(".git")) s = s.substring(0, s.length() - 4);
        if (s.startsWith("git@")) {
            int colon = s.indexOf(':');
            if (colon > 0) return s.substring(colon + 1);
        }
        if (s.startsWith("http")) {
            int slash = s.indexOf('/', s.indexOf("//") + 2);
            if (slash > 0) return s.substring(slash + 1);
        }
        return s;
    }
}
