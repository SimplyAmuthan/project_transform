package com.usbank.vulnrewrite.model;

import lombok.Builder;
import lombok.Value;

import java.nio.file.Path;
import java.time.Instant;

/**
 * Outcome of an end-to-end run, persisted to disk and printed to the shell.
 */
@Value
@Builder
public class RemediationReport {

    String projectUrl;
    String branchName;
    Path workingCopy;
    Path recipeFile;
    boolean dryRun;
    boolean pushed;
    boolean mergeRequestOpened;
    String mergeRequestUrl;
    int totalVulnerabilities;
    int automatedRemediations;
    int manualRemediations;
    String dryRunDiffSummary;
    Instant completedAt;
    Path htmlReportPath;
}
