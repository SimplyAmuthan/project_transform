package com.usbank.vulnrewrite.model;

import lombok.Builder;
import lombok.Value;

import java.util.List;

/**
 * One unit of remediation: typically a single OpenRewrite recipe step that fixes
 * one or more vulnerabilities in the same component.
 *
 * The {@link Strategy} field tells the executor *how* to apply this:
 * <ul>
 *   <li>{@link Strategy#KNOWN_RECIPE} — reference an existing recipe (no YAML
 *       authoring needed; cheapest and safest path)</li>
 *   <li>{@link Strategy#GENERATED_YAML} — emit a custom YAML recipe block (used
 *       when no built-in recipe exists, e.g. for Tomcat embedded by Spring Boot)</li>
 *   <li>{@link Strategy#MANUAL} — flagged for human review; written into the
 *       remediation report only</li>
 * </ul>
 */
@Value
@Builder
public class RecipeArtifact {

    String componentCoordinate;
    String groupId;
    String artifactId;
    String currentVersion;
    String targetVersion;
    Strategy strategy;
    /** For KNOWN_RECIPE — fully qualified recipe name. */
    String recipeReference;
    /** For GENERATED_YAML — the generated recipe YAML body (without document separator). */
    String generatedYaml;
    /** For MANUAL — explanation of why automation isn't safe. */
    String manualNote;
    /** Vulnerability ids covered by this artifact. */
    List<String> coversVulnIds;
    /** Confidence 0.0–1.0 reported by the model. */
    Double confidence;

    public enum Strategy {
        KNOWN_RECIPE,
        GENERATED_YAML,
        MANUAL
    }
}
