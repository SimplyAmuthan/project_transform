package com.usbank.vulnrewrite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.usbank.vulnrewrite")
public class VulnRewriteApplication {

    public static void main(String[] args) {
        // Banner is fine; Spring Shell takes over after context starts.
        SpringApplication.run(VulnRewriteApplication.class, args);
    }
}
