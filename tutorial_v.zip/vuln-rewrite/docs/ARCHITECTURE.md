# vuln-rewrite — Architecture

## 1. Component view

```plantuml
@startuml
!theme plain
skinparam componentStyle rectangle
skinparam shadowing false

actor "Developer / SRE" as user

package "vuln-rewrite (Spring Shell app)" {
  [RemediationCommands\n(Spring Shell)]      as cli
  [RemediationOrchestrator]                  as orch
  [VulnerabilityParserService]               as parser
  [RecipeGeneratorService]                   as gen
  [RecipeWriterService]                      as writer
  [MavenPluginInjector]                      as inj
  [RecipeExecutorService]                    as exec
  [GitService]                               as git
  [GitLabMergeRequestService]                as mr
  [ReportService]                            as report
}

cloud "Azure OpenAI" as azure
node  "GitLab"        as gitlab
node  "Target Maven\nproject (working copy)" as project
database "Black Duck\nexport (.xlsx)"        as bd

user --> cli : remediate / plan / summarise
cli --> orch
orch --> parser : parse(file)
parser --> bd
orch --> git : clone + branch
git --> gitlab
orch --> gen : generate(plan)
gen --> azure : ChatClient.prompt()
orch --> writer : write rewrite.yml
writer --> project
orch --> inj : inject(pom.xml)
inj --> project
orch --> exec : mvn rewrite:dryRun|run
exec --> project
orch --> git : commit + push
git --> gitlab
orch --> mr : open MR
mr --> gitlab
orch --> report : write HTML/MD
@enduml
```

## 2. End-to-end sequence

```plantuml
@startuml
!theme plain
autonumber

actor User
participant "RemediationCommands" as Cmd
participant "RemediationOrchestrator" as Orch
participant "VulnerabilityParserService" as Parser
participant "GitService" as Git
participant "RecipeGeneratorService" as Gen
participant "Azure OpenAI" as AI
participant "RecipeWriterService" as Writer
participant "MavenPluginInjector" as Inj
participant "RecipeExecutorService" as Exec
participant "GitLabMergeRequestService" as MR
participant "ReportService" as Rpt

User -> Cmd : remediate --project-url ... --vulnerabilities ...
Cmd -> Orch : execute(Request)
Orch -> Parser : parse(file)
Parser --> Orch : List<Vulnerability>

Orch -> Git : cloneOrUpdate(url)
Git --> Orch : workingCopy
Orch -> Git : createBranch()
Git --> Orch : branchName

Orch -> Gen : generate(vulns, severityFloor)
loop for each unique component coordinate
  Gen -> AI : prompt(component, vulns)
  AI --> Gen : RecipeArtifact JSON
end
Gen --> Orch : RemediationPlan

Orch -> Writer : writeRecipeFile(plan, workingCopy)
Writer --> Orch : recipeFile

Orch -> Inj : inject(workingCopy, aggregateRecipe)

alt dryRun=true
  Orch -> Exec : dryRun(workingCopy)
else dryRun=false
  Orch -> Exec : run(workingCopy)
end
Exec --> Orch : ExecutionResult

Orch -> Git : commitAll()
opt push=true
  Orch -> Git : push(branch)
  opt openMr=true
    Orch -> MR : openMergeRequest(...)
    MR --> Orch : mrUrl
  end
end

Orch -> Rpt : writeHtml(plan, report)
Orch --> Cmd : RemediationReport
Cmd --> User : formatted summary
@enduml
```

## 3. Domain model

```plantuml
@startuml
!theme plain
class Vulnerability {
  +applicationId : String
  +componentName : String
  +componentVersion : String
  +severity : Severity
  +vulnerabilityId : String
  +suggestedUpgradeVersion : String
  +baseScore : Double
  +componentCoordinate() : String
}

enum Severity {
  CRITICAL
  HIGH
  MEDIUM
  LOW
  UNSPECIFIED
  +weight() : int
  +atLeast(floor) : boolean
}

class RecipeArtifact {
  +componentCoordinate : String
  +groupId / artifactId / targetVersion : String
  +strategy : Strategy
  +recipeReference : String
  +generatedYaml : String
  +manualNote : String
  +coversVulnIds : List<String>
  +confidence : Double
}

enum Strategy {
  KNOWN_RECIPE
  GENERATED_YAML
  MANUAL
}

class RemediationPlan {
  +aggregateRecipeName : String
  +artifacts : List<RecipeArtifact>
  +inputVulnerabilities : List<Vulnerability>
  +automatedCount() : long
  +manualCount() : long
}

class RemediationReport {
  +projectUrl : String
  +branchName : String
  +recipeFile : Path
  +dryRun / pushed / mergeRequestOpened : boolean
  +mergeRequestUrl : String
  +totalVulnerabilities : int
  +automatedRemediations : int
  +manualRemediations : int
  +htmlReportPath : Path
}

Vulnerability "1..*" --> Severity
RecipeArtifact "1" --> Strategy
RemediationPlan "1" --> "0..*" RecipeArtifact
RemediationPlan "1" --> "0..*" Vulnerability
@enduml
```

## 4. Decision: why three recipe strategies?

| Strategy        | When | Trust level |
|-----------------|------|-------------|
| `KNOWN_RECIPE`  | A canonical recipe exists (e.g. `UpgradeSpringBoot_3_5`). | High — recipe is authored by Moderne/community. |
| `GENERATED_YAML`| LLM emits a vanilla `UpgradeDependencyVersion` for a library with a clean upgrade target. | Medium — bounded blast radius (Maven coordinates only). |
| `MANUAL`        | Confidence < 0.6, conflicting upgrades, or business-logic-touching change required. | Out of scope for automation; written to the report. |

Splitting these three concerns means the **automated path is provably narrow**: we never let
the LLM modify Java source. All it can ever produce is a Maven dependency bump — verifiable
by `mvn dependency:tree` and `mvn rewrite:dryRun` before any push.

## 5. Failure modes

| Failure                                  | Behaviour |
|------------------------------------------|-----------|
| Black Duck file missing / wrong format   | `RemediationException` from parser; pipeline aborts. |
| LLM unreachable / throws                 | `RecipeGeneratorService` falls back to `MANUAL` artifact and continues. |
| `pom.xml` malformed                      | `MavenPluginInjector` aborts before any push. |
| `mvn rewrite:run` fails                  | Maven exit code captured in report; commit still happens (user can inspect locally). |
| GitLab token missing                     | Push skipped; MR creation skipped; report still written. |
