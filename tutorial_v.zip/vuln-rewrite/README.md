# vuln-rewrite

> AI-powered Spring Shell tool that converts Black Duck vulnerability exports into
> OpenRewrite recipes, then applies them to a target GitLab project.

`vuln-rewrite` closes the loop between vulnerability scanning and remediation. Point it at a
GitLab project URL and a Black Duck export (the same `.xlsx` your security team already
sends), and it will:

1. Parse and prioritise the vulnerabilities.
2. Use Spring AI (Azure OpenAI) to translate each vulnerable component into the most
   appropriate **OpenRewrite recipe** — preferring canonical recipes (`UpgradeSpringBoot_3_5`,
   etc.) and only falling back to a custom YAML recipe when no built-in fits.
3. Clone the target repo, create a remediation branch, write `rewrite.yml`, and inject the
   `rewrite-maven-plugin` (with `activeRecipes`, recipe dependencies, and `failOnDryRunResults=false`)
   directly into the target `pom.xml`.
4. Run either `mvn rewrite:dryRun` (default, safe) or `mvn rewrite:run`.
5. Commit the changes, optionally push the branch, and optionally open a GitLab MR.
6. Emit an HTML + Markdown remediation report.

---

## Quick start

### 1. Build

```bash
mvn -DskipTests clean package
```

### 2. Configure

Set environment variables (or override in `application.yml`):

```bash
export AZURE_OPENAI_ENDPOINT="https://<your-resource>.openai.azure.com"
export AZURE_OPENAI_API_KEY="<key>"
export AZURE_OPENAI_DEPLOYMENT="gpt-4o"           # or gpt-4o-mini, gpt-4-turbo …
export GITLAB_BASE_URL="https://gitlab.usbank.com"
export GITLAB_TOKEN="<personal-access-token>"
```

### 3. Run

```bash
java -jar target/vuln-rewrite-0.1.0.jar
```

You'll land in the Spring Shell prompt:

```
shell:>help

vuln-rewrite
        plan         Generate a rewrite.yml without touching Git.
        remediate    Run the end-to-end remediation pipeline.
        summarise    Quick triage: counts by severity & component.
```

---

## Commands

### `summarise` — triage

```
shell:>summarise --vulnerabilities ./blackduck-export.xlsx
Total: 47

By severity:
  HIGH: 23
  MEDIUM: 18
  LOW: 6

By component:
  Spring Boot:3.5.11: 14
  Apache Tomcat:11.0.18: 9
  ...
```

### `plan` — generate `rewrite.yml` only (dry, offline)

```
shell:>plan --vulnerabilities ./blackduck-export.xlsx --min-severity HIGH
```

Prints the generated YAML to stdout. Useful in CI before opening a real MR.

### `remediate` — full pipeline

```
shell:>remediate \
   --project-url https://gitlab.usbank.com/payments/cardcontrols.git \
   --vulnerabilities ./blackduck-export.xlsx \
   --dry-run true \
   --push false \
   --open-mr false \
   --min-severity HIGH
```

| Option              | Default | Description |
|---------------------|---------|-------------|
| `--project-url`     | —       | GitLab project URL (HTTPS or SSH). |
| `--vulnerabilities` | —       | Path to Black Duck export (XLSX, TSV, CSV). |
| `--dry-run`         | `true`  | `true` → `mvn rewrite:dryRun`; `false` → `mvn rewrite:run`. |
| `--push`            | `false` | Push the auto-created branch to origin. |
| `--open-mr`         | `false` | Open a GitLab merge request after pushing. |
| `--min-severity`    | `MEDIUM`| Minimum severity threshold (CRITICAL/HIGH/MEDIUM/LOW). |

Typical workflow:

```bash
# 1. Inspect what would change
shell:>remediate --project-url ... --vulnerabilities export.xlsx --dry-run true

# 2. When happy, apply + push + MR in one go
shell:>remediate --project-url ... --vulnerabilities export.xlsx --dry-run false --push true --open-mr true
```

---

## What gets injected into your `pom.xml`

Idempotent — re-running won't duplicate the plugin:

```xml
<plugin>
  <groupId>org.openrewrite.maven</groupId>
  <artifactId>rewrite-maven-plugin</artifactId>
  <version>5.46.0</version>
  <configuration>
    <activeRecipes>
      <recipe>com.usbank.vulnrewrite.AutoRemediation</recipe>
    </activeRecipes>
    <failOnDryRunResults>false</failOnDryRunResults>
    <dependencies>
      <dependency>
        <groupId>org.openrewrite.recipe</groupId>
        <artifactId>rewrite-spring</artifactId>
        <version>5.24.1</version>
      </dependency>
    </dependencies>
  </configuration>
</plugin>
```

And a `rewrite.yml` like:

```yaml
---
type: specs.openrewrite.org/v1beta/recipe
name: com.usbank.vulnrewrite.AutoRemediation
displayName: U.S. Bank automated vulnerability remediation
recipeList:
  - org.openrewrite.java.spring.boot3.UpgradeSpringBoot_3_5
  - com.usbank.vulnrewrite.upgrade.ApacheTomcat_11_0_18

---
type: specs.openrewrite.org/v1beta/recipe
name: com.usbank.vulnrewrite.upgrade.ApacheTomcat_11_0_18
displayName: Upgrade Apache Tomcat:11.0.18 → 11.0.22
recipeList:
  - org.openrewrite.maven.UpgradeDependencyVersion:
      groupId: org.apache.tomcat.embed
      artifactId: tomcat-embed-core
      newVersion: 11.0.22
```

---

## Safety model

| Risk                              | Mitigation |
|-----------------------------------|------------|
| LLM invents a non-existent recipe | Confidence threshold + fallback to `MANUAL` strategy. |
| Recipe touches business logic     | System prompt forbids it; only Maven/dependency recipes are allowed. |
| Push to `main` by accident        | Branch is always created with timestamped prefix; `--push` defaults to `false`. |
| Plugin overrides developer config | `MavenPluginInjector` is idempotent and merges with existing `<configuration>` blocks. |
| Maven mirror / settings           | We shell out to the project's own `mvnw`/`mvn`, inheriting its `settings.xml`. |

---

## Architecture

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for PlantUML component & sequence diagrams.

---

## Roadmap (potential extensions)

- **Recipe cache** — keyed by `(component, version, target)` to skip repeat LLM calls across applications.
- **Pre-canned recipe registry** — drop-in YAML files under `src/main/resources/recipes/known/` indexed by CVE/BDSA → recipe.
- **Multi-module support** — inject plugin into root `pom.xml` only when modules inherit from a parent.
- **Confluence / Jira integration** — write the Markdown report straight to a Confluence page or attach to a Jira ticket.
- **MCP server mode** — expose `remediate` as an MCP tool so that an upstream agent can drive it end-to-end.
