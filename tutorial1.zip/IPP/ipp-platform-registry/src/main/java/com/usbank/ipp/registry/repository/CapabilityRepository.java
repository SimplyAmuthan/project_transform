package com.usbank.ipp.registry.repository;

import com.usbank.ipp.registry.model.Capability;
import com.usbank.ipp.registry.model.Capability.CapabilityType;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.*;

public interface CapabilityRepository extends MongoRepository<Capability, String> {
    Optional<Capability> findByCapabilityId(String capabilityId);
    List<Capability> findByPlatformId(String platformId);
    Page<Capability> findByPlatformId(String platformId, Pageable pageable);
    Optional<Capability> findByPlatformIdAndSlug(String platformId, String slug);
    boolean existsByPlatformIdAndSlug(String platformId, String slug);
    List<Capability> findByType(CapabilityType type);
    Page<Capability> findByPlatformIdAndType(String platformId, CapabilityType type, Pageable pageable);
}
