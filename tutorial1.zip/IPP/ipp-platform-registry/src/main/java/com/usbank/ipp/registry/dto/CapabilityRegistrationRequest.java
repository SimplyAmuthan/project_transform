package com.usbank.ipp.registry.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.util.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class CapabilityRegistrationRequest {
    @NotBlank private String name;
    @NotBlank @Pattern(regexp = "^[a-z0-9\\-]{2,80}$", message = "Slug must be lowercase alphanumeric with hyphens")
    private String slug;
    @NotNull private String type;
    @NotBlank private String version;
    private String description;
    private String deliveryMechanism;

    // *** Onboarding JSON Schema for this capability ***
    private Object onboardingSchema;

    // API-specific
    private String endpoint;
    private String openApiSpecUrl;
    private List<String> protocols;
    private boolean authRequired;
    private Map<String, Integer> rateLimits;
    private Map<String, String> sla;
    // MFE/SDK/Scaffold/Config
    private Map<String, Object> mfeConfig;
    private Map<String, Object> sdkConfig;
    private Map<String, Object> scaffoldConfig;
    private Map<String, Object> configTemplate;

    private List<String> tags;
    private List<String> dependencies;
}
