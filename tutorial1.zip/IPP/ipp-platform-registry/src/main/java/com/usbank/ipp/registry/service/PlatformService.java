package com.usbank.ipp.registry.service;

import com.usbank.ipp.registry.dto.*;
import com.usbank.ipp.registry.event.RegistryEventPublisher;
import com.usbank.ipp.registry.exception.*;
import com.usbank.ipp.registry.model.*;
import com.usbank.ipp.registry.model.Platform.*;
import com.usbank.ipp.registry.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import java.time.Instant;
import java.util.*;

@Service @RequiredArgsConstructor @Slf4j
public class PlatformService {
    private final PlatformRepository platformRepo;
    private final CapabilityRepository capabilityRepo;
    private final RegistryEventPublisher eventPublisher;

    @CacheEvict(value = "platforms", allEntries = true)
    public Platform register(PlatformRegistrationRequest req, String createdBy) {
        if (platformRepo.existsBySlug(req.getSlug()))
            throw new DuplicateResourceException("Platform slug already exists: " + req.getSlug());

        String platformId = UUID.randomUUID().toString();
        var platform = Platform.builder()
                .platformId(platformId).slug(req.getSlug()).name(req.getName())
                .description(req.getDescription()).version(req.getVersion())
                .owner(req.getOwner() != null ? PlatformOwner.builder()
                        .teamName(req.getOwner().getTeamName()).contactEmail(req.getOwner().getContactEmail())
                        .slackChannel(req.getOwner().getSlackChannel()).build() : null)
                .status(PlatformStatus.ACTIVE)
                .tags(req.getTags() != null ? req.getTags() : List.of())
                .documentationUrl(req.getDocumentationUrl()).supportTier(req.getSupportTier())
                .complianceCertifications(req.getComplianceCertifications())
                .onboardingConfig(req.getOnboardingConfig() != null ? OnboardingConfig.builder()
                        .selfServiceEnabled(req.getOnboardingConfig().isSelfServiceEnabled())
                        .onboardingEndpoint(req.getOnboardingConfig().getOnboardingEndpoint())
                        .webhookUrl(req.getOnboardingConfig().getWebhookUrl())
                        .hmacSecretRef(req.getOnboardingConfig().getHmacSecretRef()).build() : null)
                .capabilityIds(new ArrayList<>()).createdBy(createdBy).build();

        platform = platformRepo.save(platform);

        if (req.getCapabilities() != null) {
            for (var capReq : req.getCapabilities()) addCapability(platformId, capReq, createdBy);
        }

        eventPublisher.publishPlatformEvent("PLATFORM_REGISTERED", platformId,
                Map.of("platformId", platformId, "name", req.getName(), "slug", req.getSlug()));

        return platformRepo.findByPlatformId(platformId).orElse(platform);
    }

    @Cacheable(value = "platforms", key = "'list-' + #status + '-' + #page + '-' + #size")
    public Page<Platform> listPlatforms(String status, List<String> tags, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "name"));
        if (status != null) return platformRepo.findByStatus(PlatformStatus.valueOf(status), pageable);
        return platformRepo.findAll(pageable);
    }

    @Cacheable(value = "platforms", key = "#platformId")
    public Platform getById(String platformId) {
        return platformRepo.findByPlatformId(platformId)
                .orElseThrow(() -> new ResourceNotFoundException("Platform not found: " + platformId));
    }

    public Platform getBySlug(String slug) {
        return platformRepo.findBySlug(slug)
                .orElseThrow(() -> new ResourceNotFoundException("Platform not found: " + slug));
    }

    @CacheEvict(value = "platforms", allEntries = true)
    public Platform update(String platformId, PlatformUpdateRequest req) {
        Platform p = getById(platformId);
        if (req.getName() != null) p.setName(req.getName());
        if (req.getDescription() != null) p.setDescription(req.getDescription());
        if (req.getVersion() != null) p.setVersion(req.getVersion());
        if (req.getOwner() != null) p.setOwner(PlatformOwner.builder().teamName(req.getOwner().getTeamName())
                .contactEmail(req.getOwner().getContactEmail()).slackChannel(req.getOwner().getSlackChannel()).build());
        if (req.getTags() != null) p.setTags(req.getTags());
        if (req.getDocumentationUrl() != null) p.setDocumentationUrl(req.getDocumentationUrl());
        if (req.getSupportTier() != null) p.setSupportTier(req.getSupportTier());
        if (req.getOnboardingConfig() != null) p.setOnboardingConfig(OnboardingConfig.builder()
                .selfServiceEnabled(req.getOnboardingConfig().isSelfServiceEnabled())
                .onboardingEndpoint(req.getOnboardingConfig().getOnboardingEndpoint())
                .webhookUrl(req.getOnboardingConfig().getWebhookUrl())
                .hmacSecretRef(req.getOnboardingConfig().getHmacSecretRef()).build());
        p = platformRepo.save(p);
        eventPublisher.publishPlatformEvent("PLATFORM_UPDATED", platformId, Map.of("platformId", platformId));
        return p;
    }

    @CacheEvict(value = "platforms", allEntries = true)
    public void deactivate(String platformId) {
        Platform p = getById(platformId);
        p.setStatus(PlatformStatus.INACTIVE);
        platformRepo.save(p);
        eventPublisher.publishPlatformEvent("PLATFORM_DEACTIVATED", platformId, Map.of("platformId", platformId));
    }

    // --- Capabilities ---

    @CacheEvict(value = {"platforms", "capabilitySchemas"}, allEntries = true)
    public Capability addCapability(String platformId, CapabilityRegistrationRequest req, String createdBy) {
        Platform platform = getById(platformId);
        if (capabilityRepo.existsByPlatformIdAndSlug(platformId, req.getSlug()))
            throw new DuplicateResourceException("Capability slug already exists in this platform: " + req.getSlug());

        String capId = UUID.randomUUID().toString();
        var cap = Capability.builder()
                .capabilityId(capId).platformId(platformId).slug(req.getSlug()).name(req.getName())
                .type(Capability.CapabilityType.valueOf(req.getType()))
                .version(req.getVersion()).description(req.getDescription())
                .deliveryMechanism(req.getDeliveryMechanism() != null ? Capability.DeliveryMechanism.valueOf(req.getDeliveryMechanism()) : null)
                .status(Capability.CapabilityStatus.ACTIVE)
                .onboardingSchema(req.getOnboardingSchema()) // <-- Per-capability JSON Schema
                .endpoint(req.getEndpoint()).openApiSpecUrl(req.getOpenApiSpecUrl())
                .protocols(req.getProtocols()).authRequired(req.isAuthRequired())
                .rateLimits(req.getRateLimits() != null ? Capability.RateLimits.builder()
                        .requestsPerMinute(req.getRateLimits().getOrDefault("requestsPerMinute", 0))
                        .burstLimit(req.getRateLimits().getOrDefault("burstLimit", 0)).build() : null)
                .sla(req.getSla() != null ? Capability.Sla.builder()
                        .availability(req.getSla().get("availability")).p99Latency(req.getSla().get("p99Latency")).build() : null)
                .tags(req.getTags()).dependencies(req.getDependencies())
                .versionHistory(new ArrayList<>(List.of(Capability.CapabilityVersion.builder()
                        .version(req.getVersion()).changelog("Initial release")
                        .publishedAt(Instant.now()).publishedBy(createdBy).build())))
                .build();

        cap = capabilityRepo.save(cap);
        platform.getCapabilityIds().add(capId);
        platformRepo.save(platform);

        eventPublisher.publishCapabilityEvent("CAPABILITY_REGISTERED", capId,
                Map.of("capabilityId", capId, "platformId", platformId, "name", req.getName(),
                        "type", req.getType(), "hasOnboardingSchema", req.getOnboardingSchema() != null));
        return cap;
    }

    public List<Capability> listCapabilities(String platformId) { getById(platformId); return capabilityRepo.findByPlatformId(platformId); }

    public Capability getCapability(String platformId, String capabilityId) {
        Capability cap = capabilityRepo.findByCapabilityId(capabilityId)
                .orElseThrow(() -> new ResourceNotFoundException("Capability not found: " + capabilityId));
        if (!cap.getPlatformId().equals(platformId)) throw new ResourceNotFoundException("Capability does not belong to this platform");
        return cap;
    }

    public Capability getCapabilityBySlug(String platformSlug, String capabilitySlug) {
        Platform p = getBySlug(platformSlug);
        return capabilityRepo.findByPlatformIdAndSlug(p.getPlatformId(), capabilitySlug)
                .orElseThrow(() -> new ResourceNotFoundException("Capability not found: " + platformSlug + "/" + capabilitySlug));
    }

    @CacheEvict(value = {"platforms", "capabilitySchemas"}, allEntries = true)
    public Capability updateCapability(String platformId, String capabilityId, CapabilityRegistrationRequest req) {
        Capability cap = getCapability(platformId, capabilityId);
        if (req.getName() != null) cap.setName(req.getName());
        if (req.getDescription() != null) cap.setDescription(req.getDescription());
        if (req.getEndpoint() != null) cap.setEndpoint(req.getEndpoint());
        if (req.getOpenApiSpecUrl() != null) cap.setOpenApiSpecUrl(req.getOpenApiSpecUrl());
        if (req.getProtocols() != null) cap.setProtocols(req.getProtocols());
        if (req.getTags() != null) cap.setTags(req.getTags());
        if (req.getOnboardingSchema() != null) cap.setOnboardingSchema(req.getOnboardingSchema());
        cap = capabilityRepo.save(cap);
        eventPublisher.publishCapabilityEvent("CAPABILITY_UPDATED", capabilityId, Map.of("capabilityId", capabilityId));
        return cap;
    }

    @CacheEvict(value = {"platforms", "capabilitySchemas"}, allEntries = true)
    public Capability deprecateCapability(String platformId, String capabilityId) {
        Capability cap = getCapability(platformId, capabilityId);
        cap.setStatus(Capability.CapabilityStatus.DEPRECATED);
        cap = capabilityRepo.save(cap);
        eventPublisher.publishCapabilityEvent("CAPABILITY_DEPRECATED", capabilityId,
                Map.of("capabilityId", capabilityId, "platformId", platformId, "name", cap.getName()));
        return cap;
    }

    public Capability publishVersion(String platformId, String capabilityId, CapabilityVersionRequest req) {
        Capability cap = getCapability(platformId, capabilityId);
        if (!req.getVersion().matches("^\\d+\\.\\d+\\.\\d+.*$"))
            throw new InvalidOperationException("Version must follow semver format: " + req.getVersion());
        cap.setVersion(req.getVersion());
        if (cap.getVersionHistory() == null) cap.setVersionHistory(new ArrayList<>());
        cap.getVersionHistory().add(Capability.CapabilityVersion.builder()
                .version(req.getVersion()).changelog(req.getChangelog())
                .publishedAt(Instant.now()).publishedBy(req.getPublishedBy()).build());
        cap = capabilityRepo.save(cap);
        eventPublisher.publishCapabilityEvent("CAPABILITY_VERSION_PUBLISHED", capabilityId,
                Map.of("capabilityId", capabilityId, "version", req.getVersion()));
        return cap;
    }
}
