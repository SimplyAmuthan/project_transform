package com.usbank.ipp.registry.exception;
public class ResourceNotFoundException extends RuntimeException { public ResourceNotFoundException(String m) { super(m); } }
