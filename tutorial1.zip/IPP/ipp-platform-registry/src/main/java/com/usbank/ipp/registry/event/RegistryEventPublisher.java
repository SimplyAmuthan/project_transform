package com.usbank.ipp.registry.event;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import java.util.Map;

@Service @RequiredArgsConstructor @Slf4j
public class RegistryEventPublisher {
    private final KafkaTemplate<String, RegistryEvent> kafkaTemplate;

    @Value("${ipp.kafka.topics.platform-events}") private String platformTopic;
    @Value("${ipp.kafka.topics.capability-events}") private String capabilityTopic;

    @Async public void publishPlatformEvent(String eventType, String platformId, Map<String, Object> payload) {
        var event = RegistryEvent.builder().eventType(eventType).correlationId(platformId).payload(payload).build();
        log.info("Publishing platform event: type={}, platformId={}", eventType, platformId);
        kafkaTemplate.send(platformTopic, platformId, event);
    }

    @Async public void publishCapabilityEvent(String eventType, String capabilityId, Map<String, Object> payload) {
        var event = RegistryEvent.builder().eventType(eventType).correlationId(capabilityId).payload(payload).build();
        log.info("Publishing capability event: type={}, capabilityId={}", eventType, capabilityId);
        kafkaTemplate.send(capabilityTopic, capabilityId, event);
    }
}
