package com.usbank.ipp.registry.model;

import lombok.*;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.Instant;
import java.util.*;

@Document(collection = "capabilities")
@CompoundIndex(name = "idx_platform_slug", def = "{'platformId': 1, 'slug': 1}", unique = true)
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class Capability {
    @Id private String id;
    @Indexed(unique = true) private String capabilityId;
    @Indexed private String platformId;
    private String slug;
    private String name;
    private CapabilityType type;
    private String version;
    private String description;
    private DeliveryMechanism deliveryMechanism;
    private CapabilityStatus status;

    // *** Onboarding schema (JSON Schema Draft 7) — per capability ***
    private Object onboardingSchema;

    // API-specific
    private String endpoint;
    private String openApiSpecUrl;
    private List<String> protocols;
    private boolean authRequired;
    private RateLimits rateLimits;
    private Sla sla;
    // MFE-specific
    private MfeConfig mfeConfig;
    // SDK-specific
    private SdkConfig sdkConfig;
    // Scaffold-specific
    private ScaffoldConfig scaffoldConfig;
    // Config-template-specific
    private ConfigTemplate configTemplate;

    private List<String> tags;
    private List<String> dependencies;
    private List<CapabilityVersion> versionHistory;
    @CreatedDate private Instant createdAt;
    @LastModifiedDate private Instant updatedAt;

    public enum CapabilityType { API, MFE, SDK, CONFIG, SCAFFOLD, REPO, DESIGN_ASSET, CODE_SNIPPET }
    public enum DeliveryMechanism { REST_API, GRAPHQL, GRPC, MICRO_FRONTEND, SDK, CONFIG_TEMPLATE, SCAFFOLD_PACKAGE, GIT_REPO, DESIGN_SYSTEM, CODE_LIBRARY }
    public enum CapabilityStatus { ACTIVE, DEPRECATED, BETA, SUNSET }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class RateLimits { private int requestsPerMinute; private int burstLimit; }
    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class Sla { private String availability; private String p99Latency; }
    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class MfeConfig { private String bundleUrl; private String framework; private String moduleName; private String exposedModule; private String mountPoint; private List<String> requiredProps; private String cssIsolation; }
    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class SdkConfig { private List<String> languages; private Map<String, String> repositories; private String sampleCodeUrl; }
    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ScaffoldConfig { private String templateRepoUrl; private List<Map<String, Object>> parameters; private String outputFormat; }
    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ConfigTemplate { private Object schema; private Object defaults; }
    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class CapabilityVersion { private String version; private String changelog; private Instant publishedAt; private String publishedBy; }
}
