package com.usbank.ipp.registry.controller;

import com.usbank.ipp.registry.dto.*;
import com.usbank.ipp.registry.model.*;
import com.usbank.ipp.registry.service.PlatformService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.*;

@RestController @RequestMapping("/api/v1/platforms") @RequiredArgsConstructor @Slf4j
@Tag(name = "Platform Registry", description = "Register, update, and manage platforms and their capabilities. Onboarding schemas are per-capability.")
public class PlatformController {
    private final PlatformService service;

    // ===== Platform CRUD =====

    @PostMapping
    @Operation(summary = "Register a new platform", description = "Register with metadata and onboarding config. Capabilities (with per-capability JSON Schema) can be provided inline or added later.")
    public ResponseEntity<Platform> register(@Valid @RequestBody PlatformRegistrationRequest req) {
        Platform p = service.register(req, "api-caller");
        return ResponseEntity.created(URI.create("/api/v1/platforms/" + p.getPlatformId())).body(p);
    }

    @GetMapping
    @Operation(summary = "List all registered platforms")
    public ResponseEntity<Page<Platform>> list(@RequestParam(required = false) String status, @RequestParam(required = false) List<String> tags, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(service.listPlatforms(status, tags, page, size));
    }

    @GetMapping("/{platformId}")
    @Operation(summary = "Get platform details by ID")
    public ResponseEntity<Platform> getById(@PathVariable String platformId) { return ResponseEntity.ok(service.getById(platformId)); }

    @GetMapping("/slug/{slug}")
    @Operation(summary = "Get platform details by slug")
    public ResponseEntity<Platform> getBySlug(@PathVariable String slug) { return ResponseEntity.ok(service.getBySlug(slug)); }

    @PutMapping("/{platformId}")
    @Operation(summary = "Update platform metadata")
    public ResponseEntity<Platform> update(@PathVariable String platformId, @RequestBody PlatformUpdateRequest req) { return ResponseEntity.ok(service.update(platformId, req)); }

    @DeleteMapping("/{platformId}")
    @Operation(summary = "Deactivate a platform (soft delete)")
    public ResponseEntity<Void> deactivate(@PathVariable String platformId) { service.deactivate(platformId); return ResponseEntity.noContent().build(); }

    // ===== Platform-level config (consumed by Orchestrator) =====

    @GetMapping("/slug/{slug}/onboarding-config")
    @Operation(summary = "Get platform-level onboarding config (endpoint, HMAC, selfService)")
    public ResponseEntity<Platform.OnboardingConfig> getOnboardingConfig(@PathVariable String slug) {
        return ResponseEntity.ok(service.getBySlug(slug).getOnboardingConfig());
    }

    // ===== Capability CRUD =====

    @PostMapping("/{platformId}/capabilities")
    @Operation(summary = "Add a capability with onboarding JSON Schema", description = "Each capability can define its own onboardingSchema (JSON Schema Draft 7) that the Onboarding Orchestrator validates against.")
    public ResponseEntity<Capability> addCapability(@PathVariable String platformId, @Valid @RequestBody CapabilityRegistrationRequest req) {
        Capability cap = service.addCapability(platformId, req, "api-caller");
        return ResponseEntity.created(URI.create("/api/v1/platforms/" + platformId + "/capabilities/" + cap.getCapabilityId())).body(cap);
    }

    @GetMapping("/{platformId}/capabilities")
    @Operation(summary = "List capabilities for a platform")
    public ResponseEntity<List<Capability>> listCapabilities(@PathVariable String platformId) { return ResponseEntity.ok(service.listCapabilities(platformId)); }

    @GetMapping("/{platformId}/capabilities/{capabilityId}")
    @Operation(summary = "Get capability details")
    public ResponseEntity<Capability> getCapability(@PathVariable String platformId, @PathVariable String capabilityId) { return ResponseEntity.ok(service.getCapability(platformId, capabilityId)); }

    @PutMapping("/{platformId}/capabilities/{capabilityId}")
    @Operation(summary = "Update a capability (including its onboarding schema)")
    public ResponseEntity<Capability> updateCapability(@PathVariable String platformId, @PathVariable String capabilityId, @RequestBody CapabilityRegistrationRequest req) { return ResponseEntity.ok(service.updateCapability(platformId, capabilityId, req)); }

    @DeleteMapping("/{platformId}/capabilities/{capabilityId}")
    @Operation(summary = "Deprecate a capability")
    public ResponseEntity<Capability> deprecateCapability(@PathVariable String platformId, @PathVariable String capabilityId) { return ResponseEntity.ok(service.deprecateCapability(platformId, capabilityId)); }

    @PostMapping("/{platformId}/capabilities/{capabilityId}/versions")
    @Operation(summary = "Publish a new capability version")
    public ResponseEntity<Capability> publishVersion(@PathVariable String platformId, @PathVariable String capabilityId, @Valid @RequestBody CapabilityVersionRequest req) { return ResponseEntity.ok(service.publishVersion(platformId, capabilityId, req)); }

    // ===== Capability-level onboarding schema (consumed by Orchestrator) =====

    @GetMapping("/slug/{platformSlug}/capabilities/{capabilitySlug}/onboarding-schema")
    @Operation(summary = "Get onboarding JSON Schema for a specific capability", description = "Returns the JSON Schema that the Onboarding Orchestrator uses to validate onboarding payloads for this capability.")
    public ResponseEntity<Object> getCapabilityOnboardingSchema(@PathVariable String platformSlug, @PathVariable String capabilitySlug) {
        Capability cap = service.getCapabilityBySlug(platformSlug, capabilitySlug);
        if (cap.getOnboardingSchema() == null)
            return ResponseEntity.ok(Map.of("type", "object", "properties", Map.of(), "additionalProperties", true));
        return ResponseEntity.ok(cap.getOnboardingSchema());
    }

    @GetMapping("/slug/{platformSlug}/capabilities/onboarding-schemas")
    @Operation(summary = "Get all capability onboarding schemas for a platform", description = "Returns a map of capabilitySlug -> JSON Schema for all capabilities that have schemas defined.")
    public ResponseEntity<Map<String, Object>> getAllCapabilitySchemas(@PathVariable String platformSlug) {
        Platform p = service.getBySlug(platformSlug);
        List<Capability> caps = service.listCapabilities(p.getPlatformId());
        Map<String, Object> schemas = new LinkedHashMap<>();
        for (Capability cap : caps) {
            if (cap.getOnboardingSchema() != null) schemas.put(cap.getSlug(), cap.getOnboardingSchema());
        }
        return ResponseEntity.ok(schemas);
    }
}
