package com.usbank.ipp.registry.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.util.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class PlatformRegistrationRequest {
    @NotBlank private String name;
    @NotBlank @Pattern(regexp = "^[a-z0-9\\-]{2,50}$", message = "Slug must be lowercase alphanumeric with hyphens, 2-50 chars")
    private String slug;
    @NotBlank private String description;
    @NotBlank private String version;
    @jakarta.validation.Valid private OwnerDto owner;
    private List<String> tags;
    private String documentationUrl;
    private String supportTier;
    private List<String> complianceCertifications;
    private OnboardingConfigDto onboardingConfig;
    private List<CapabilityRegistrationRequest> capabilities;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class OwnerDto {
        @NotBlank private String teamName;
        @NotBlank @Email private String contactEmail;
        private String slackChannel;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class OnboardingConfigDto {
        private boolean selfServiceEnabled;
        private String onboardingEndpoint;
        private String webhookUrl;
        private String hmacSecretRef;
        // NOTE: onboardingSchema is now per-Capability via CapabilityRegistrationRequest.onboardingSchema
    }
}
