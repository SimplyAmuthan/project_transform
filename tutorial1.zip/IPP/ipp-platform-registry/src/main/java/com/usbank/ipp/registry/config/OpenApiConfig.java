package com.usbank.ipp.registry.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI().info(new Info()
                .title("IPP Platform Registry API").version("1.0.0")
                .description("Register, manage, and expose internal banking platforms and their capabilities. " +
                        "Platform providers use this API to publish their platform metadata, onboarding JSON Schema, " +
                        "and capability catalog. The Onboarding Orchestrator consumes this API to resolve platform configs.")
                .contact(new Contact().name("IPP Platform Engineering").email("ipp-platform@usbank.com")));
    }
}
