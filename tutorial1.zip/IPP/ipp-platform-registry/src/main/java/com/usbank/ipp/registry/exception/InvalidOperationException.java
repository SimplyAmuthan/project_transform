package com.usbank.ipp.registry.exception;
public class InvalidOperationException extends RuntimeException { public InvalidOperationException(String m) { super(m); } }
