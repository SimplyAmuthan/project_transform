package com.usbank.ipp.registry.repository;

import com.usbank.ipp.registry.model.Platform;
import com.usbank.ipp.registry.model.Platform.PlatformStatus;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;

public interface PlatformRepository extends MongoRepository<Platform, String> {
    Optional<Platform> findByPlatformId(String platformId);
    Optional<Platform> findBySlug(String slug);
    boolean existsBySlug(String slug);
    Page<Platform> findByStatus(PlatformStatus status, Pageable pageable);
    Page<Platform> findByTagsContaining(String tag, Pageable pageable);
    Page<Platform> findByStatusAndTagsIn(PlatformStatus status, java.util.List<String> tags, Pageable pageable);
}
