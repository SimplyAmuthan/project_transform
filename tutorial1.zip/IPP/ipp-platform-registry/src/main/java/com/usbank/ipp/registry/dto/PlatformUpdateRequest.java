package com.usbank.ipp.registry.dto;

import lombok.*;
import java.util.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class PlatformUpdateRequest {
    private String name;
    private String description;
    private String version;
    private PlatformRegistrationRequest.OwnerDto owner;
    private List<String> tags;
    private String documentationUrl;
    private String supportTier;
    private List<String> complianceCertifications;
    private PlatformRegistrationRequest.OnboardingConfigDto onboardingConfig;
}
