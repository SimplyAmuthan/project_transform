package com.usbank.ipp.registry.event;

import lombok.*;
import java.time.*;
import java.util.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class RegistryEvent {
    @Builder.Default private String eventId = UUID.randomUUID().toString();
    private String eventType;
    @Builder.Default private Instant timestamp = Instant.now();
    @Builder.Default private String source = "platform-registry-service";
    private String correlationId;
    private Map<String, Object> payload;
}
