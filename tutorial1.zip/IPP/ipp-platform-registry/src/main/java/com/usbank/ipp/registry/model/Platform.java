package com.usbank.ipp.registry.model;

import lombok.*;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.Instant;
import java.util.*;

@Document(collection = "platforms")
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class Platform {
    @Id private String id;
    @Indexed(unique = true) private String platformId;
    @Indexed(unique = true) private String slug;
    private String name;
    private String description;
    private String version;
    private PlatformOwner owner;
    private PlatformStatus status;
    private List<String> tags;
    private String documentationUrl;
    private String supportTier;
    private List<String> complianceCertifications;
    private OnboardingConfig onboardingConfig;
    private List<String> capabilityIds;
    @CreatedDate private Instant createdAt;
    @LastModifiedDate private Instant updatedAt;
    private String createdBy;

    public enum PlatformStatus { ACTIVE, DEPRECATED, INACTIVE }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PlatformOwner {
        private String teamName;
        private String contactEmail;
        private String slackChannel;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class OnboardingConfig {
        private boolean selfServiceEnabled;
        private String onboardingEndpoint;  // Platform-level onboarding endpoint
        private String webhookUrl;
        private String hmacSecretRef;
        // NOTE: onboardingSchema is now per-Capability, not per-Platform
    }
}
