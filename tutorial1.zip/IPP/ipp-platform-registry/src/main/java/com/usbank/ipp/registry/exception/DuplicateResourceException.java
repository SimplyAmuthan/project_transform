package com.usbank.ipp.registry.exception;
public class DuplicateResourceException extends RuntimeException { public DuplicateResourceException(String m) { super(m); } }
