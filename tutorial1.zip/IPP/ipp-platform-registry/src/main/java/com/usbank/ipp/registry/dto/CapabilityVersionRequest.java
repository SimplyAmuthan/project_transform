package com.usbank.ipp.registry.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class CapabilityVersionRequest {
    @NotBlank private String version;
    private String changelog;
    private String publishedBy;
}
