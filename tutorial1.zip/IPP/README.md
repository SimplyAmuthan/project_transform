# IPP Microservices — Platform Registry + Onboarding Orchestrator

Two Spring Boot microservices that implement Sections 4.1 and 4.3 of the IPP Design Document.

## Architecture

```
┌──────────────────────┐     ┌──────────────────────┐
│  Platform Registry   │     │ Onboarding           │
│  Service (:8081)     │◄────│ Orchestrator (:8082) │
│                      │     │                      │
│ • Register platforms │     │ • Submit onboarding  │
│ • Manage capabilities│     │ • Validate vs schema │
│ • Store JSON Schema  │     │ • Parallel platform  │
│ • Publish to Kafka   │     │   calls with HMAC    │
│ • Cache in Redis     │     │ • Webhook callbacks  │
└──────┬───────────────┘     └──────┬───────────────┘
       │                            │
  ┌────┴────┐  ┌─────┐  ┌──────┐  ┌┴──────┐
  │MongoDB  │  │Redis│  │Kafka │  │MongoDB│
  │registry │  │cache│  │events│  │onboard│
  └─────────┘  └─────┘  └──────┘  └───────┘
```

## Quick Start

```bash
docker-compose up -d
```

| Service | URL |
|---------|-----|
| Platform Registry API | http://localhost:8081/swagger-ui.html |
| Onboarding Orchestrator API | http://localhost:8082/swagger-ui.html |
| Kafka UI | http://localhost:9091 |
| Mongo Express | http://localhost:8083 |

## Usage Flow

**Step 1: Platform providers register their platforms (Registry :8081)**

```bash
POST http://localhost:8081/api/v1/platforms
{
  "name": "Authentication Platform",
  "slug": "authentication",
  "version": "3.2.0",
  "onboardingConfig": {
    "selfServiceEnabled": true,
    "onboardingEndpoint": "https://auth.internal/api/v1/onboard",
    "onboardingSchema": {  <-- JSON Schema (Draft 7)
      "type": "object",
      "required": ["appId", "environment", "callbackUrls"],
      "properties": {
        "appId": { "type": "string" },
        "environment": { "type": "string", "enum": ["DEV","QA","PROD"] },
        "callbackUrls": { "type": "array", "items": { "type": "string", "format": "uri" } },
        "scopes": { "type": "array", "items": { "type": "string" } }
      }
    }
  }
}
```

**Step 2: Business-line developers submit onboarding requests (Orchestrator :8082)**

The Orchestrator fetches the JSON Schema from the Registry, validates the payload, then fans out.

```bash
POST http://localhost:8082/api/v1/onboarding/requests
{
  "applicationId": "credit-cards-web-app",
  "platforms": [{
    "platformSlug": "authentication",
    "capabilitySlugs": ["oauth-token-service"],
    "onboardingPayload": {
      "appId": "credit-cards-web-app",
      "environment": "QA",
      "callbackUrls": ["https://cc.qa.internal/auth/callback"]
    }
  }]
}
```

## Platform Registry Endpoints (Section 4.1)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/v1/platforms | Register platform with JSON Schema |
| GET | /api/v1/platforms | List all platforms |
| GET | /api/v1/platforms/{id} | Get platform by ID |
| GET | /api/v1/platforms/slug/{slug} | Get platform by slug |
| PUT | /api/v1/platforms/{id} | Update platform |
| DELETE | /api/v1/platforms/{id} | Deactivate platform |
| POST | /api/v1/platforms/{id}/capabilities | Add capability |
| GET | /api/v1/platforms/{id}/capabilities | List capabilities |
| GET | /api/v1/platforms/{id}/capabilities/{capId} | Get capability |
| PUT | /api/v1/platforms/{id}/capabilities/{capId} | Update capability |
| DELETE | /api/v1/platforms/{id}/capabilities/{capId} | Deprecate capability |
| POST | /api/v1/platforms/{id}/capabilities/{capId}/versions | Publish version |
| GET | /api/v1/platforms/slug/{slug}/onboarding-schema | Get JSON Schema |
| GET | /api/v1/platforms/slug/{slug}/onboarding-config | Get full config |

## Onboarding Orchestrator Endpoints (Section 4.3)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/v1/onboarding/requests | Submit multi-platform request |
| GET | /api/v1/onboarding/requests/{id} | Get request status |
| GET | /api/v1/onboarding/requests?appId= | List by application |
| POST | /api/v1/onboarding/requests/{id}/approve | Approve pending request |
| POST | /api/v1/onboarding/requests/{id}/reject | Reject pending request |
| DELETE | /api/v1/onboarding/requests/{id} | Cancel request |
| GET | /api/v1/onboarding/schema/{platformSlug} | Get schema (from Registry) |
| POST | /api/v1/onboarding/requests/{id}/webhook | Platform webhook callback |
