package com.usbank.ipp.onboarding.service;

import com.fasterxml.jackson.databind.*;
import com.networknt.schema.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

@Service @RequiredArgsConstructor @Slf4j
public class SchemaValidationService {

    private final ObjectMapper objectMapper;

    /**
     * Validates a payload against a JSON Schema (stored as a Map from the Platform Registry).
     * Returns a map of field-level errors, empty if valid.
     */
    public Map<String, String> validate(Map<String, Object> payload, Map<String, Object> schemaMap, String platformSlug) {
        Map<String, String> errors = new LinkedHashMap<>();

        if (schemaMap == null || schemaMap.isEmpty()) {
            log.debug("No schema defined for platform {}, skipping validation", platformSlug);
            return errors;
        }

        try {
            JsonNode schemaNode = objectMapper.valueToTree(schemaMap);
            JsonNode payloadNode = objectMapper.valueToTree(payload != null ? payload : Map.of());

            JsonSchemaFactory factory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);
            JsonSchema schema = factory.getSchema(schemaNode);

            Set<ValidationMessage> validationErrors = schema.validate(payloadNode);
            for (ValidationMessage msg : validationErrors) {
                String path = msg.getInstanceLocation().toString().replaceFirst("^/", "").replace("/", ".");
                errors.put(platformSlug + "." + (path.isEmpty() ? "_root" : path), msg.getMessage());
            }
        } catch (Exception e) {
            log.warn("Schema validation error for platform {}: {}", platformSlug, e.getMessage());
            errors.put(platformSlug + "._schema", "Schema validation error: " + e.getMessage());
        }
        return errors;
    }
}
