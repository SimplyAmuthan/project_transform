package com.usbank.ipp.onboarding.model;

import lombok.*;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.index.*;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.Instant;
import java.util.*;

@Document(collection = "onboarding_requests")
@CompoundIndex(name = "idx_appId_status", def = "{'applicationId': 1, 'status': 1}")
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OnboardingRequest {
    @Id private String id;
    @Indexed(unique = true) private String requestId;
    @Indexed private String applicationId;
    private String applicationName;
    private String businessLine;
    private String environment;
    private String requestedBy;
    @Indexed private RequestStatus status;
    private List<PlatformOnboarding> platforms;
    private Map<String, Object> metadata;
    @CreatedDate private Instant createdAt;
    @LastModifiedDate private Instant updatedAt;

    public enum RequestStatus { PENDING, PENDING_APPROVAL, IN_PROGRESS, COMPLETED, FAILED, CANCELLED, REJECTED }
    public enum PlatformStatus { PENDING, IN_PROGRESS, COMPLETED, FAILED }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PlatformOnboarding {
        private String platformSlug;
        private List<CapabilityOnboarding> capabilities; // per-capability payloads
        private PlatformStatus status;
        private String externalOnboardingId;
        private Map<String, Object> credentials;
        private String error;
        private Instant startedAt;
        private Instant completedAt;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class CapabilityOnboarding {
        private String capabilitySlug;
        private Map<String, Object> onboardingPayload;
    }
}
