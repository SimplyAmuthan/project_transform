package com.usbank.ipp.onboarding.config;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.*;
import org.springframework.context.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class AppConfig {
    @Bean public WebClient.Builder webClientBuilder() { return WebClient.builder(); }
    @Bean public OpenAPI openAPI() {
        return new OpenAPI().info(new Info().title("IPP Onboarding Orchestrator API").version("1.0.0")
                .description("Orchestrates multi-platform onboarding. Validates payloads against JSON Schema from the Platform Registry Service, " +
                        "then fans out parallel calls to each platform's onboarding endpoint with HMAC-signed payloads."));
    }
}
