package com.usbank.ipp.onboarding.controller;

import com.usbank.ipp.onboarding.dto.*;
import com.usbank.ipp.onboarding.service.OnboardingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.Map;

@RestController @RequestMapping("/api/v1/onboarding") @RequiredArgsConstructor @Slf4j
@Tag(name = "Onboarding Orchestrator", description = "Manage application onboarding. Payloads are validated per-capability against JSON Schema from the Platform Registry.")
public class OnboardingController {
    private final OnboardingService service;

    @PostMapping("/requests")
    @Operation(summary = "Submit multi-platform onboarding request", description = "Each capability within each platform has its own onboardingPayload validated against that capability's JSON Schema from the Platform Registry.")
    public ResponseEntity<OnboardingResponse> submit(@Valid @RequestBody OnboardingSubmitRequest req) {
        var resp = service.submit(req);
        return ResponseEntity.created(URI.create("/api/v1/onboarding/requests/" + resp.getRequestId())).body(resp);
    }

    @GetMapping("/requests/{requestId}")
    @Operation(summary = "Get onboarding request status")
    public ResponseEntity<OnboardingResponse> get(@PathVariable String requestId) { return ResponseEntity.ok(service.getRequest(requestId)); }

    @GetMapping("/requests")
    @Operation(summary = "List onboarding requests by application ID")
    public ResponseEntity<Page<OnboardingResponse>> list(@RequestParam String appId, @RequestParam(required = false) String status, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(service.listByApp(appId, status, page, size));
    }

    @PostMapping("/requests/{requestId}/approve")
    @Operation(summary = "Approve pending request")
    public ResponseEntity<OnboardingResponse> approve(@PathVariable String requestId, @RequestBody(required = false) ApprovalRequest req) {
        return ResponseEntity.ok(service.approve(requestId, req != null ? req : new ApprovalRequest("admin", null)));
    }

    @PostMapping("/requests/{requestId}/reject")
    @Operation(summary = "Reject pending request")
    public ResponseEntity<OnboardingResponse> reject(@PathVariable String requestId, @Valid @RequestBody RejectionRequest req) {
        return ResponseEntity.ok(service.reject(requestId, req));
    }

    @DeleteMapping("/requests/{requestId}")
    @Operation(summary = "Cancel onboarding request")
    public ResponseEntity<Void> cancel(@PathVariable String requestId) { service.cancel(requestId); return ResponseEntity.noContent().build(); }

    @GetMapping("/schema/{platformSlug}/{capabilitySlug}")
    @Operation(summary = "Get onboarding JSON Schema for a specific capability (proxied from Registry)")
    public ResponseEntity<Map<String, Object>> getCapabilitySchema(@PathVariable String platformSlug, @PathVariable String capabilitySlug) {
        return ResponseEntity.ok(service.getCapabilitySchema(platformSlug, capabilitySlug));
    }

    @PostMapping("/requests/{requestId}/webhook")
    @Operation(summary = "Process platform webhook callback")
    public ResponseEntity<OnboardingResponse> webhook(@PathVariable String requestId, @RequestBody WebhookCallbackRequest cb,
            @RequestHeader(value = "X-IPP-Signature", required = false) String sig) {
        return ResponseEntity.ok(service.processWebhook(requestId, cb));
    }
}
