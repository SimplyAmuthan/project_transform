package com.usbank.ipp.onboarding.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.ipp.onboarding.security.HmacSignatureService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import java.time.Duration;
import java.util.Map;

@Service @RequiredArgsConstructor @Slf4j
public class PlatformCallService {
    private final WebClient.Builder webClientBuilder;
    private final HmacSignatureService hmacService;
    private final ObjectMapper objectMapper;
    @Value("${ipp.onboarding.parallel-timeout-seconds:30}") private int timeoutSeconds;

    @Data @Builder @AllArgsConstructor @NoArgsConstructor
    public static class CallResult { private boolean success; private String externalOnboardingId; private String error; }

    @CircuitBreaker(name = "platformOnboarding", fallbackMethod = "fallback")
    @Retry(name = "platformOnboarding")
    public CallResult callPlatform(String endpoint, Map<String, Object> payload, String hmacSecret, String requestId) {
        if (endpoint == null || endpoint.isBlank()) {
            return CallResult.builder().success(true).externalOnboardingId("sim-" + requestId).build();
        }
        try {
            String json = objectMapper.writeValueAsString(payload);
            String sig = hmacService.sign(json, hmacSecret != null ? hmacSecret : "default-secret");
            Map<?,?> resp = webClientBuilder.build().post().uri(endpoint)
                    .contentType(MediaType.APPLICATION_JSON).header("X-IPP-Signature", sig).header("X-IPP-Request-Id", requestId)
                    .bodyValue(payload).retrieve().bodyToMono(Map.class).timeout(Duration.ofSeconds(timeoutSeconds)).block();
            String extId = resp != null && resp.containsKey("onboardingId") ? resp.get("onboardingId").toString() : "ext-" + requestId;
            return CallResult.builder().success(true).externalOnboardingId(extId).build();
        } catch (Exception e) {
            log.error("Platform call failed: {}", e.getMessage());
            return CallResult.builder().success(false).error(e.getMessage()).build();
        }
    }

    @SuppressWarnings("unused")
    private CallResult fallback(String endpoint, Map<String, Object> payload, String hmacSecret, String requestId, Throwable t) {
        return CallResult.builder().success(false).error("Circuit breaker open: " + t.getMessage()).build();
    }
}
