package com.usbank.ipp.onboarding.client;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import java.time.Duration;
import java.util.Map;

@Component @RequiredArgsConstructor @Slf4j
public class PlatformRegistryClient {
    private final WebClient.Builder webClientBuilder;
    @Value("${ipp.registry.base-url}") private String registryBaseUrl;

    @CircuitBreaker(name = "registryClient")
    @Cacheable(value = "onboardingConfig", key = "#platformSlug")
    public Map<String, Object> getOnboardingConfig(String platformSlug) {
        log.info("Fetching platform config from registry: {}", platformSlug);
        return webClientBuilder.build().get()
                .uri(registryBaseUrl + "/api/v1/platforms/slug/{slug}/onboarding-config", platformSlug)
                .retrieve().bodyToMono(Map.class).timeout(Duration.ofSeconds(10)).block();
    }

    @CircuitBreaker(name = "registryClient")
    @Cacheable(value = "capabilitySchema", key = "#platformSlug + ':' + #capabilitySlug")
    public Map<String, Object> getCapabilityOnboardingSchema(String platformSlug, String capabilitySlug) {
        log.info("Fetching capability schema from registry: {}/{}", platformSlug, capabilitySlug);
        return webClientBuilder.build().get()
                .uri(registryBaseUrl + "/api/v1/platforms/slug/{pSlug}/capabilities/{cSlug}/onboarding-schema", platformSlug, capabilitySlug)
                .retrieve().bodyToMono(Map.class).timeout(Duration.ofSeconds(10)).block();
    }
}
