package com.usbank.ipp.onboarding.event;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service @RequiredArgsConstructor @Slf4j
public class EventPublisher {
    private final KafkaTemplate<String, OnboardingEvent> kafkaTemplate;
    @Value("${ipp.kafka.topics.onboarding-status}") private String topic;

    @Async public void publish(OnboardingEvent event) {
        log.info("Publishing: type={}, correlationId={}", event.getEventType(), event.getCorrelationId());
        kafkaTemplate.send(topic, event.getCorrelationId(), event);
    }
}
