package com.usbank.ipp.onboarding.dto;
import lombok.*;
import java.util.Map;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class WebhookCallbackRequest {
    private String onboardingId;
    private String platformSlug;
    private String status;
    private Map<String, Object> credentials;
    private String error;
}
