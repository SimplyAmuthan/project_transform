package com.usbank.ipp.onboarding.security;
import org.apache.commons.codec.digest.HmacUtils;
import org.springframework.stereotype.Component;
import java.security.MessageDigest;

@Component
public class HmacSignatureService {
    public String sign(String payload, String secret) { return "sha256=" + HmacUtils.hmacSha256Hex(secret, payload); }
    public boolean verify(String payload, String signature, String secret) {
        if (signature == null || secret == null) return false;
        return MessageDigest.isEqual(sign(payload, secret).getBytes(), signature.getBytes());
    }
}
