package com.usbank.ipp.onboarding.dto;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor
public class RejectionRequest { private String rejectedBy; @NotBlank private String reason; }
