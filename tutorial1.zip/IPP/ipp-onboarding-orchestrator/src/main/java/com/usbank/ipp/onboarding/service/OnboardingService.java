package com.usbank.ipp.onboarding.service;

import com.usbank.ipp.onboarding.client.PlatformRegistryClient;
import com.usbank.ipp.onboarding.dto.*;
import com.usbank.ipp.onboarding.dto.OnboardingSubmitRequest.*;
import com.usbank.ipp.onboarding.event.*;
import com.usbank.ipp.onboarding.exception.*;
import com.usbank.ipp.onboarding.model.OnboardingRequest;
import com.usbank.ipp.onboarding.model.OnboardingRequest.*;
import com.usbank.ipp.onboarding.repository.OnboardingRequestRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

@Service @RequiredArgsConstructor @Slf4j
public class OnboardingService {
    private final OnboardingRequestRepository repo;
    private final PlatformRegistryClient registryClient;
    private final SchemaValidationService schemaValidator;
    private final PlatformCallService callService;
    private final EventPublisher eventPublisher;

    public OnboardingResponse submit(OnboardingSubmitRequest req) {
        log.info("Submitting onboarding: appId={}, platforms={}", req.getApplicationId(), req.getPlatforms().size());

        Map<String, Map<String, Object>> platformConfigs = new LinkedHashMap<>();
        Map<String, String> allErrors = new LinkedHashMap<>();
        boolean anyManualApproval = false;

        for (var platformEntry : req.getPlatforms()) {
            String pSlug = platformEntry.getPlatformSlug();

            // 1. Fetch platform-level config (endpoint, HMAC, selfService)
            Map<String, Object> config = registryClient.getOnboardingConfig(pSlug);
            platformConfigs.put(pSlug, config);
            if (config != null && Boolean.FALSE.equals(config.get("selfServiceEnabled"))) anyManualApproval = true;

            // 2. Validate EACH capability's payload against ITS onboarding JSON Schema
            for (var capEntry : platformEntry.getCapabilities()) {
                String cSlug = capEntry.getCapabilitySlug();
                Map<String, Object> schema = registryClient.getCapabilityOnboardingSchema(pSlug, cSlug);
                Map<String, String> errors = schemaValidator.validate(
                        capEntry.getOnboardingPayload(), schema, pSlug + "/" + cSlug);
                allErrors.putAll(errors);
            }
        }

        if (!allErrors.isEmpty()) throw new ValidationException("Onboarding payload validation failed", allErrors);

        // 3. Persist
        String requestId = UUID.randomUUID().toString();
        List<PlatformOnboarding> platforms = req.getPlatforms().stream().map(pe -> PlatformOnboarding.builder()
                .platformSlug(pe.getPlatformSlug())
                .capabilities(pe.getCapabilities().stream().map(ce -> CapabilityOnboarding.builder()
                        .capabilitySlug(ce.getCapabilitySlug())
                        .onboardingPayload(ce.getOnboardingPayload()).build()).toList())
                .status(PlatformStatus.PENDING).build()).toList();

        var onboardingReq = OnboardingRequest.builder().requestId(requestId)
                .applicationId(req.getApplicationId()).applicationName(req.getApplicationName())
                .businessLine(req.getBusinessLine()).environment(req.getEnvironment())
                .requestedBy(req.getRequestedBy() != null ? req.getRequestedBy() : "system")
                .status(anyManualApproval ? RequestStatus.PENDING_APPROVAL : RequestStatus.PENDING)
                .platforms(new ArrayList<>(platforms)).metadata(req.getMetadata()).build();

        onboardingReq = repo.save(onboardingReq);

        eventPublisher.publish(OnboardingEvent.builder().eventType("ONBOARDING_INITIATED").correlationId(requestId)
                .payload(Map.of("requestId", requestId, "applicationId", req.getApplicationId())).build());

        if (!anyManualApproval) executePlatformCalls(onboardingReq, platformConfigs);

        return OnboardingResponse.from(repo.findByRequestId(requestId).orElse(onboardingReq));
    }

    @Async
    public void executePlatformCalls(OnboardingRequest request, Map<String, Map<String, Object>> configs) {
        request.setStatus(RequestStatus.IN_PROGRESS);
        ExecutorService exec = Executors.newFixedThreadPool(Math.min(configs.size(), 5));
        Map<String, Future<PlatformCallService.CallResult>> futures = new LinkedHashMap<>();

        for (var p : request.getPlatforms()) {
            var config = configs.get(p.getPlatformSlug());
            p.setStatus(PlatformStatus.IN_PROGRESS); p.setStartedAt(Instant.now());
            String endpoint = config != null ? (String) config.get("onboardingEndpoint") : null;
            String hmac = config != null ? (String) config.get("hmacSecretRef") : null;
            // Merge all capability payloads into a single platform call payload
            Map<String, Object> mergedPayload = new LinkedHashMap<>();
            mergedPayload.put("applicationId", request.getApplicationId());
            mergedPayload.put("environment", request.getEnvironment());
            List<Map<String, Object>> capPayloads = new ArrayList<>();
            for (var cap : p.getCapabilities()) {
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("capabilitySlug", cap.getCapabilitySlug());
                entry.put("onboardingPayload", cap.getOnboardingPayload());
                capPayloads.add(entry);
            }
            mergedPayload.put("capabilities", capPayloads);
            futures.put(p.getPlatformSlug(), exec.submit(() -> callService.callPlatform(endpoint, mergedPayload, hmac, request.getRequestId())));
        }
        repo.save(request);

        for (var entry : futures.entrySet()) {
            var platform = request.getPlatforms().stream().filter(p -> p.getPlatformSlug().equals(entry.getKey())).findFirst().orElse(null);
            if (platform == null) continue;
            try {
                var result = entry.getValue().get(35, TimeUnit.SECONDS);
                if (result.isSuccess()) {
                    platform.setStatus(PlatformStatus.COMPLETED); platform.setExternalOnboardingId(result.getExternalOnboardingId());
                    platform.setCompletedAt(Instant.now());
                    platform.setCredentials(Map.of("clientId", "ipp-" + request.getApplicationId() + "-" + entry.getKey(),
                            "clientSecretRef", "vault:secrets/ipp/" + request.getApplicationId() + "/" + entry.getKey()));
                } else { platform.setStatus(PlatformStatus.FAILED); platform.setError(result.getError()); }
            } catch (Exception e) { platform.setStatus(PlatformStatus.FAILED); platform.setError(e.getMessage()); }
        }
        exec.shutdown();

        boolean allOk = request.getPlatforms().stream().allMatch(p -> p.getStatus() == PlatformStatus.COMPLETED);
        request.setStatus(allOk ? RequestStatus.COMPLETED : RequestStatus.FAILED);
        repo.save(request);
        if (allOk) eventPublisher.publish(OnboardingEvent.builder().eventType("ONBOARDING_COMPLETED").correlationId(request.getRequestId())
                .payload(Map.of("requestId", request.getRequestId(), "applicationId", request.getApplicationId())).build());
    }

    public OnboardingResponse getRequest(String requestId) {
        return OnboardingResponse.from(repo.findByRequestId(requestId).orElseThrow(() -> new ResourceNotFoundException("Not found: " + requestId)));
    }

    public Page<OnboardingResponse> listByApp(String appId, String status, int page, int size) {
        var pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return (status != null ? repo.findByApplicationIdAndStatus(appId, RequestStatus.valueOf(status), pageable) : repo.findByApplicationId(appId, pageable)).map(OnboardingResponse::from);
    }

    public OnboardingResponse approve(String requestId, ApprovalRequest approval) {
        var req = repo.findByRequestId(requestId).orElseThrow(() -> new ResourceNotFoundException("Not found: " + requestId));
        if (req.getStatus() != RequestStatus.PENDING_APPROVAL) throw new InvalidOperationException("Not pending approval: " + req.getStatus());
        req.setStatus(RequestStatus.PENDING);
        Map<String, Map<String, Object>> configs = new LinkedHashMap<>();
        for (var p : req.getPlatforms()) configs.put(p.getPlatformSlug(), registryClient.getOnboardingConfig(p.getPlatformSlug()));
        repo.save(req); executePlatformCalls(req, configs);
        return OnboardingResponse.from(repo.findByRequestId(requestId).orElse(req));
    }

    public OnboardingResponse reject(String requestId, RejectionRequest rejection) {
        var req = repo.findByRequestId(requestId).orElseThrow(() -> new ResourceNotFoundException("Not found: " + requestId));
        if (req.getStatus() != RequestStatus.PENDING_APPROVAL && req.getStatus() != RequestStatus.PENDING) throw new InvalidOperationException("Cannot reject: " + req.getStatus());
        req.setStatus(RequestStatus.REJECTED);
        req.getPlatforms().forEach(p -> { p.setStatus(PlatformStatus.FAILED); p.setError("Rejected: " + rejection.getReason()); });
        return OnboardingResponse.from(repo.save(req));
    }

    public void cancel(String requestId) {
        var req = repo.findByRequestId(requestId).orElseThrow(() -> new ResourceNotFoundException("Not found: " + requestId));
        if (req.getStatus() == RequestStatus.COMPLETED) throw new InvalidOperationException("Cannot cancel completed request");
        req.setStatus(RequestStatus.CANCELLED); repo.save(req);
    }

    public Map<String, Object> getCapabilitySchema(String platformSlug, String capabilitySlug) {
        return registryClient.getCapabilityOnboardingSchema(platformSlug, capabilitySlug);
    }

    public OnboardingResponse processWebhook(String requestId, WebhookCallbackRequest cb) {
        var req = repo.findByRequestId(requestId).orElseThrow(() -> new ResourceNotFoundException("Not found: " + requestId));
        var platform = req.getPlatforms().stream().filter(p -> p.getPlatformSlug().equals(cb.getPlatformSlug())).findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Platform not in request: " + cb.getPlatformSlug()));
        if ("COMPLETED".equals(cb.getStatus())) {
            platform.setStatus(PlatformStatus.COMPLETED); platform.setCompletedAt(Instant.now());
            platform.setExternalOnboardingId(cb.getOnboardingId());
            if (cb.getCredentials() != null) platform.setCredentials(cb.getCredentials());
        } else { platform.setStatus(PlatformStatus.FAILED); platform.setError(cb.getError()); }
        boolean allDone = req.getPlatforms().stream().allMatch(p -> p.getStatus() == PlatformStatus.COMPLETED || p.getStatus() == PlatformStatus.FAILED);
        if (allDone) { boolean allOk = req.getPlatforms().stream().allMatch(p -> p.getStatus() == PlatformStatus.COMPLETED); req.setStatus(allOk ? RequestStatus.COMPLETED : RequestStatus.FAILED); }
        return OnboardingResponse.from(repo.save(req));
    }
}
