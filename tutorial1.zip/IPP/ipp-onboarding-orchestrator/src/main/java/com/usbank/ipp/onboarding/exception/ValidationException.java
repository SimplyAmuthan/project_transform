package com.usbank.ipp.onboarding.exception;
import java.util.Map;
import lombok.Getter;
@Getter
public class ValidationException extends RuntimeException {
    private final Map<String, String> errors;
    public ValidationException(String m, Map<String, String> errors) { super(m); this.errors = errors; }
}
