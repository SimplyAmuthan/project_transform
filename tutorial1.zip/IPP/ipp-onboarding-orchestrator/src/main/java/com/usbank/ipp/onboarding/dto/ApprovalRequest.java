package com.usbank.ipp.onboarding.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor
public class ApprovalRequest { private String approvedBy; private String comments; }
