package com.usbank.ipp.onboarding.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.*;
import java.util.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OnboardingSubmitRequest {
    @NotBlank private String applicationId;
    @NotBlank private String applicationName;
    @NotBlank private String businessLine;
    @NotBlank private String environment;
    private String requestedBy;
    @NotEmpty @Valid private List<PlatformEntry> platforms;
    private Map<String, Object> metadata;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PlatformEntry {
        @NotBlank private String platformSlug;
        @NotEmpty @Valid private List<CapabilityEntry> capabilities;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class CapabilityEntry {
        @NotBlank private String capabilitySlug;
        private Map<String, Object> onboardingPayload; // Validated against this capability's JSON Schema
    }
}
