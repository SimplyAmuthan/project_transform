package com.usbank.ipp.onboarding.dto;

import com.usbank.ipp.onboarding.model.OnboardingRequest;
import lombok.*;
import java.time.Instant;
import java.util.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OnboardingResponse {
    private String requestId; private String applicationId; private String applicationName;
    private String businessLine; private String environment; private String requestedBy;
    private OnboardingRequest.RequestStatus status;
    private List<OnboardingRequest.PlatformOnboarding> platforms;
    private Map<String, Object> metadata;
    private Instant createdAt; private Instant updatedAt;

    public static OnboardingResponse from(OnboardingRequest r) {
        return OnboardingResponse.builder().requestId(r.getRequestId()).applicationId(r.getApplicationId())
                .applicationName(r.getApplicationName()).businessLine(r.getBusinessLine())
                .environment(r.getEnvironment()).requestedBy(r.getRequestedBy()).status(r.getStatus())
                .platforms(r.getPlatforms()).metadata(r.getMetadata())
                .createdAt(r.getCreatedAt()).updatedAt(r.getUpdatedAt()).build();
    }
}
