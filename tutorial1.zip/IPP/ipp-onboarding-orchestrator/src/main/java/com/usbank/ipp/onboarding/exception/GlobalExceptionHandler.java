package com.usbank.ipp.onboarding.exception;
import org.springframework.http.*;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.*;
import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice @Slf4j
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handle(ResourceNotFoundException ex) {
        return ResponseEntity.status(404).body(Map.of("error","NOT_FOUND","message",ex.getMessage(),"timestamp",Instant.now().toString()));
    }
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<Map<String, Object>> handle(ValidationException ex) {
        return ResponseEntity.badRequest().body(Map.of("error","VALIDATION_FAILED","message",ex.getMessage(),"fieldErrors",ex.getErrors(),"timestamp",Instant.now().toString()));
    }
    @ExceptionHandler(InvalidOperationException.class)
    public ResponseEntity<Map<String, Object>> handle(InvalidOperationException ex) {
        return ResponseEntity.status(409).body(Map.of("error","INVALID_OPERATION","message",ex.getMessage(),"timestamp",Instant.now().toString()));
    }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handle(MethodArgumentNotValidException ex) {
        Map<String,String> errs = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(e -> errs.put(e instanceof FieldError f ? f.getField() : e.getObjectName(), e.getDefaultMessage()));
        return ResponseEntity.badRequest().body(Map.of("error","VALIDATION_FAILED","fieldErrors",errs,"timestamp",Instant.now().toString()));
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handle(Exception ex) {
        log.error("Unhandled", ex);
        return ResponseEntity.status(500).body(Map.of("error","INTERNAL_ERROR","message","An unexpected error occurred","timestamp",Instant.now().toString()));
    }
}
