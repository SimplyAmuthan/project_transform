package com.usbank.ipp.onboarding.event;
import lombok.*;
import java.time.*;
import java.util.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OnboardingEvent {
    @Builder.Default private String eventId = UUID.randomUUID().toString();
    private String eventType;
    @Builder.Default private Instant timestamp = Instant.now();
    @Builder.Default private String source = "onboarding-orchestrator";
    private String correlationId;
    private Map<String, Object> payload;
}
