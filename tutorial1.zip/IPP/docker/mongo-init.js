db = db.getSiblingDB('ipp_registry');
db.createCollection('platforms');
db.createCollection('capabilities');

db = db.getSiblingDB('ipp_onboarding');
db.createCollection('onboarding_requests');

print('IPP databases initialized (indexes managed by Spring Data)');
