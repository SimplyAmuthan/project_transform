# IPP Onboarding Orchestrator Service

A Spring Boot microservice that manages end-to-end onboarding of business-line applications to internal banking platforms. Part of the Internal Platforms Portal (IPP).

## Architecture

```
┌─────────────────────────────────────────────────────┐
│              Onboarding Orchestrator                │
│                                                     │
│  ┌──────────┐  ┌──────────┐  ┌───────────────────┐  │
│  │Controller│→ │ Service  │→ │PlatformCallService│  │
│  └──────────┘  └────┬─────┘  └───────────────────┘  │
│                     │                               │
│  ┌──────────┐  ┌────┴─────┐  ┌───────────────────┐  │
│  │Validator │  │EventPubl.│→ │   Apache Kafka    │  │
│  └──────────┘  └──────────┘  └───────────────────┘  │
│                     │                               │
│               ┌─────┴──────┐                        │
│               │  MongoDB   │                        │
│               └────────────┘                        │
└─────────────────────────────────────────────────────┘
```

## Tech Stack

| Component       | Technology              |
|-----------------|-------------------------|
| Framework       | Spring Boot 3.3, Java 21|
| Database        | MongoDB 7.0             |
| Cache           | Redis 7                 |
| Message Broker  | Apache Kafka            |
| Resilience      | Resilience4j            |
| HTTP Client     | Spring WebFlux WebClient|
| Signing         | HMAC-SHA256             |
| API Docs        | SpringDoc OpenAPI 3     |
| Metrics         | Micrometer + Prometheus |

## Quick Start

### Prerequisites
- Docker & Docker Compose
- (Optional) Java 21 + Maven for local development

### 1. Start All Services

```bash
docker-compose up -d
```

This starts:
- **Onboarding Orchestrator** → http://localhost:8080
- **MongoDB** → localhost:27017
- **Redis** → localhost:6379
- **Kafka** → localhost:9092
- **Kafka UI** → http://localhost:9091
- **Mongo Express** → http://localhost:8081

### 2. Verify Health

```bash
curl http://localhost:8080/actuator/health
```

### 3. Explore the API

- **Swagger UI**: http://localhost:8080/swagger-ui.html
- **OpenAPI Spec**: http://localhost:8080/api-docs

### 4. Import Postman Collection

Import `IPP_Onboarding_Orchestrator.postman_collection.json` into Postman and run requests in order.

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST   | `/api/v1/onboarding/requests` | Submit multi-platform onboarding request |
| GET    | `/api/v1/onboarding/requests/{id}` | Get request status |
| GET    | `/api/v1/onboarding/requests?appId=` | List requests by app |
| POST   | `/api/v1/onboarding/requests/{id}/approve` | Approve pending request |
| POST   | `/api/v1/onboarding/requests/{id}/reject` | Reject pending request |
| DELETE | `/api/v1/onboarding/requests/{id}` | Cancel request |
| GET    | `/api/v1/onboarding/schema/{platformSlug}` | Get platform onboarding schema |
| POST   | `/api/v1/onboarding/requests/{id}/webhook` | Process platform webhook |

## Seeded Platform Configurations

The service auto-seeds configurations for all 7 internal platforms on first startup:

| Platform | Self-Service | Key Required Fields |
|----------|-------------|---------------------|
| Authentication | ✅ Yes | appId, environment, callbackUrls, scopes |
| Connected Finance | ✅ Yes | appId, environment, accountTypes |
| Customer Acquisition | ✅ Yes | appId, environment, productType |
| Customer Engagement | ✅ Yes | appId, environment, channels |
| Document Management | ❌ No (needs approval) | appId, environment, allowedDocTypes, maxFileSizeMb, retentionPolicy |
| Digital Experience | ✅ Yes | appId, environment |
| Money Hub | ❌ No (needs approval) | appId, environment, paymentTypes, dailyTransactionLimit, complianceLevel |

## Local Development (without Docker)

```bash
# Start dependencies
docker-compose up -d mongodb redis kafka zookeeper

# Run the application
./mvnw spring-boot:run
```

## Monitoring

- **Kafka UI**: http://localhost:9091 — View topics, messages, consumer groups
- **Mongo Express**: http://localhost:8081 — Browse MongoDB collections
- **Prometheus Metrics**: http://localhost:8080/actuator/prometheus
- **Health Check**: http://localhost:8080/actuator/health
