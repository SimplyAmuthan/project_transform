// MongoDB initialization script for IPP Onboarding Orchestrator
db = db.getSiblingDB('ipp_onboarding');

db.createCollection('onboarding_requests');
db.createCollection('platform_configs');

// Indexes for onboarding_requests
db.onboarding_requests.createIndex({ "requestId": 1 }, { unique: true });
db.onboarding_requests.createIndex({ "applicationId": 1, "status": 1 });
db.onboarding_requests.createIndex({ "requestedBy": 1 });
db.onboarding_requests.createIndex({ "createdAt": -1 });
db.onboarding_requests.createIndex({ "status": 1 });

// Indexes for platform_configs
db.platform_configs.createIndex({ "platformSlug": 1 }, { unique: true });

print('IPP Onboarding database initialized successfully');
