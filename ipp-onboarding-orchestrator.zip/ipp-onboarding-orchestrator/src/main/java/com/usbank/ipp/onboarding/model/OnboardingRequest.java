package com.usbank.ipp.onboarding.model;

import lombok.*;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Document(collection = "onboarding_requests")
@CompoundIndex(name = "idx_appId_status", def = "{'applicationId': 1, 'status': 1}")
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OnboardingRequest {

    @Id
    private String id;

    @Indexed(unique = true)
    private String requestId;

    @Indexed
    private String applicationId;
    private String applicationName;
    private String businessLine;
    private String environment; // DEV, QA, STAGING, PROD
    private String requestedBy;

    @Indexed
    private RequestStatus status;

    private List<PlatformOnboarding> platforms;
    private RequestMetadata metadata;

    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;

    // --- Nested types ---

    public enum RequestStatus {
        PENDING, PENDING_APPROVAL, IN_PROGRESS, COMPLETED, FAILED, CANCELLED, REJECTED
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PlatformOnboarding {
        private String platformSlug;
        private List<String> capabilitySlugs;
        private Map<String, Object> onboardingPayload;
        private PlatformStatus status;
        private String externalOnboardingId;
        private PlatformCredentials credentials;
        private String error;
        private String rejectionReason;
        private Instant startedAt;
        private Instant completedAt;
    }

    public enum PlatformStatus {
        PENDING, IN_PROGRESS, COMPLETED, FAILED
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PlatformCredentials {
        private String clientId;
        private String clientSecretRef; // Vault reference
        private String apiKeyRef;       // Vault reference
        private Map<String, Object> additionalConfig;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class RequestMetadata {
        private String projectCode;
        private String costCenter;
        private String targetGoLiveDate;
    }
}
