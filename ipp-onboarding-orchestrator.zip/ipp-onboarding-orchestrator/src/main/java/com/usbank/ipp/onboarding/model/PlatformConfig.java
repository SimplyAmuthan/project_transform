package com.usbank.ipp.onboarding.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.Map;

@Document(collection = "platform_configs")
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class PlatformConfig {

    @Id
    private String id;

    @Indexed(unique = true)
    private String platformSlug;

    private String name;
    private boolean selfServiceEnabled;
    private String onboardingEndpoint;
    private String webhookUrl;
    private String hmacSecretRef; // Vault reference or plain for local dev
    private List<OnboardingField> requiredFields;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class OnboardingField {
        private String field;
        private String type;       // string, number, boolean, enum, array, object
        private boolean required;
        private String description;
        private List<String> values;    // for enum type
        private String itemType;        // for array type
        private Map<String, Object> schema; // for object type
    }
}
