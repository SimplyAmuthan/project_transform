package com.usbank.ipp.onboarding.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("IPP Onboarding Orchestrator API")
                        .version("1.0.0")
                        .description("Manages end-to-end onboarding of business-line applications to internal platforms. " +
                                "Supports multi-platform parallel onboarding with platform-specific payload validation, " +
                                "HMAC-signed webhook callbacks, and comprehensive status tracking.")
                        .contact(new Contact()
                                .name("IPP Platform Engineering")
                                .email("ipp-platform@usbank.com"))
                        .license(new License()
                                .name("Internal Use Only")));
    }
}
