package com.usbank.ipp.onboarding.event;

import lombok.*;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OnboardingEvent {
    @Builder.Default
    private String eventId = UUID.randomUUID().toString();
    private String eventType;
    @Builder.Default
    private Instant timestamp = Instant.now();
    private String source;
    private String correlationId;
    private Map<String, Object> payload;

    public static OnboardingEvent initiated(String requestId, String appId, List<String> platforms, String requestedBy) {
        return OnboardingEvent.builder()
                .eventType("ONBOARDING_INITIATED")
                .source("onboarding-orchestrator")
                .correlationId(requestId)
                .payload(Map.of(
                        "requestId", requestId,
                        "applicationId", appId,
                        "platforms", platforms,
                        "requestedBy", requestedBy
                )).build();
    }

    public static OnboardingEvent platformCompleted(String requestId, String platformSlug, String appId) {
        return OnboardingEvent.builder()
                .eventType("PLATFORM_ONBOARDING_COMPLETED")
                .source("onboarding-orchestrator")
                .correlationId(requestId)
                .payload(Map.of(
                        "requestId", requestId,
                        "platformSlug", platformSlug,
                        "applicationId", appId
                )).build();
    }

    public static OnboardingEvent platformFailed(String requestId, String platformSlug, String error) {
        return OnboardingEvent.builder()
                .eventType("PLATFORM_ONBOARDING_FAILED")
                .source("onboarding-orchestrator")
                .correlationId(requestId)
                .payload(Map.of(
                        "requestId", requestId,
                        "platformSlug", platformSlug,
                        "error", error
                )).build();
    }

    public static OnboardingEvent completed(String requestId, String appId) {
        return OnboardingEvent.builder()
                .eventType("ONBOARDING_COMPLETED")
                .source("onboarding-orchestrator")
                .correlationId(requestId)
                .payload(Map.of(
                        "requestId", requestId,
                        "applicationId", appId
                )).build();
    }

    public static OnboardingEvent cancelled(String requestId, String cancelledBy) {
        return OnboardingEvent.builder()
                .eventType("ONBOARDING_CANCELLED")
                .source("onboarding-orchestrator")
                .correlationId(requestId)
                .payload(Map.of("requestId", requestId, "cancelledBy", cancelledBy))
                .build();
    }
}
