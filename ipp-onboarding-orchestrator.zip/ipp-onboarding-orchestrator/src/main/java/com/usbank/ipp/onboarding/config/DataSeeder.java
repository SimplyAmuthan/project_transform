package com.usbank.ipp.onboarding.config;

import com.usbank.ipp.onboarding.model.PlatformConfig;
import com.usbank.ipp.onboarding.model.PlatformConfig.OnboardingField;
import com.usbank.ipp.onboarding.repository.PlatformConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
@org.springframework.boot.autoconfigure.condition.ConditionalOnProperty(
        name = "ipp.onboarding.seed-platforms",
        havingValue = "true",
        matchIfMissing = true
)
public class DataSeeder implements CommandLineRunner {

    private final PlatformConfigRepository repo;

    @Override
    public void run(String... args) {
        if (repo.count() > 0) {
            log.info("Platform configs already seeded ({} found), skipping", repo.count());
            return;
        }
        log.info("Seeding platform configurations for 7 internal platforms...");

        repo.saveAll(List.of(
            PlatformConfig.builder()
                .platformSlug("authentication")
                .name("Authentication Platform")
                .selfServiceEnabled(true)
                .onboardingEndpoint(null) // null = simulate locally
                .webhookUrl("http://localhost:8080/api/v1/onboarding/requests/{requestId}/webhook")
                .hmacSecretRef("auth-hmac-secret-2026")
                .requiredFields(List.of(
                    field("appId", "string", true, "Application identifier"),
                    field("environment", "enum", true, "Target environment", List.of("DEV", "QA", "STAGING", "PROD")),
                    field("callbackUrls", "array", true, "OAuth callback URLs"),
                    field("scopes", "array", true, "Requested OAuth scopes"),
                    field("mfaPolicy", "object", false, "MFA configuration")
                )).build(),

            PlatformConfig.builder()
                .platformSlug("connected-finance")
                .name("Connected Finance Platform")
                .selfServiceEnabled(true)
                .onboardingEndpoint(null)
                .hmacSecretRef("cf-hmac-secret-2026")
                .requiredFields(List.of(
                    field("appId", "string", true, "Application identifier"),
                    field("environment", "enum", true, "Target environment", List.of("DEV", "QA", "STAGING", "PROD")),
                    field("accountTypes", "array", true, "Account types to access"),
                    field("dataRetentionDays", "number", false, "Data retention period in days"),
                    field("webhookUrl", "string", false, "Webhook URL for notifications")
                )).build(),

            PlatformConfig.builder()
                .platformSlug("customer-acquisition")
                .name("Customer Acquisition Platform")
                .selfServiceEnabled(true)
                .onboardingEndpoint(null)
                .hmacSecretRef("ca-hmac-secret-2026")
                .requiredFields(List.of(
                    field("appId", "string", true, "Application identifier"),
                    field("environment", "enum", true, "Target environment", List.of("DEV", "QA", "STAGING", "PROD")),
                    field("productType", "enum", true, "Product type", List.of("CREDIT_CARD", "CHECKING", "SAVINGS", "LOAN", "MORTGAGE")),
                    field("kycLevel", "enum", false, "KYC verification level", List.of("BASIC", "ENHANCED", "FULL"))
                )).build(),

            PlatformConfig.builder()
                .platformSlug("customer-engagement")
                .name("Customer Engagement Platform")
                .selfServiceEnabled(true)
                .onboardingEndpoint(null)
                .hmacSecretRef("ce-hmac-secret-2026")
                .requiredFields(List.of(
                    field("appId", "string", true, "Application identifier"),
                    field("environment", "enum", true, "Target environment", List.of("DEV", "QA", "STAGING", "PROD")),
                    field("channels", "array", true, "Communication channels (push, email, sms, in-app)"),
                    field("personalizationEnabled", "boolean", false, "Enable personalization engine")
                )).build(),

            PlatformConfig.builder()
                .platformSlug("document-management")
                .name("Document Management Platform")
                .selfServiceEnabled(false) // requires manual approval
                .onboardingEndpoint(null)
                .hmacSecretRef("dm-hmac-secret-2026")
                .requiredFields(List.of(
                    field("appId", "string", true, "Application identifier"),
                    field("environment", "enum", true, "Target environment", List.of("DEV", "QA", "STAGING", "PROD")),
                    field("allowedDocTypes", "array", true, "Allowed document types"),
                    field("maxFileSizeMb", "number", true, "Maximum file size in MB"),
                    field("retentionPolicy", "enum", true, "Document retention policy", List.of("1_YEAR", "3_YEARS", "7_YEARS", "PERMANENT"))
                )).build(),

            PlatformConfig.builder()
                .platformSlug("digital-experience")
                .name("Digital Experience Platform")
                .selfServiceEnabled(true)
                .onboardingEndpoint(null)
                .hmacSecretRef("dx-hmac-secret-2026")
                .requiredFields(List.of(
                    field("appId", "string", true, "Application identifier"),
                    field("environment", "enum", true, "Target environment", List.of("DEV", "QA", "STAGING", "PROD")),
                    field("featureFlagsEnabled", "boolean", false, "Enable feature flag service"),
                    field("abTestingEnabled", "boolean", false, "Enable A/B testing")
                )).build(),

            PlatformConfig.builder()
                .platformSlug("money-hub")
                .name("Money Hub Platform")
                .selfServiceEnabled(false) // requires manual approval (payment platform)
                .onboardingEndpoint(null)
                .hmacSecretRef("mh-hmac-secret-2026")
                .requiredFields(List.of(
                    field("appId", "string", true, "Application identifier"),
                    field("environment", "enum", true, "Target environment", List.of("DEV", "QA", "STAGING", "PROD")),
                    field("paymentTypes", "array", true, "Payment types (ACH, WIRE, P2P, BILL_PAY)"),
                    field("dailyTransactionLimit", "number", true, "Daily transaction limit in USD"),
                    field("complianceLevel", "enum", true, "Compliance level", List.of("STANDARD", "ENHANCED", "PCI_FULL"))
                )).build()
        ));

        log.info("Seeded 7 platform configurations successfully");
    }

    private static OnboardingField field(String name, String type, boolean required, String desc) {
        return OnboardingField.builder().field(name).type(type).required(required).description(desc).build();
    }

    private static OnboardingField field(String name, String type, boolean required, String desc, List<String> values) {
        return OnboardingField.builder().field(name).type(type).required(required).description(desc).values(values).build();
    }
}
