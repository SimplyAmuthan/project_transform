package com.usbank.ipp.onboarding.exception;

public class InvalidOperationException extends RuntimeException {
    public InvalidOperationException(String message) { super(message); }
}
