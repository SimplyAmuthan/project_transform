package com.usbank.ipp.onboarding.dto.request;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class ApprovalRequest {
    private String approvedBy;
    private String comments;
}
