package com.usbank.ipp.onboarding.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.ipp.onboarding.model.PlatformConfig;
import com.usbank.ipp.onboarding.security.HmacSignatureService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class PlatformCallService {

    private final WebClient.Builder webClientBuilder;
    private final HmacSignatureService hmacService;
    private final ObjectMapper objectMapper;

    @Value("${ipp.onboarding.parallel-timeout-seconds:30}")
    private int timeoutSeconds;

    @Value("${ipp.onboarding.webhook-hmac-header:X-IPP-Signature}")
    private String hmacHeader;

    @Data @Builder @AllArgsConstructor @NoArgsConstructor
    public static class PlatformCallResult {
        private boolean success;
        private String externalOnboardingId;
        private String error;
        private int httpStatus;
    }

    @CircuitBreaker(name = "platformOnboarding", fallbackMethod = "callFallback")
    @Retry(name = "platformOnboarding")
    public PlatformCallResult callPlatformOnboarding(
            PlatformConfig config,
            Map<String, Object> payload,
            String requestId) {

        String endpoint = config.getOnboardingEndpoint();
        if (endpoint == null || endpoint.isBlank()) {
            log.info("No onboarding endpoint for platform {}, simulating success", config.getPlatformSlug());
            return PlatformCallResult.builder()
                    .success(true)
                    .externalOnboardingId("sim-" + requestId + "-" + config.getPlatformSlug())
                    .httpStatus(202)
                    .build();
        }

        try {
            String payloadJson = objectMapper.writeValueAsString(payload);
            String signature = hmacService.sign(payloadJson,
                    config.getHmacSecretRef() != null ? config.getHmacSecretRef() : "default-dev-secret");

            log.info("Calling platform onboarding: platform={}, endpoint={}", config.getPlatformSlug(), endpoint);

            Map<?, ?> response = webClientBuilder.build()
                    .post()
                    .uri(endpoint)
                    .contentType(MediaType.APPLICATION_JSON)
                    .header(hmacHeader, signature)
                    .header("X-IPP-Request-Id", requestId)
                    .bodyValue(payload)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .timeout(Duration.ofSeconds(timeoutSeconds))
                    .block();

            String extId = response != null && response.containsKey("onboardingId")
                    ? response.get("onboardingId").toString()
                    : "ext-" + requestId;

            return PlatformCallResult.builder()
                    .success(true)
                    .externalOnboardingId(extId)
                    .httpStatus(202)
                    .build();

        } catch (JsonProcessingException e) {
            return PlatformCallResult.builder().success(false).error("Payload serialization error: " + e.getMessage()).httpStatus(400).build();
        } catch (Exception e) {
            log.error("Platform call failed: platform={}, error={}", config.getPlatformSlug(), e.getMessage());
            return PlatformCallResult.builder().success(false).error("Platform call failed: " + e.getMessage()).httpStatus(503).build();
        }
    }

    @SuppressWarnings("unused")
    private PlatformCallResult callFallback(PlatformConfig config, Map<String, Object> payload, String requestId, Throwable t) {
        log.warn("Circuit breaker open for platform {}: {}", config.getPlatformSlug(), t.getMessage());
        return PlatformCallResult.builder()
                .success(false)
                .error("Platform temporarily unavailable (circuit breaker open): " + t.getMessage())
                .httpStatus(503)
                .build();
    }
}
