package com.usbank.ipp.onboarding.controller;

import com.usbank.ipp.onboarding.dto.request.*;
import com.usbank.ipp.onboarding.dto.response.OnboardingResponse;
import com.usbank.ipp.onboarding.model.PlatformConfig;
import com.usbank.ipp.onboarding.service.OnboardingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;

@RestController
@RequestMapping("/api/v1/onboarding")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Onboarding Orchestrator", description = "Manage application onboarding to internal platforms")
public class OnboardingController {

    private final OnboardingService onboardingService;

    @PostMapping("/requests")
    @Operation(summary = "Submit onboarding request",
               description = "Submit a new multi-platform onboarding request with platform-specific configurations")
    public ResponseEntity<OnboardingResponse> submitRequest(
            @Valid @RequestBody OnboardingSubmitRequest request) {
        log.info("POST /api/v1/onboarding/requests - appId={}", request.getApplicationId());
        OnboardingResponse response = onboardingService.submitRequest(request);
        return ResponseEntity
                .created(URI.create("/api/v1/onboarding/requests/" + response.getRequestId()))
                .body(response);
    }

    @GetMapping("/requests/{requestId}")
    @Operation(summary = "Get onboarding request status",
               description = "Retrieve the current status of an onboarding request including per-platform progress")
    public ResponseEntity<OnboardingResponse> getRequest(
            @PathVariable String requestId) {
        log.info("GET /api/v1/onboarding/requests/{}", requestId);
        return ResponseEntity.ok(onboardingService.getRequest(requestId));
    }

    @GetMapping("/requests")
    @Operation(summary = "List onboarding requests",
               description = "List onboarding requests filtered by application ID and/or status")
    public ResponseEntity<Page<OnboardingResponse>> listRequests(
            @RequestParam String appId,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        log.info("GET /api/v1/onboarding/requests?appId={}&status={}", appId, status);
        return ResponseEntity.ok(onboardingService.listByApplicationId(appId, status, page, size));
    }

    @PostMapping("/requests/{requestId}/approve")
    @Operation(summary = "Approve pending onboarding request",
               description = "Approve a request that is pending manual approval and trigger platform onboarding")
    public ResponseEntity<OnboardingResponse> approveRequest(
            @PathVariable String requestId,
            @RequestBody(required = false) ApprovalRequest approval) {
        log.info("POST /api/v1/onboarding/requests/{}/approve", requestId);
        if (approval == null) approval = new ApprovalRequest("admin", null);
        return ResponseEntity.ok(onboardingService.approveRequest(requestId, approval));
    }

    @PostMapping("/requests/{requestId}/reject")
    @Operation(summary = "Reject pending onboarding request",
               description = "Reject a pending onboarding request with a reason")
    public ResponseEntity<OnboardingResponse> rejectRequest(
            @PathVariable String requestId,
            @Valid @RequestBody RejectionRequest rejection) {
        log.info("POST /api/v1/onboarding/requests/{}/reject", requestId);
        return ResponseEntity.ok(onboardingService.rejectRequest(requestId, rejection));
    }

    @DeleteMapping("/requests/{requestId}")
    @Operation(summary = "Cancel onboarding request",
               description = "Cancel a pending or in-progress onboarding request")
    public ResponseEntity<Void> cancelRequest(
            @PathVariable String requestId) {
        log.info("DELETE /api/v1/onboarding/requests/{}", requestId);
        onboardingService.cancelRequest(requestId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/schema/{platformSlug}")
    @Operation(summary = "Get platform onboarding schema",
               description = "Retrieve the onboarding payload schema for a specific platform")
    public ResponseEntity<PlatformConfig> getOnboardingSchema(
            @PathVariable String platformSlug) {
        log.info("GET /api/v1/onboarding/schema/{}", platformSlug);
        return ResponseEntity.ok(onboardingService.getOnboardingSchema(platformSlug));
    }

    @PostMapping("/requests/{requestId}/webhook")
    @Operation(summary = "Process platform webhook callback",
               description = "Receive onboarding status updates from platforms via webhook")
    public ResponseEntity<OnboardingResponse> webhookCallback(
            @PathVariable String requestId,
            @RequestBody WebhookCallbackRequest callback,
            @RequestHeader(value = "X-IPP-Signature", required = false) String hmacSignature) {
        log.info("POST /api/v1/onboarding/requests/{}/webhook - platform={}, status={}",
                requestId, callback.getPlatformSlug(), callback.getStatus());
        return ResponseEntity.ok(onboardingService.processWebhookCallback(requestId, callback, hmacSignature));
    }
}
