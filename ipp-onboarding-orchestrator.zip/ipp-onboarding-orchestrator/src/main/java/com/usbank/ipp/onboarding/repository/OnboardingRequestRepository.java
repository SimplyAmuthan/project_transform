package com.usbank.ipp.onboarding.repository;

import com.usbank.ipp.onboarding.model.OnboardingRequest;
import com.usbank.ipp.onboarding.model.OnboardingRequest.RequestStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface OnboardingRequestRepository extends MongoRepository<OnboardingRequest, String> {
    Optional<OnboardingRequest> findByRequestId(String requestId);
    Page<OnboardingRequest> findByApplicationId(String applicationId, Pageable pageable);
    Page<OnboardingRequest> findByApplicationIdAndStatus(String applicationId, RequestStatus status, Pageable pageable);
    Page<OnboardingRequest> findByRequestedBy(String requestedBy, Pageable pageable);
    Page<OnboardingRequest> findByStatus(RequestStatus status, Pageable pageable);
    List<OnboardingRequest> findByStatusIn(List<RequestStatus> statuses);
}
