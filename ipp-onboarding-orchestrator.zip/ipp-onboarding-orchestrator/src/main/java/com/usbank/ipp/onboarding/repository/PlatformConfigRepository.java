package com.usbank.ipp.onboarding.repository;

import com.usbank.ipp.onboarding.model.PlatformConfig;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface PlatformConfigRepository extends MongoRepository<PlatformConfig, String> {
    Optional<PlatformConfig> findByPlatformSlug(String platformSlug);
    boolean existsByPlatformSlug(String platformSlug);
}
