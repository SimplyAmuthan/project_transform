package com.usbank.ipp.onboarding.dto.request;

import lombok.*;
import java.util.Map;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class WebhookCallbackRequest {
    private String onboardingId;
    private String platformSlug;
    private String status; // COMPLETED, FAILED
    private CredentialsPayload credentials;
    private String error;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class CredentialsPayload {
        private String clientId;
        private String clientSecret;
        private String apiKey;
        private Map<String, Object> additionalConfig;
    }
}
