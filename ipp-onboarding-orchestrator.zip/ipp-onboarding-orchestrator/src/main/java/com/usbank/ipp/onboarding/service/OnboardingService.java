package com.usbank.ipp.onboarding.service;

import com.usbank.ipp.onboarding.dto.request.*;
import com.usbank.ipp.onboarding.dto.response.OnboardingResponse;
import com.usbank.ipp.onboarding.event.*;
import com.usbank.ipp.onboarding.exception.*;
import com.usbank.ipp.onboarding.model.*;
import com.usbank.ipp.onboarding.model.OnboardingRequest.*;
import com.usbank.ipp.onboarding.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class OnboardingService {

    private final OnboardingRequestRepository requestRepo;
    private final PlatformConfigRepository platformConfigRepo;
    private final PayloadValidationService validationService;
    private final PlatformCallService platformCallService;
    private final EventPublisher eventPublisher;

    // ---- Submit Onboarding Request ----
    public OnboardingResponse submitRequest(OnboardingSubmitRequest request) {
        log.info("Submitting onboarding request: appId={}, platforms={}",
                request.getApplicationId(), request.getPlatforms().size());

        // 1. Resolve platform configs and validate payloads
        Map<String, PlatformConfig> configs = new LinkedHashMap<>();
        Map<String, String> allErrors = new LinkedHashMap<>();

        for (var entry : request.getPlatforms()) {
            PlatformConfig config = platformConfigRepo.findByPlatformSlug(entry.getPlatformSlug())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Platform not found: " + entry.getPlatformSlug()));
            configs.put(entry.getPlatformSlug(), config);

            Map<String, String> errors = validationService.validate(entry, config);
            if (!errors.isEmpty()) {
                errors.forEach((k, v) -> allErrors.put(entry.getPlatformSlug() + "." + k, v));
            }
        }

        if (!allErrors.isEmpty()) {
            throw new OnboardingValidationException("Onboarding payload validation failed", allErrors);
        }

        // 2. Build and persist onboarding request
        String requestId = UUID.randomUUID().toString();
        boolean anyManualApproval = configs.values().stream()
                .anyMatch(c -> !c.isSelfServiceEnabled());

        List<PlatformOnboarding> platforms = request.getPlatforms().stream()
                .map(entry -> PlatformOnboarding.builder()
                        .platformSlug(entry.getPlatformSlug())
                        .capabilitySlugs(entry.getCapabilitySlugs())
                        .onboardingPayload(entry.getOnboardingPayload())
                        .status(PlatformStatus.PENDING)
                        .build())
                .toList();

        OnboardingRequest onboardingReq = OnboardingRequest.builder()
                .requestId(requestId)
                .applicationId(request.getApplicationId())
                .applicationName(request.getApplicationName())
                .businessLine(request.getBusinessLine())
                .environment(request.getEnvironment())
                .requestedBy(request.getRequestedBy() != null ? request.getRequestedBy() : "system")
                .status(anyManualApproval ? RequestStatus.PENDING_APPROVAL : RequestStatus.PENDING)
                .platforms(new ArrayList<>(platforms))
                .metadata(request.getMetadata() != null ?
                        RequestMetadata.builder()
                                .projectCode(request.getMetadata().getProjectCode())
                                .costCenter(request.getMetadata().getCostCenter())
                                .targetGoLiveDate(request.getMetadata().getTargetGoLiveDate())
                                .build() : null)
                .build();

        onboardingReq = requestRepo.save(onboardingReq);

        // 3. Publish event
        eventPublisher.publishOnboardingEvent(OnboardingEvent.initiated(
                requestId, request.getApplicationId(),
                request.getPlatforms().stream().map(OnboardingSubmitRequest.PlatformEntry::getPlatformSlug).toList(),
                onboardingReq.getRequestedBy()));

        // 4. If self-service, initiate parallel onboarding calls
        if (!anyManualApproval) {
            executePlatformOnboarding(onboardingReq, configs);
        }

        return OnboardingResponse.from(requestRepo.findByRequestId(requestId).orElse(onboardingReq));
    }

    // ---- Execute parallel platform calls ----
    @Async
    public void executePlatformOnboarding(OnboardingRequest request, Map<String, PlatformConfig> configs) {
        log.info("Executing parallel platform onboarding: requestId={}, platforms={}",
                request.getRequestId(), configs.keySet());

        request.setStatus(RequestStatus.IN_PROGRESS);

        ExecutorService executor = Executors.newFixedThreadPool(
                Math.min(configs.size(), 5));
        Map<String, Future<PlatformCallService.PlatformCallResult>> futures = new LinkedHashMap<>();

        for (var platform : request.getPlatforms()) {
            PlatformConfig config = configs.get(platform.getPlatformSlug());
            if (config == null) continue;

            platform.setStatus(PlatformStatus.IN_PROGRESS);
            platform.setStartedAt(Instant.now());

            futures.put(platform.getPlatformSlug(),
                    executor.submit(() -> platformCallService.callPlatformOnboarding(
                            config, platform.getOnboardingPayload(), request.getRequestId())));
        }
        requestRepo.save(request);

        // Collect results
        for (var entry : futures.entrySet()) {
            String slug = entry.getKey();
            PlatformOnboarding platform = request.getPlatforms().stream()
                    .filter(p -> p.getPlatformSlug().equals(slug)).findFirst().orElse(null);
            if (platform == null) continue;

            try {
                PlatformCallService.PlatformCallResult result =
                        entry.getValue().get(35, TimeUnit.SECONDS);

                if (result.isSuccess()) {
                    platform.setStatus(PlatformStatus.COMPLETED);
                    platform.setExternalOnboardingId(result.getExternalOnboardingId());
                    platform.setCompletedAt(Instant.now());
                    platform.setCredentials(PlatformCredentials.builder()
                            .clientId("ipp-" + request.getApplicationId() + "-" + slug)
                            .clientSecretRef("vault:secrets/ipp/" + request.getApplicationId() + "/" + slug)
                            .build());

                    eventPublisher.publishOnboardingEvent(
                            OnboardingEvent.platformCompleted(request.getRequestId(), slug, request.getApplicationId()));
                } else {
                    platform.setStatus(PlatformStatus.FAILED);
                    platform.setError(result.getError());
                    eventPublisher.publishOnboardingEvent(
                            OnboardingEvent.platformFailed(request.getRequestId(), slug, result.getError()));
                }
            } catch (TimeoutException e) {
                platform.setStatus(PlatformStatus.FAILED);
                platform.setError("Platform onboarding timed out after 35 seconds");
            } catch (Exception e) {
                platform.setStatus(PlatformStatus.FAILED);
                platform.setError("Unexpected error: " + e.getMessage());
            }
        }

        executor.shutdown();

        // Update overall status
        boolean allCompleted = request.getPlatforms().stream()
                .allMatch(p -> p.getStatus() == PlatformStatus.COMPLETED);
        boolean anyFailed = request.getPlatforms().stream()
                .anyMatch(p -> p.getStatus() == PlatformStatus.FAILED);

        if (allCompleted) {
            request.setStatus(RequestStatus.COMPLETED);
            eventPublisher.publishOnboardingEvent(
                    OnboardingEvent.completed(request.getRequestId(), request.getApplicationId()));
        } else if (anyFailed) {
            boolean anySucceeded = request.getPlatforms().stream()
                    .anyMatch(p -> p.getStatus() == PlatformStatus.COMPLETED);
            request.setStatus(anySucceeded ? RequestStatus.COMPLETED : RequestStatus.FAILED);
        }

        requestRepo.save(request);
        log.info("Onboarding complete: requestId={}, status={}", request.getRequestId(), request.getStatus());
    }

    // ---- Get request by ID ----
    public OnboardingResponse getRequest(String requestId) {
        OnboardingRequest req = requestRepo.findByRequestId(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Onboarding request not found: " + requestId));
        return OnboardingResponse.from(req);
    }

    // ---- List requests by appId ----
    public Page<OnboardingResponse> listByApplicationId(String appId, String status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<OnboardingRequest> results;
        if (status != null && !status.isBlank()) {
            results = requestRepo.findByApplicationIdAndStatus(appId, RequestStatus.valueOf(status), pageable);
        } else {
            results = requestRepo.findByApplicationId(appId, pageable);
        }
        return results.map(OnboardingResponse::from);
    }

    // ---- Approve ----
    @CacheEvict(value = "onboarding", key = "#requestId")
    public OnboardingResponse approveRequest(String requestId, ApprovalRequest approval) {
        OnboardingRequest req = requestRepo.findByRequestId(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request not found: " + requestId));

        if (req.getStatus() != RequestStatus.PENDING_APPROVAL) {
            throw new InvalidOperationException("Request is not pending approval. Current status: " + req.getStatus());
        }

        req.setStatus(RequestStatus.PENDING);

        // Resolve configs and execute
        Map<String, PlatformConfig> configs = new LinkedHashMap<>();
        for (var p : req.getPlatforms()) {
            platformConfigRepo.findByPlatformSlug(p.getPlatformSlug())
                    .ifPresent(c -> configs.put(p.getPlatformSlug(), c));
        }

        requestRepo.save(req);
        executePlatformOnboarding(req, configs);

        return OnboardingResponse.from(requestRepo.findByRequestId(requestId).orElse(req));
    }

    // ---- Reject ----
    @CacheEvict(value = "onboarding", key = "#requestId")
    public OnboardingResponse rejectRequest(String requestId, RejectionRequest rejection) {
        OnboardingRequest req = requestRepo.findByRequestId(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request not found: " + requestId));

        if (req.getStatus() != RequestStatus.PENDING_APPROVAL && req.getStatus() != RequestStatus.PENDING) {
            throw new InvalidOperationException("Request cannot be rejected. Current status: " + req.getStatus());
        }

        req.setStatus(RequestStatus.REJECTED);
        req.getPlatforms().forEach(p -> {
            p.setStatus(PlatformStatus.FAILED);
            p.setRejectionReason(rejection.getReason());
        });

        return OnboardingResponse.from(requestRepo.save(req));
    }

    // ---- Cancel ----
    @CacheEvict(value = "onboarding", key = "#requestId")
    public void cancelRequest(String requestId) {
        OnboardingRequest req = requestRepo.findByRequestId(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request not found: " + requestId));

        if (req.getStatus() == RequestStatus.COMPLETED) {
            throw new InvalidOperationException("Completed requests cannot be cancelled");
        }

        req.setStatus(RequestStatus.CANCELLED);
        requestRepo.save(req);

        eventPublisher.publishOnboardingEvent(
                OnboardingEvent.cancelled(requestId, req.getRequestedBy()));
    }

    // ---- Get platform onboarding schema ----
    @Cacheable(value = "platformSchema", key = "#platformSlug")
    public PlatformConfig getOnboardingSchema(String platformSlug) {
        return platformConfigRepo.findByPlatformSlug(platformSlug)
                .orElseThrow(() -> new ResourceNotFoundException("Platform not found: " + platformSlug));
    }

    // ---- Process webhook callback ----
    public OnboardingResponse processWebhookCallback(String requestId, WebhookCallbackRequest callback, String hmacSignature) {
        OnboardingRequest req = requestRepo.findByRequestId(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request not found: " + requestId));

        PlatformOnboarding platform = req.getPlatforms().stream()
                .filter(p -> p.getPlatformSlug().equals(callback.getPlatformSlug()))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Platform not in request: " + callback.getPlatformSlug()));

        if ("COMPLETED".equals(callback.getStatus())) {
            platform.setStatus(PlatformStatus.COMPLETED);
            platform.setCompletedAt(Instant.now());
            platform.setExternalOnboardingId(callback.getOnboardingId());
            if (callback.getCredentials() != null) {
                platform.setCredentials(PlatformCredentials.builder()
                        .clientId(callback.getCredentials().getClientId())
                        .clientSecretRef("vault:secrets/ipp/" + req.getApplicationId() + "/" + callback.getPlatformSlug())
                        .apiKeyRef(callback.getCredentials().getApiKey() != null ?
                                "vault:secrets/ipp/" + req.getApplicationId() + "/apikey" : null)
                        .additionalConfig(callback.getCredentials().getAdditionalConfig())
                        .build());
            }
            eventPublisher.publishOnboardingEvent(
                    OnboardingEvent.platformCompleted(requestId, callback.getPlatformSlug(), req.getApplicationId()));
        } else {
            platform.setStatus(PlatformStatus.FAILED);
            platform.setError(callback.getError());
            eventPublisher.publishOnboardingEvent(
                    OnboardingEvent.platformFailed(requestId, callback.getPlatformSlug(), callback.getError()));
        }

        // Check if all done
        boolean allDone = req.getPlatforms().stream()
                .allMatch(p -> p.getStatus() == PlatformStatus.COMPLETED || p.getStatus() == PlatformStatus.FAILED);
        if (allDone) {
            boolean allSuccess = req.getPlatforms().stream().allMatch(p -> p.getStatus() == PlatformStatus.COMPLETED);
            req.setStatus(allSuccess ? RequestStatus.COMPLETED : RequestStatus.FAILED);
            if (allSuccess) {
                eventPublisher.publishOnboardingEvent(OnboardingEvent.completed(requestId, req.getApplicationId()));
            }
        }

        return OnboardingResponse.from(requestRepo.save(req));
    }
}
