package com.usbank.ipp.onboarding.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;

import java.util.List;
import java.util.Map;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OnboardingSubmitRequest {

    @NotBlank(message = "applicationId is required")
    private String applicationId;

    @NotBlank(message = "applicationName is required")
    private String applicationName;

    @NotBlank(message = "businessLine is required")
    private String businessLine;

    @NotBlank(message = "environment is required")
    private String environment;

    private String requestedBy;

    @NotEmpty(message = "At least one platform must be specified")
    @Valid
    private List<PlatformEntry> platforms;

    private MetadataEntry metadata;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PlatformEntry {
        @NotBlank(message = "platformSlug is required")
        private String platformSlug;

        @NotEmpty(message = "At least one capability must be specified")
        private List<String> capabilitySlugs;

        private Map<String, Object> onboardingPayload;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class MetadataEntry {
        private String projectCode;
        private String costCenter;
        private String targetGoLiveDate;
    }
}
