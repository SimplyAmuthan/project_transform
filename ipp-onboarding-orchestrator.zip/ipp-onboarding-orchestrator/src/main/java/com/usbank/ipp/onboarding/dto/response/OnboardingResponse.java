package com.usbank.ipp.onboarding.dto.response;

import com.usbank.ipp.onboarding.model.OnboardingRequest;
import lombok.*;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OnboardingResponse {
    private String requestId;
    private String applicationId;
    private String applicationName;
    private String businessLine;
    private String environment;
    private String requestedBy;
    private OnboardingRequest.RequestStatus status;
    private List<PlatformStatusResponse> platforms;
    private OnboardingRequest.RequestMetadata metadata;
    private Instant createdAt;
    private Instant updatedAt;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PlatformStatusResponse {
        private String platformSlug;
        private List<String> capabilitySlugs;
        private OnboardingRequest.PlatformStatus status;
        private String externalOnboardingId;
        private CredentialsSummary credentials;
        private String error;
        private Instant startedAt;
        private Instant completedAt;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class CredentialsSummary {
        private String clientId;
        private boolean clientSecretAvailable;
        private boolean apiKeyAvailable;
        private Map<String, Object> additionalConfig;
    }

    public static OnboardingResponse from(OnboardingRequest req) {
        return OnboardingResponse.builder()
                .requestId(req.getRequestId())
                .applicationId(req.getApplicationId())
                .applicationName(req.getApplicationName())
                .businessLine(req.getBusinessLine())
                .environment(req.getEnvironment())
                .requestedBy(req.getRequestedBy())
                .status(req.getStatus())
                .metadata(req.getMetadata())
                .createdAt(req.getCreatedAt())
                .updatedAt(req.getUpdatedAt())
                .platforms(req.getPlatforms() == null ? List.of() :
                        req.getPlatforms().stream().map(p -> PlatformStatusResponse.builder()
                                .platformSlug(p.getPlatformSlug())
                                .capabilitySlugs(p.getCapabilitySlugs())
                                .status(p.getStatus())
                                .externalOnboardingId(p.getExternalOnboardingId())
                                .error(p.getError())
                                .startedAt(p.getStartedAt())
                                .completedAt(p.getCompletedAt())
                                .credentials(p.getCredentials() == null ? null :
                                        CredentialsSummary.builder()
                                                .clientId(p.getCredentials().getClientId())
                                                .clientSecretAvailable(p.getCredentials().getClientSecretRef() != null)
                                                .apiKeyAvailable(p.getCredentials().getApiKeyRef() != null)
                                                .additionalConfig(p.getCredentials().getAdditionalConfig())
                                                .build())
                                .build()).toList())
                .build();
    }
}
