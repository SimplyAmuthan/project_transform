package com.usbank.ipp.onboarding.security;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.HmacUtils;
import org.springframework.stereotype.Component;

import java.security.MessageDigest;

@Component
@Slf4j
public class HmacSignatureService {

    public String sign(String payload, String secret) {
        return "sha256=" + HmacUtils.hmacSha256Hex(secret, payload);
    }

    public boolean verify(String payload, String signature, String secret) {
        if (signature == null || secret == null) return false;
        String computed = sign(payload, secret);
        boolean valid = MessageDigest.isEqual(
                computed.getBytes(), signature.getBytes());
        if (!valid) {
            log.warn("HMAC signature verification failed");
        }
        return valid;
    }
}
