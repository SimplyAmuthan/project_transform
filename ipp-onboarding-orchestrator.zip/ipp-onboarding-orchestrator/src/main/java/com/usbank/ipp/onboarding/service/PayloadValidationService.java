package com.usbank.ipp.onboarding.service;

import com.usbank.ipp.onboarding.dto.request.OnboardingSubmitRequest.PlatformEntry;
import com.usbank.ipp.onboarding.model.PlatformConfig;
import com.usbank.ipp.onboarding.model.PlatformConfig.OnboardingField;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class PayloadValidationService {

    public Map<String, String> validate(PlatformEntry entry, PlatformConfig config) {
        Map<String, String> errors = new LinkedHashMap<>();
        Map<String, Object> payload = entry.getOnboardingPayload();

        if (payload == null) payload = Map.of();
        if (config.getRequiredFields() == null) return errors;

        for (OnboardingField field : config.getRequiredFields()) {
            Object value = payload.get(field.getField());

            if (field.isRequired() && (value == null || value.toString().isBlank())) {
                errors.put(field.getField(),
                        "Required field '" + field.getField() + "' is missing for platform '" + config.getPlatformSlug() + "'");
                continue;
            }

            if (value == null) continue;

            switch (field.getType()) {
                case "string" -> {
                    if (!(value instanceof String))
                        errors.put(field.getField(), "Expected string, got " + value.getClass().getSimpleName());
                }
                case "number" -> {
                    if (!(value instanceof Number))
                        errors.put(field.getField(), "Expected number, got " + value.getClass().getSimpleName());
                }
                case "boolean" -> {
                    if (!(value instanceof Boolean))
                        errors.put(field.getField(), "Expected boolean, got " + value.getClass().getSimpleName());
                }
                case "enum" -> {
                    if (field.getValues() != null && !field.getValues().contains(value.toString()))
                        errors.put(field.getField(), "Value '" + value + "' not in allowed values: " + field.getValues());
                }
                case "array" -> {
                    if (!(value instanceof List))
                        errors.put(field.getField(), "Expected array, got " + value.getClass().getSimpleName());
                }
                case "object" -> {
                    if (!(value instanceof Map))
                        errors.put(field.getField(), "Expected object, got " + value.getClass().getSimpleName());
                }
            }
        }
        return errors;
    }
}
