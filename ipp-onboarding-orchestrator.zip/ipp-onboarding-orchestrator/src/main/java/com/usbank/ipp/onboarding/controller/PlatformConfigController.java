package com.usbank.ipp.onboarding.controller;

import com.usbank.ipp.onboarding.exception.InvalidOperationException;
import com.usbank.ipp.onboarding.exception.ResourceNotFoundException;
import com.usbank.ipp.onboarding.model.PlatformConfig;
import com.usbank.ipp.onboarding.repository.PlatformConfigRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/platforms")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Platform Configuration", description = "Register and manage platform onboarding schemas (Platform Provider API)")
public class PlatformConfigController {

    private final PlatformConfigRepository repo;

    @PostMapping
    @Operation(summary = "Register a platform",
               description = "Platform owners register their platform with onboarding endpoint, HMAC secret, " +
                       "and required fields schema so that business-line developers can onboard to it.")
    public ResponseEntity<PlatformConfig> registerPlatform(
            @Valid @RequestBody PlatformConfig config) {

        log.info("POST /api/v1/platforms - Registering platform: {}", config.getPlatformSlug());

        if (repo.existsByPlatformSlug(config.getPlatformSlug())) {
            throw new InvalidOperationException(
                    "Platform slug '" + config.getPlatformSlug() + "' is already registered. Use PUT to update.");
        }

        PlatformConfig saved = repo.save(config);
        return ResponseEntity
                .created(URI.create("/api/v1/platforms/" + saved.getPlatformSlug()))
                .body(saved);
    }

    @GetMapping
    @Operation(summary = "List all registered platforms",
               description = "Returns all platform configurations registered with the onboarding orchestrator.")
    public ResponseEntity<List<PlatformConfig>> listPlatforms() {
        log.info("GET /api/v1/platforms");
        return ResponseEntity.ok(repo.findAll());
    }

    @GetMapping("/{platformSlug}")
    @Operation(summary = "Get platform configuration",
               description = "Retrieve the full configuration for a specific platform including onboarding schema.")
    public ResponseEntity<PlatformConfig> getPlatform(@PathVariable String platformSlug) {
        log.info("GET /api/v1/platforms/{}", platformSlug);
        PlatformConfig config = repo.findByPlatformSlug(platformSlug)
                .orElseThrow(() -> new ResourceNotFoundException("Platform not found: " + platformSlug));
        return ResponseEntity.ok(config);
    }

    @PutMapping("/{platformSlug}")
    @Operation(summary = "Update platform configuration",
               description = "Platform owners update their onboarding configuration, required fields, or endpoints.")
    public ResponseEntity<PlatformConfig> updatePlatform(
            @PathVariable String platformSlug,
            @Valid @RequestBody PlatformConfig config) {

        log.info("PUT /api/v1/platforms/{}", platformSlug);

        PlatformConfig existing = repo.findByPlatformSlug(platformSlug)
                .orElseThrow(() -> new ResourceNotFoundException("Platform not found: " + platformSlug));

        existing.setName(config.getName());
        existing.setSelfServiceEnabled(config.isSelfServiceEnabled());
        existing.setOnboardingEndpoint(config.getOnboardingEndpoint());
        existing.setWebhookUrl(config.getWebhookUrl());
        existing.setHmacSecretRef(config.getHmacSecretRef());
        existing.setRequiredFields(config.getRequiredFields());

        return ResponseEntity.ok(repo.save(existing));
    }

    @DeleteMapping("/{platformSlug}")
    @Operation(summary = "Deregister a platform",
               description = "Remove a platform configuration. Existing onboarding requests are not affected.")
    public ResponseEntity<Void> deletePlatform(@PathVariable String platformSlug) {
        log.info("DELETE /api/v1/platforms/{}", platformSlug);

        PlatformConfig config = repo.findByPlatformSlug(platformSlug)
                .orElseThrow(() -> new ResourceNotFoundException("Platform not found: " + platformSlug));

        repo.delete(config);
        return ResponseEntity.noContent().build();
    }
}
