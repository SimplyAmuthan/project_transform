package com.usbank.ipp.onboarding.event;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EventPublisher {

    private final KafkaTemplate<String, OnboardingEvent> kafkaTemplate;

    @Value("${ipp.kafka.topics.onboarding-status}")
    private String statusTopic;

    @Value("${ipp.kafka.topics.audit-log}")
    private String auditTopic;

    @Async
    public void publishOnboardingEvent(OnboardingEvent event) {
        String key = event.getCorrelationId();
        log.info("Publishing event: type={}, correlationId={}", event.getEventType(), key);
        kafkaTemplate.send(statusTopic, key, event)
                .whenComplete((result, ex) -> {
                    if (ex != null) {
                        log.error("Failed to publish event: type={}, error={}", event.getEventType(), ex.getMessage());
                    } else {
                        log.debug("Event published: type={}, partition={}, offset={}",
                                event.getEventType(),
                                result.getRecordMetadata().partition(),
                                result.getRecordMetadata().offset());
                    }
                });
    }

    @Async
    public void publishAuditEvent(OnboardingEvent event) {
        kafkaTemplate.send(auditTopic, event.getCorrelationId(), event);
    }
}
