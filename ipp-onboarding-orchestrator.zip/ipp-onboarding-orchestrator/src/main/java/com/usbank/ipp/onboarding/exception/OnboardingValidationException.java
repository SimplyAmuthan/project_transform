package com.usbank.ipp.onboarding.exception;

import lombok.Getter;
import java.util.Map;

@Getter
public class OnboardingValidationException extends RuntimeException {
    private final Map<String, String> fieldErrors;
    public OnboardingValidationException(String message, Map<String, String> fieldErrors) {
        super(message);
        this.fieldErrors = fieldErrors;
    }
}
