package com.usbank.ipp.onboarding.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class RejectionRequest {
    private String rejectedBy;
    @NotBlank(message = "Rejection reason is required")
    private String reason;
}
