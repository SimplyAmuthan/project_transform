package com.usbank.vulnrewrite.mcp;

import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * Wires {@link VulnRewriteMcpTools} into the Spring AI MCP server starter.
 * <p>
 * Only active when an MCP profile is selected — keeps the shell-only
 * developer experience light (no MCP wiring, no extra port bound).
 */
@Configuration
@Profile({"mcp-stdio", "mcp-http"})
public class McpConfig {

    /**
     * Spring AI's MCP server starter discovers any {@link ToolCallbackProvider}
     * bean and exposes its callbacks as MCP tools. Method-level reflection
     * derives the JSON schema from {@link org.springframework.ai.tool.annotation.Tool}
     * and {@link org.springframework.ai.tool.annotation.ToolParam} annotations.
     */
    @Bean
    public ToolCallbackProvider vulnRewriteTools(VulnRewriteMcpTools tools) {
        return MethodToolCallbackProvider.builder()
                .toolObjects(tools)
                .build();
    }
}
