package com.usbank.vulnrewrite.mcp;

import com.usbank.vulnrewrite.exception.RemediationException;
import com.usbank.vulnrewrite.model.RecipeArtifact;
import com.usbank.vulnrewrite.model.RemediationPlan;
import com.usbank.vulnrewrite.model.RemediationReport;
import com.usbank.vulnrewrite.model.Vulnerability;
import com.usbank.vulnrewrite.service.RecipeGeneratorService;
import com.usbank.vulnrewrite.service.RecipeWriterService;
import com.usbank.vulnrewrite.service.RemediationOrchestrator;
import com.usbank.vulnrewrite.service.VulnerabilityParserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * MCP tool surface for vuln-rewrite.
 * <p>
 * Each method here is exposed to the MCP host (VS Code Copilot, IntelliJ Copilot,
 * Claude Code, Copilot CLI, Cursor …) as a callable tool. The host's LLM decides
 * when to invoke them based on the {@link Tool#description()} text — these
 * descriptions are part of the contract, treat them like API docs.
 * <p>
 * Naming convention: <em>verb_noun</em>, all lowercase with underscores.
 * <p>
 * Safety: tools that can mutate remote state (push, MR creation) are exposed
 * via {@link #apply_remediation} only. Hosts typically prompt the user before
 * invoking write tools; we additionally provide {@link #apply_remediation_dry_run}
 * as the always-safe variant.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class VulnRewriteMcpTools {

    private final VulnerabilityParserService parser;
    private final RecipeGeneratorService generator;
    private final RecipeWriterService writer;
    private final RemediationOrchestrator orchestrator;

    // ---------------------------------------------------------------- read-only

    @Tool(name = "summarise_vulnerabilities",
          description = """
                  Parse a Black Duck vulnerability export (XLSX, TSV, or CSV) and
                  return a structured summary: total count, breakdown by severity,
                  and breakdown by component coordinate. Use this for triage before
                  generating any recipes. This tool does not touch Git or network.
                  """)
    public SummaryResult summarise_vulnerabilities(
            @ToolParam(description = "Absolute path to the Black Duck export file (.xlsx, .tsv, or .csv).")
            String vulnerability_file
    ) {
        List<Vulnerability> vulns = parser.parse(Path.of(vulnerability_file));
        Map<String, Long> bySeverity = new LinkedHashMap<>();
        for (Vulnerability v : vulns) {
            bySeverity.merge(v.getSeverity().name(), 1L, Long::sum);
        }
        Map<String, Long> byComponent = vulns.stream()
                .collect(Collectors.groupingBy(
                        Vulnerability::componentCoordinate,
                        LinkedHashMap::new,
                        Collectors.counting()));
        return new SummaryResult(vulns.size(), bySeverity, byComponent);
    }

    @Tool(name = "generate_remediation_plan",
          description = """
                  Generate an OpenRewrite recipe (rewrite.yml content) for the
                  given vulnerability export. Returns the YAML body plus counts
                  of automated vs manual remediations. Does NOT clone any repo,
                  modify pom.xml, or run Maven. Use this for previewing what
                  apply_remediation would produce.
                  """)
    public PlanResult generate_remediation_plan(
            @ToolParam(description = "Absolute path to the Black Duck export.")
            String vulnerability_file,
            @ToolParam(description = "Minimum severity to remediate. One of CRITICAL, HIGH, MEDIUM, LOW. Default: MEDIUM.",
                       required = false)
            String min_severity
    ) {
        List<Vulnerability> vulns = parser.parse(Path.of(vulnerability_file));
        Vulnerability.Severity floor = Vulnerability.Severity.from(
                min_severity == null || min_severity.isBlank() ? "MEDIUM" : min_severity);
        RemediationPlan plan = generator.generate(vulns, floor);
        return new PlanResult(
                plan.getAggregateRecipeName(),
                writer.render(plan),
                (int) plan.automatedCount(),
                (int) plan.manualCount(),
                plan.getArtifacts().stream().map(this::toArtifactView).toList()
        );
    }

    // ------------------------------------------------------------- mutating ops

    @Tool(name = "apply_remediation_dry_run",
          description = """
                  End-to-end SAFE remediation: clones the GitLab project, creates a
                  remediation branch, generates rewrite.yml, injects the OpenRewrite
                  Maven plugin into pom.xml, and runs 'mvn rewrite:dryRun'. Commits
                  the changes locally but DOES NOT push and DOES NOT open an MR.
                  Returns a structured report with paths to the generated artifacts
                  and the dry-run diff summary. Always prefer this tool over
                  apply_remediation for first-time runs.
                  """)
    public RemediateResult apply_remediation_dry_run(
            @ToolParam(description = "GitLab project URL (HTTPS or SSH).")
            String project_url,
            @ToolParam(description = "Absolute path to the Black Duck export.")
            String vulnerability_file,
            @ToolParam(description = "Minimum severity. CRITICAL/HIGH/MEDIUM/LOW. Default: MEDIUM.",
                       required = false)
            String min_severity
    ) {
        return runPipeline(project_url, vulnerability_file, min_severity,
                /*dryRun*/ true, /*push*/ false, /*openMr*/ false);
    }

    @Tool(name = "apply_remediation",
          description = """
                  End-to-end remediation with full options: clones the GitLab project,
                  creates a remediation branch, generates rewrite.yml, injects the
                  OpenRewrite Maven plugin, runs Maven (rewrite:run if dry_run=false,
                  otherwise rewrite:dryRun), commits, optionally pushes the branch,
                  and optionally opens a GitLab merge request. USE WITH CARE: when
                  push=true and open_merge_request=true this tool produces visible
                  external side effects. Confirm with the user before invoking with
                  push=true.
                  """)
    public RemediateResult apply_remediation(
            @ToolParam(description = "GitLab project URL (HTTPS or SSH).")
            String project_url,
            @ToolParam(description = "Absolute path to the Black Duck export.")
            String vulnerability_file,
            @ToolParam(description = "If true, run 'mvn rewrite:dryRun' (no source changes); if false, run 'mvn rewrite:run' (applies changes).")
            boolean dry_run,
            @ToolParam(description = "If true, push the auto-created branch to origin. Requires GITLAB_TOKEN.")
            boolean push,
            @ToolParam(description = "If true and push=true, open a GitLab merge request after pushing.")
            boolean open_merge_request,
            @ToolParam(description = "Minimum severity. CRITICAL/HIGH/MEDIUM/LOW. Default: MEDIUM.",
                       required = false)
            String min_severity
    ) {
        // Defensive: 'open_merge_request' is meaningless without push. Quietly normalise.
        boolean effectiveOpenMr = push && open_merge_request;
        return runPipeline(project_url, vulnerability_file, min_severity,
                dry_run, push, effectiveOpenMr);
    }

    // ----------------------------------------------------------------- internal

    private RemediateResult runPipeline(String projectUrl,
                                        String vulnerabilityFile,
                                        String minSeverity,
                                        boolean dryRun,
                                        boolean push,
                                        boolean openMr) {
        try {
            Vulnerability.Severity floor = Vulnerability.Severity.from(
                    minSeverity == null || minSeverity.isBlank() ? "MEDIUM" : minSeverity);
            RemediationOrchestrator.Request req = new RemediationOrchestrator.Request(
                    projectUrl, Path.of(vulnerabilityFile), dryRun, push, openMr, floor);
            RemediationReport report = orchestrator.execute(req);
            return RemediateResult.from(report);
        } catch (RemediationException e) {
            // Surface domain failures in a structured way the host LLM can interpret.
            log.error("Remediation failed", e);
            return RemediateResult.failure(e.getMessage());
        }
    }

    private ArtifactView toArtifactView(RecipeArtifact a) {
        return new ArtifactView(
                a.getComponentCoordinate(),
                a.getStrategy().name(),
                a.getTargetVersion(),
                a.getRecipeReference(),
                a.getManualNote(),
                a.getCoversVulnIds(),
                a.getConfidence()
        );
    }

    // ---------------------------------------------------------- response shapes

    /**
     * MCP tools should return JSON-serialisable records, not domain entities,
     * so the schema we expose stays decoupled from the internal model.
     */
    public record SummaryResult(int total,
                                Map<String, Long> bySeverity,
                                Map<String, Long> byComponent) { }

    public record PlanResult(String aggregateRecipeName,
                             String recipeYaml,
                             int automatedCount,
                             int manualCount,
                             List<ArtifactView> artifacts) { }

    public record ArtifactView(String componentCoordinate,
                               String strategy,
                               String targetVersion,
                               String recipeReference,
                               String manualNote,
                               List<String> coversVulnerabilityIds,
                               Double confidence) { }

    public record RemediateResult(boolean success,
                                  String errorMessage,
                                  String projectUrl,
                                  String branchName,
                                  String workingCopyPath,
                                  String recipeFilePath,
                                  boolean dryRun,
                                  boolean pushed,
                                  boolean mergeRequestOpened,
                                  String mergeRequestUrl,
                                  int totalVulnerabilities,
                                  int automatedRemediations,
                                  int manualRemediations,
                                  String dryRunDiffSummary,
                                  String htmlReportPath) {

        static RemediateResult from(RemediationReport r) {
            return new RemediateResult(
                    true, null,
                    r.getProjectUrl(),
                    r.getBranchName(),
                    r.getWorkingCopy() == null ? null : r.getWorkingCopy().toString(),
                    r.getRecipeFile() == null ? null : r.getRecipeFile().toString(),
                    r.isDryRun(),
                    r.isPushed(),
                    r.isMergeRequestOpened(),
                    r.getMergeRequestUrl(),
                    r.getTotalVulnerabilities(),
                    r.getAutomatedRemediations(),
                    r.getManualRemediations(),
                    r.getDryRunDiffSummary(),
                    r.getHtmlReportPath() == null ? null : r.getHtmlReportPath().toString()
            );
        }

        static RemediateResult failure(String message) {
            return new RemediateResult(false, message, null, null, null, null,
                    false, false, false, null, 0, 0, 0, null, null);
        }
    }
}
