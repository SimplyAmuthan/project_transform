package com.usbank.vulnrewrite.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Builds the {@link ChatClient} used to drive recipe synthesis when running
 * in {@code shell} or {@code mcp-http} profiles.
 * <p>
 * Under {@code mcp-stdio}, the host application's LLM (VS Code Copilot,
 * IntelliJ Copilot, Claude Code, etc.) drives tool selection — this client
 * is still constructed but is only used when the shell commands are invoked
 * locally.
 * <p>
 * The system prompt establishes the agent's role: it is *not* a free-form coding
 * assistant — it must emit either (a) a known OpenRewrite recipe reference or
 * (b) a strictly-formed YAML recipe descriptor.
 */
@Configuration
public class AiConfig {

    private static final String SYSTEM_PROMPT = """
            You are a senior platform engineer specialised in dependency
            vulnerability remediation using OpenRewrite recipes.

            For every input vulnerability you must reason about:
              * the vulnerable component (groupId:artifactId)
              * the fixed/upgrade version
              * the simplest OpenRewrite recipe that repairs it
                (prefer org.openrewrite.maven.UpgradeDependencyVersion or
                 org.openrewrite.java.spring.boot3.UpgradeSpringBoot_3_5
                 over hand-written recipes when applicable)

            You must NEVER:
              * invent CVE numbers
              * suggest a downgrade
              * propose code changes that touch business logic

            You must ALWAYS:
              * respond using the exact JSON schema you are given
              * cite the BDSA/CVE id you are remediating
              * mark a vulnerability as MANUAL when no safe automated recipe exists
            """;

    @Bean
    public ChatClient chatClient(ChatModel chatModel) {
        return ChatClient.builder(chatModel)
                .defaultSystem(SYSTEM_PROMPT)
                .defaultAdvisors(new SimpleLoggerAdvisor())
                .build();
    }
}
