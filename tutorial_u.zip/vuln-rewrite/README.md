# vuln-rewrite

> Spring Boot tool that converts Black Duck vulnerability exports into
> OpenRewrite recipes and applies them to a target GitLab project.
>
> Runs in **three modes** from the same JAR — Spring Shell, MCP STDIO server,
> MCP HTTP server — so it fits whatever workflow you have.

## What it does

1. Parses and prioritises Black Duck vulnerabilities (XLSX / TSV / CSV).
2. Translates each vulnerable component into the most appropriate
   **OpenRewrite recipe** — preferring canonical recipes
   (`UpgradeSpringBoot_3_5`, etc.) and falling back to a custom YAML recipe
   only when no built-in fits.
3. Clones the target GitLab repo, creates a remediation branch, writes
   `rewrite.yml`, injects the `rewrite-maven-plugin` (with `activeRecipes`,
   recipe dependencies, `failOnDryRunResults=false`) into the target `pom.xml`.
4. Runs `mvn rewrite:dryRun` (default, safe) or `mvn rewrite:run`.
5. Commits the changes, optionally pushes the branch, and optionally opens a
   GitLab MR.
6. Emits an HTML + Markdown remediation report.

## Operating modes

| Mode | When | Activation |
|---|---|---|
| **Spring Shell** | Power users at the CLI; CI scripts. | `java -jar vuln-rewrite-0.2.0.jar` (default) |
| **MCP STDIO** | IDE-spawned per developer (VS Code Copilot, IntelliJ Copilot, Claude Code, Cursor …). The host's LLM drives the tools. | `--spring.profiles.active=mcp-stdio` |
| **MCP HTTP** | One shared endpoint for a team or for CI; supports OAuth. | `--spring.profiles.active=mcp-http` |

The same business logic (parser, recipe generator, Maven injector, JGit, GitLab
client, report writer) is shared across all three modes — see
`docs/ARCHITECTURE.md`.

## LLM source

Two paths supported, picked by profile:

- **Shell + MCP HTTP** call **GitHub Models** (`https://models.github.ai/inference`)
  using a GitHub PAT (`models:read` scope). OpenAI-compatible, free tier
  available, billed separately from any Copilot subscription.
- **MCP STDIO** does *not* call any LLM directly. The IDE host's LLM (the
  user's Copilot or Claude subscription) invokes the tools. The recipe-synthesis
  ChatClient still works inside the JVM if a tool needs it, but typical use is
  fully driven by the host LLM.

## Quick start — pick your mode

### A. Shell mode

```bash
mvn -DskipTests clean package
export GITHUB_TOKEN=<github-pat-with-models-read>
export GITLAB_BASE_URL=https://gitlab.usbank.com
export GITLAB_TOKEN=<gitlab-pat>

java -jar target/vuln-rewrite-0.2.0.jar
```

You'll land in the Spring Shell prompt:

```
shell:>summarise --vulnerabilities ./blackduck-export.xlsx
shell:>plan       --vulnerabilities ./blackduck-export.xlsx --min-severity HIGH
shell:>remediate  --project-url https://gitlab.usbank.com/payments/cardcontrols.git \
                  --vulnerabilities ./blackduck-export.xlsx \
                  --dry-run true
```

### B. MCP STDIO mode (per-developer, IDE-spawned)

Configure the IDE host (see `docs/MCP-INTEGRATION.md` for VS Code, IntelliJ,
Claude Code, Cursor, Copilot CLI snippets), then in chat:

> *"Use vuln-rewrite to summarise ./blackduck-export.xlsx and tell me which
> components have the worst CVEs."*

> *"Run a dry-run remediation on https://gitlab.usbank.com/payments/cardcontrols.git
> using ./blackduck-export.xlsx, only HIGH severity."*

The host LLM picks the right tool (`summarise_vulnerabilities`,
`apply_remediation_dry_run`, etc.) and shows the result inline.

### C. MCP HTTP mode (shared)

```bash
java -jar vuln-rewrite-0.2.0.jar --spring.profiles.active=mcp-http
```

Default port `8080`; endpoint `/mcp/messages`. Hosts then point at
`http://<server>:8080/mcp` — same tools, network-accessible.

## Tools exposed (MCP)

| Tool | Description |
|---|---|
| `summarise_vulnerabilities` | Triage histogram by severity & component. |
| `generate_remediation_plan` | Returns the `rewrite.yml` body without touching Git. |
| `apply_remediation_dry_run` | Full pipeline, but commits locally only — never pushes. |
| `apply_remediation` | Full pipeline with optional `push` and `open_merge_request`. |

Detailed descriptions are baked into the `@Tool` annotations so the host LLM can
route correctly. See `src/main/java/com/usbank/vulnrewrite/mcp/VulnRewriteMcpTools.java`.

## Shell commands

Equivalent to the MCP tools above — `remediate`, `plan`, `summarise`. See
`shell --help` once inside.

## What gets injected into the target `pom.xml`

Idempotent — re-running won't duplicate the plugin:

```xml
<plugin>
  <groupId>org.openrewrite.maven</groupId>
  <artifactId>rewrite-maven-plugin</artifactId>
  <version>5.46.0</version>
  <configuration>
    <activeRecipes>
      <recipe>com.usbank.vulnrewrite.AutoRemediation</recipe>
    </activeRecipes>
    <failOnDryRunResults>false</failOnDryRunResults>
    <dependencies>
      <dependency>
        <groupId>org.openrewrite.recipe</groupId>
        <artifactId>rewrite-spring</artifactId>
        <version>5.24.1</version>
      </dependency>
    </dependencies>
  </configuration>
</plugin>
```

## Safety model

| Risk | Mitigation |
|------|------------|
| LLM invents a non-existent recipe | Confidence threshold + fallback to `MANUAL` strategy. |
| Recipe touches business logic | System prompt forbids it; only Maven dependency recipes allowed. |
| Push to `main` by accident | Branch is always created with timestamped prefix; CLI `--push` defaults to `false`; MCP host prompts before `apply_remediation`. |
| Plugin overrides developer config | `MavenPluginInjector` is idempotent; existing `<configuration>` is merged. |
| MCP STDIO log spam corrupts protocol | `logback-spring.xml` routes all logs to file under `mcp-stdio`. |
| MCP HTTP exposed on network | OAuth 2 resource-server support is one starter dependency away — see `MCP-INTEGRATION.md`. |

## Architecture

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — PlantUML component view,
end-to-end sequence (per transport), and domain class diagrams.

## Roadmap

- **Recipe cache** keyed by `(component, version, target)` to skip repeat LLM
  calls across applications.
- **Pre-canned recipe registry** — drop-in YAML files under
  `src/main/resources/recipes/known/` indexed by CVE/BDSA → recipe.
- **Multi-module support** — inject the plugin into the root `pom.xml` only
  when sub-modules inherit from a parent.
- **Confluence / Jira integration** — write the Markdown report straight to a
  Confluence page or attach to a Jira ticket.
- **Fine-grained MCP tools** — `parse_vulnerability_file`, `inject_maven_plugin`,
  `run_open_rewrite` — for IDE LLMs that want to compose more flexibly than the
  current four coarse tools.
