# GitHub Models — quick reference

This document covers the Spring AI / GitHub Models integration used in
`shell` and `mcp-http` profiles. Skip this if you only run `mcp-stdio` —
in that mode, your IDE's Copilot supplies the LLM and `vuln-rewrite` is a
pure tool server.

## Why GitHub Models (not GitHub Copilot)

The two are **separate products**:

|  | GitHub Copilot | GitHub Models |
|---|---|---|
| What it is | IDE assistant subscription | REST inference API |
| How you call it | Copilot UI / `vscode.lm` / MCP | Direct HTTPS POST |
| Endpoint | n/a (no public LLM API) | `https://models.github.ai/inference/chat/completions` |
| Auth | Copilot subscription | GitHub PAT with `models:read` |
| Spec | proprietary | OpenAI-compatible (chat/completions) |
| Free tier | no | yes (rate-limited) |

`vuln-rewrite` uses **GitHub Models** for direct LLM calls in shell/HTTP modes
because there is no public REST endpoint for the Copilot LLM. If you want the
user's actual Copilot subscription to drive things, use `mcp-stdio` mode and
let the IDE Copilot orchestrate.

## How the integration works

Spring AI's OpenAI starter speaks the standard `chat/completions` schema. We
override the base URL and pass a GitHub PAT in the `Authorization: Bearer`
slot. No code changes required — just configuration:

```yaml
spring:
  ai:
    openai:
      base-url: https://models.github.ai/inference
      api-key: ${GITHUB_TOKEN}
      chat:
        options:
          model: openai/gpt-4o
          temperature: 0.1
```

## Setting up the token

1. Create a fine-grained PAT at https://github.com/settings/tokens?type=beta
2. Grant the **`models:read`** scope (no other scopes needed for Models alone).
3. Export it: `export GITHUB_TOKEN=ghp_...`

In CI, you don't need a PAT — the runner's built-in `GITHUB_TOKEN` already has
`models:read` if you opt in:

```yaml
permissions:
  contents: read
  models: read    # 👈 unlocks GitHub Models for GITHUB_TOKEN
```

## Available models

The catalogue is live at `https://models.github.ai/catalog/models`. Common picks:

| Model | When to use |
|---|---|
| `openai/gpt-4o` | Default. Strong tool-use, good JSON. |
| `openai/gpt-4o-mini` | Cheaper / faster for triage prompts. |
| `openai/gpt-4.1` | Newer, when available in your tier. |
| `meta/Meta-Llama-3.1-70B-Instruct` | If you need a Meta model. |

Override via env var without changing config:

```bash
export VULN_REWRITE_MODEL=openai/gpt-4o-mini
```

## Rate limits

The free tier is rate-limited (per-minute and per-day). `vuln-rewrite`
deduplicates by component coordinate before calling the LLM, so a 100-row
Black Duck export typically issues 5–15 LLM calls, not 100. If you exceed the
free tier, switch to paid inference in your GitHub settings — same endpoint,
larger context windows, higher RPM.

## Testing without burning credits

For local development against a real LLM, point at `gpt-4o-mini`:

```bash
export GITHUB_TOKEN=ghp_...
export VULN_REWRITE_MODEL=openai/gpt-4o-mini
java -jar target/vuln-rewrite-0.2.0.jar
```

For unit tests, mock the `ChatClient` — see `RecipeWriterServiceTest` for the
pattern.
