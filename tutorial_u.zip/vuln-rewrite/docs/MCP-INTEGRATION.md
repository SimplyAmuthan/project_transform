# MCP integration guide

`vuln-rewrite` ships as an MCP server that exposes four tools to any
MCP-compatible host: VS Code Copilot, IntelliJ Copilot, Copilot CLI,
Claude Code, Cursor, Windsurf, and Claude Desktop.

## Tools exposed

| Tool | Mutates? | Network? | Use it for |
|---|---|---|---|
| `summarise_vulnerabilities` | no | no | Triage / counts before deciding to remediate. |
| `generate_remediation_plan` | no | yes (LLM) | Preview the `rewrite.yml` without touching any repo. |
| `apply_remediation_dry_run` | local commit only | yes (clone, LLM, mvn) | Always-safe end-to-end run; commits locally, never pushes. |
| `apply_remediation` | yes (push, MR) | yes | Full pipeline with optional `push`/`open_merge_request`. |

The host's LLM picks tools based on the descriptions; phrases like *"summarise the
vulnerabilities in this Black Duck export"* or *"open an MR with the dependency bumps"*
will route to the right one.

## Picking a transport

| Transport | When | How |
|---|---|---|
| **STDIO** | Solo developer, IDE-spawns the JAR per session. | `java -jar vuln-rewrite-0.2.0.jar --spring.profiles.active=mcp-stdio` |
| **Streamable HTTP** | Team / CI, one shared endpoint, OAuth-friendly. | `java -jar vuln-rewrite-0.2.0.jar --spring.profiles.active=mcp-http` |

Both modes use the same JAR and the same tools — only the wire protocol differs.

## Environment variables

```bash
# GitHub Models (only needed for shell / mcp-http profiles; mcp-stdio uses host LLM)
export GITHUB_TOKEN=...                        # PAT with models:read
export VULN_REWRITE_MODEL=openai/gpt-4o        # optional override

# GitLab (needed for clone + push + MR — required by all transports for apply_remediation)
export GITLAB_BASE_URL=https://gitlab.usbank.com
export GITLAB_TOKEN=...                         # PAT with api + write_repository
```

## Client configuration

### VS Code Copilot (STDIO)

`.vscode/mcp.json` in the project, or VS Code user settings:

```json
{
  "servers": {
    "vuln-rewrite": {
      "type": "stdio",
      "command": "java",
      "args": [
        "-jar",
        "/absolute/path/to/vuln-rewrite-0.2.0.jar",
        "--spring.profiles.active=mcp-stdio"
      ],
      "env": {
        "GITLAB_BASE_URL": "https://gitlab.usbank.com",
        "GITLAB_TOKEN": "${input:gitlab_token}"
      }
    }
  }
}
```

Then in Copilot Chat, agent mode: *"Use vuln-rewrite to summarise ./blackduck-export.xlsx"*.

### VS Code Copilot (HTTP)

If `vuln-rewrite` is running as a shared HTTP server somewhere on your network:

```json
{
  "servers": {
    "vuln-rewrite": {
      "type": "http",
      "url": "https://vuln-rewrite.internal.usbank.com/mcp",
      "headers": { "Authorization": "Bearer ${input:bearer_token}" }
    }
  }
}
```

### IntelliJ Copilot

Settings → GitHub Copilot → MCP Servers → Add. Same JSON shape as VS Code.

### Copilot CLI

`~/.config/github-copilot/mcp.json`:

```json
{
  "servers": {
    "vuln-rewrite": {
      "command": "java",
      "args": ["-jar", "~/tools/vuln-rewrite-0.2.0.jar", "--spring.profiles.active=mcp-stdio"]
    }
  }
}
```

Then: `gh copilot --mcp vuln-rewrite "remediate the vulns in ./export.xlsx for https://gitlab.usbank.com/payments/cardcontrols.git"`

### Claude Code

`~/.claude/mcp.json`:

```json
{
  "vuln-rewrite": {
    "command": "java",
    "args": ["-jar", "/absolute/path/to/vuln-rewrite-0.2.0.jar", "--spring.profiles.active=mcp-stdio"],
    "env": {
      "GITLAB_BASE_URL": "https://gitlab.usbank.com",
      "GITLAB_TOKEN": "..."
    }
  }
}
```

### Cursor / Windsurf

Both use the same MCP JSON shape as Claude Code; place the snippet in their respective MCP config.

### Claude Desktop

`~/Library/Application Support/Claude/claude_desktop_config.json` (macOS):

```json
{
  "mcpServers": {
    "vuln-rewrite": {
      "command": "java",
      "args": ["-jar", "/absolute/path/to/vuln-rewrite-0.2.0.jar", "--spring.profiles.active=mcp-stdio"]
    }
  }
}
```

## Verifying connectivity

After the host is configured, ask it: *"What tools does vuln-rewrite expose?"* — it
should list `summarise_vulnerabilities`, `generate_remediation_plan`,
`apply_remediation_dry_run`, and `apply_remediation`.

If anything goes wrong, check `~/.vuln-rewrite/logs/vuln-rewrite.log` — under
`mcp-stdio` profile all logs go there (stdout is reserved for MCP).

## Safety notes

- **Push / MR creation** require explicit user approval at the host level. VS Code
  Copilot, Claude Code, etc. all prompt before invoking write tools.
- The `apply_remediation_dry_run` tool is the safe default. It clones, applies,
  runs `mvn rewrite:dryRun`, and commits *locally* — your machine, your branch,
  no remote effects.
- `apply_remediation` with `push=true, open_merge_request=true` produces visible
  external side effects. Recommended pattern: ask the LLM to call dry-run first,
  review, then explicitly authorise the apply.

## HTTP mode hardening

For shared deployments, the Spring AI MCP starter supports OAuth 2 on the HTTP
transport. Add `spring-boot-starter-oauth2-resource-server` and configure your
authorisation server in `application-mcp-http.yml`:

```yaml
spring:
  security:
    oauth2:
      resourceserver:
        jwt:
          issuer-uri: https://login.usbank.com/oauth2/issuer
```

The MCP starter then enforces token validation on `/mcp/messages`.
