# vuln-rewrite — Architecture

## 1. Component view (all transports)

```plantuml
@startuml
!theme plain
skinparam componentStyle rectangle
skinparam shadowing false

actor "Developer / SRE" as user
actor "IDE host\n(VS Code Copilot,\nIntelliJ Copilot,\nClaude Code, …)"  as host

package "vuln-rewrite (single JAR, profile-driven)" {

  package "Transports (one active per JVM)" {
    [Spring Shell\n(profile: shell)]                         as cli
    [MCP STDIO server\n(profile: mcp-stdio)]                 as stdio
    [MCP HTTP server\n(profile: mcp-http)]                   as http
  }

  [VulnRewriteMcpTools\n(@Tool methods)]                      as tools
  [RemediationOrchestrator]                                   as orch

  [VulnerabilityParserService]                                as parser
  [RecipeGeneratorService]                                    as gen
  [RecipeWriterService]                                       as writer
  [MavenPluginInjector]                                       as inj
  [RecipeExecutorService]                                     as exec
  [GitService]                                                as git
  [GitLabMergeRequestService]                                 as mr
  [ReportService]                                             as report
}

cloud   "GitHub Models\nmodels.github.ai" as ghmodels
cloud   "Host LLM (Copilot,\nClaude, …)"   as hostllm
node    "GitLab"                            as gitlab
node    "Target Maven project\n(working copy)" as project
database "Black Duck export"                as bd

user -> cli   : remediate / plan / summarise
host -> stdio : MCP JSON-RPC over stdio
host -> http  : MCP JSON-RPC over HTTP
host <-> hostllm : tool selection

cli   --> orch
stdio --> tools
http  --> tools
tools --> orch

orch --> parser : parse(file)
parser --> bd
orch --> git    : clone + branch
git   --> gitlab
orch --> gen    : generate(plan)
gen   --> ghmodels : ChatClient (shell / mcp-http only)
orch --> writer : write rewrite.yml
writer --> project
orch --> inj    : inject pom.xml
inj   --> project
orch --> exec   : mvn rewrite:dryRun|run
exec  --> project
orch --> git    : commit + push
orch --> mr     : open MR
mr    --> gitlab
orch --> report : write HTML/MD
@enduml
```

Key insight: the orchestrator is transport-agnostic. The same pipeline runs
whether the trigger is a shell command, an MCP STDIO tool call, or an MCP HTTP
tool call. Transports differ only in how they receive the request and how they
return the response.

## 2. End-to-end sequence (MCP STDIO path — typical IDE use)

```plantuml
@startuml
!theme plain
autonumber

actor User
participant "IDE host\n(Copilot Chat)" as Host
participant "Host LLM\n(Copilot)"        as LLM
participant "MCP STDIO server\n(vuln-rewrite JAR)"   as MCP
participant "VulnRewriteMcpTools" as Tools
participant "RemediationOrchestrator" as Orch
participant "GitHub /\nGitLab"     as Remote

User -> Host : "Run a dry-run on https://gitlab/.../cardcontrols using ./export.xlsx"
Host -> LLM  : prompt + available tool descriptions
LLM  -> Host : invoke apply_remediation_dry_run(project_url, vulnerability_file)
Host -> MCP  : MCP CallTool request (JSON-RPC)
MCP  -> Tools : apply_remediation_dry_run(...)
Tools -> Orch : execute(Request{dryRun=true,push=false,openMr=false})

Orch -> Orch : parse → clone → branch → generate plan
Orch -> Remote : git clone
Orch -> Orch : write rewrite.yml + inject plugin
Orch -> Orch : mvn rewrite:dryRun
Orch -> Orch : commit (local only)

Orch --> Tools : RemediationReport
Tools --> MCP  : RemediateResult (record → JSON)
MCP   --> Host : MCP CallTool response
Host  -> LLM   : tool result
LLM   --> Host : human summary ("dry run produced 3 changes …")
Host  --> User : displays summary + link to local report
@enduml
```

Note step 12: the LLM never sees the YAML being authored. The deterministic
Java code does that. The LLM only sees the *result*. This is the structural
reason MCP is safer than the old Azure-OpenAI-driven design — the recipe
synthesis is no longer "the LLM writes YAML."

## 3. End-to-end sequence (Shell / MCP HTTP path — same pipeline)

```plantuml
@startuml
!theme plain
autonumber

actor User
participant "RemediationCommands\n(or HTTP MCP tool)" as Entry
participant "RemediationOrchestrator" as Orch
participant "VulnerabilityParserService" as Parser
participant "GitService" as Git
participant "RecipeGeneratorService" as Gen
participant "GitHub Models" as AI
participant "RecipeWriterService" as Writer
participant "MavenPluginInjector" as Inj
participant "RecipeExecutorService" as Exec
participant "GitLabMergeRequestService" as MR
participant "ReportService" as Rpt

User -> Entry : remediate ...
Entry -> Orch : execute(Request)
Orch -> Parser : parse(file)
Parser --> Orch : List<Vulnerability>

Orch -> Git : cloneOrUpdate(url)
Orch -> Git : createBranch()

Orch -> Gen : generate(vulns, severityFloor)
loop for each unique component coordinate
  Gen -> AI : prompt(component, vulns)
  AI --> Gen : RecipeArtifact JSON
end
Gen --> Orch : RemediationPlan

Orch -> Writer : writeRecipeFile()
Orch -> Inj : inject(pom.xml)

alt dryRun=true
  Orch -> Exec : dryRun
else dryRun=false
  Orch -> Exec : run
end

Orch -> Git : commitAll()
opt push=true
  Orch -> Git : push(branch)
  opt openMr=true
    Orch -> MR : openMergeRequest
  end
end

Orch -> Rpt : writeHtml
Orch --> Entry : RemediationReport
Entry --> User : formatted summary
@enduml
```

## 4. Domain model

Unchanged from v0.1 — `Vulnerability`, `RecipeArtifact` (KNOWN_RECIPE /
GENERATED_YAML / MANUAL), `RemediationPlan`, `RemediationReport`. See the
record/POJO definitions under `com.usbank.vulnrewrite.model`.

## 5. Profile / configuration matrix

| Concern | shell | mcp-stdio | mcp-http |
|---|---|---|---|
| `spring.shell.interactive.enabled` | true | **false** | false |
| `spring.main.banner-mode` | default | **off** | off |
| `spring.main.web-application-type` | none | none | servlet |
| MCP server starter active | no | **yes (STDIO)** | **yes (Streamable HTTP)** |
| ChatClient (GitHub Models) wired | yes | yes (rarely used) | yes |
| RemediationCommands bean | **yes** | no | no |
| McpConfig / VulnRewriteMcpTools beans | no | **yes** | **yes** |
| Logback console appender | yes | **no** (file only) | yes |
| Default port | n/a | n/a | 8080 |

## 6. Why this split is safe

The most material change from v0.1 is that the LLM-authoring-YAML responsibility
moves outside the deterministic pipeline. Three layered guarantees:

1. **Recipe synthesis is bounded.** Even when an LLM is involved (shell /
   mcp-http profile, or as a fallback inside MCP STDIO), the schema
   {strategy ∈ {KNOWN_RECIPE, GENERATED_YAML, MANUAL}} only allows Maven
   dependency upgrades. The model can never propose a Java source change.

2. **MCP host is the gatekeeper for write actions.** `apply_remediation` with
   `push=true` triggers a tool-confirmation prompt in every major MCP host
   (VS Code Copilot, IntelliJ Copilot, Claude Code, Cursor). The user must
   approve before the JAR ever talks to GitLab.

3. **Dry-run is always available and always safe.** The
   `apply_remediation_dry_run` tool is a hard-coded subset that never pushes
   regardless of arguments — the LLM cannot ask it to push because the
   parameters don't exist on the tool surface.

## 7. Failure modes

| Failure | Behaviour |
|---|---|
| Black Duck file missing / wrong format | `RemediationException` from parser; pipeline aborts; MCP returns `RemediateResult{success=false}` with `errorMessage`. |
| LLM unreachable / throws | `RecipeGeneratorService` falls back to `MANUAL` artifact and continues. |
| `pom.xml` malformed | `MavenPluginInjector` aborts before any push. |
| `mvn rewrite:run` fails | Maven exit code captured in report; commit still happens (user can inspect locally). |
| GitLab token missing | Push skipped; MR creation skipped; report still written. |
| MCP STDIO log corrupts stdout | `logback-spring.xml` mcp-stdio profile uses file-only appenders. |
| Concurrent MCP HTTP clients | `SYNC` server type serialises tool calls per session; pipeline is internally thread-safe via stateless services. |
